import json
import os
import re
import shlex
import time
import threading
import unicodedata
import hashlib
import posixpath
import zipfile
import socket
import ipaddress

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.backend_loader import (
    backend_capabilities,
    get_backend,
)
from resources.lib import profiles
from resources.lib import secrets as secret_store


from resources.lib.log_privacy import (
    install_log_filter,
    set_dedicated_log_enabled,
    set_full_ipv4_logging_enabled,
    set_full_ipv6_logging_enabled,
)

install_log_filter()

ADDON = xbmcaddon.Addon("service.vpn.manager")



def _read_debug_bool_setting(setting_id):
    try:
        return ADDON.getSettingBool(
            setting_id
        )

    except Exception:
        try:
            value = ADDON.getSetting(
                setting_id
            )

        except Exception:
            return False

        return str(
            value
        ).strip().lower() in (
            "true",
            "1",
            "yes",
            "on",
        )


def _sync_full_ipv4_logging_setting():
    set_full_ipv4_logging_enabled(
        _read_debug_bool_setting(
            "debug_show_full_ipv4_logs"
        )
    )


def _sync_full_ipv6_logging_setting():
    set_full_ipv6_logging_enabled(
        _read_debug_bool_setting(
            "debug_show_full_ipv6_logs"
        )
    )


_sync_full_ipv4_logging_setting()
_sync_full_ipv6_logging_setting()

def _sync_dedicated_log_setting():
    try:
        enabled = ADDON.getSettingBool(
            "debug_enable_dedicated_log"
        )

    except Exception:
        try:
            value = ADDON.getSetting(
                "debug_enable_dedicated_log"
            )

        except Exception:
            enabled = False

        else:
            enabled = str(
                value
            ).strip().lower() in (
                "true",
                "1",
                "yes",
                "on",
            )

    profile_path = xbmcvfs.translatePath(
        ADDON.getAddonInfo("profile")
    )

    log_path = os.path.join(
        profile_path,
        "vpn-manager.log",
    )

    set_dedicated_log_enabled(
        enabled,
        log_path,
        # The persistent service owns rotation.
        # This avoids competing rotations from
        # two Kodi Python processes.
        manage_rotation=False,
    )


_sync_dedicated_log_setting()

WINDOW = xbmcgui.Window(10000)
DIALOG = xbmcgui.Dialog()

BACKEND = get_backend()
CAPABILITIES = backend_capabilities(
    BACKEND,
    interactive=True
)


def _ensure_backend_host_runtime():
    ensure = getattr(
        BACKEND,
        "ensure_host_runtime",
        None,
    )

    if not ensure:
        return

    try:
        result = ensure()

    except Exception as exc:
        xbmc.log(
            "Kodi VPN Manager: host runtime "
            "initialization failed: {}".format(
                exc
            ),
            xbmc.LOGERROR,
        )
        return

    if not isinstance(result, dict):
        return

    if not result.get("ok"):
        xbmc.log(
            "Kodi VPN Manager: host runtime "
            "initialization failed: {}".format(
                result.get(
                    "message",
                    "unknown error",
                )
            ),
            xbmc.LOGERROR,
        )


_ensure_backend_host_runtime()

REGISTRY = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/profiles.json"
)

SECRET_STORE = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/secrets.json"
)

RECENT_STORE = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/recent_profiles.json"
)

RECENT_LIMIT = 10
RECENT_PIN_LIMIT = 3

FLAG_ROOT = xbmcvfs.translatePath(
    "special://home/addons/"
    "service.vpn.manager/resources/media/flags"
)

FLAG_INDEX = os.path.join(
    FLAG_ROOT,
    "index.json",
)

_FLAG_INDEX_CACHE = None


MANAGED_PROFILE_ROOT = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/imported"
)


def _load_recent_profile_ids():
    try:
        with open(
            RECENT_STORE,
            "r",
            encoding="utf-8",
        ) as handle:
            data = json.load(handle)

    except (
        OSError,
        ValueError,
        TypeError,
    ):
        return []

    if isinstance(data, dict):
        values = data.get(
            "profiles",
            [],
        )

    elif isinstance(data, list):
        values = data

    else:
        return []

    result = []
    seen = set()

    for value in values:
        profile_id = str(
            value or ""
        ).strip()

        if (
            not profile_id
            or profile_id in seen
        ):
            continue

        seen.add(profile_id)
        result.append(profile_id)

        if len(result) >= RECENT_LIMIT:
            break

    return result


def _save_recent_profile_ids(profile_ids):
    directory = (
        os.path.dirname(
            RECENT_STORE
        )
        or "."
    )

    os.makedirs(
        directory,
        exist_ok=True,
    )

    values = []
    seen = set()

    for value in profile_ids:
        profile_id = str(
            value or ""
        ).strip()

        if (
            not profile_id
            or profile_id in seen
        ):
            continue

        seen.add(profile_id)
        values.append(profile_id)

        if len(values) >= RECENT_LIMIT:
            break

    temp_path = RECENT_STORE + ".tmp"

    try:
        with open(
            temp_path,
            "w",
            encoding="utf-8",
        ) as handle:
            json.dump(
                {
                    "schema": 1,
                    "profiles": values,
                },
                handle,
                indent=2,
            )

            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())

        try:
            os.chmod(
                temp_path,
                0o600,
            )
        except OSError:
            pass

        os.replace(
            temp_path,
            RECENT_STORE,
        )

        try:
            os.chmod(
                RECENT_STORE,
                0o600,
            )
        except OSError:
            pass

    finally:
        if os.path.exists(temp_path):
            try:
                os.unlink(temp_path)
            except OSError:
                pass


def _record_recent_profile(profile_id):
    profile_id = str(
        profile_id or ""
    ).strip()

    if not profile_id:
        return

    current = (
        _load_recent_profile_ids()
    )

    current = [
        value
        for value in current
        if value != profile_id
    ]

    current.insert(
        0,
        profile_id,
    )

    _save_recent_profile_ids(
        current
    )



def _country_flag_key(value):
    value = unicodedata.normalize(
        "NFKD",
        str(value or ""),
    )

    value = value.encode(
        "ascii",
        "ignore",
    ).decode("ascii")

    return re.sub(
        r"[^a-z0-9]+",
        " ",
        value.casefold(),
    ).strip()


def _country_flag_index():
    global _FLAG_INDEX_CACHE

    if _FLAG_INDEX_CACHE is not None:
        return _FLAG_INDEX_CACHE

    try:
        with open(
            FLAG_INDEX,
            "r",
            encoding="utf-8",
        ) as handle:
            data = json.load(handle)

        if not isinstance(data, dict):
            data = {}

    except (
        OSError,
        ValueError,
        TypeError,
    ):
        data = {}

    _FLAG_INDEX_CACHE = data
    return data


def _country_display_name(country):
    raw = str(
        country or ""
    ).strip()

    key = _country_flag_key(
        raw
    )

    aliases = {
        "british virgin island":
            "British Virgin Islands",
        "british virgin islands":
            "British Virgin Islands",
        "luxemburg":
            "Luxembourg",
        "luxembourg":
            "Luxembourg",
    }

    return aliases.get(
        key,
        raw,
    )


def _country_flag_path(country):
    filename = (
        _country_flag_index().get(
            _country_flag_key(
                country
            )
        )
    )

    if not filename:
        return ""

    path = os.path.join(
        FLAG_ROOT,
        filename,
    )

    if not os.path.isfile(path):
        return ""

    return path.replace(
        "\\",
        "/",
    )


def _country_flag_from_location(value):
    value = str(value or "").strip()

    if not value:
        return ""

    parts = [
        part.strip()
        for part in value.split(",")
        if part.strip()
    ]

    for candidate in reversed(parts):
        flag = _country_flag_path(candidate)

        if flag:
            return flag

    return _country_flag_path(value)


def prop(name):
    value = WINDOW.getProperty(
        "VPNManager." + name
    )

    return value if value else "N/A"


def selected_profile():
    data = profiles.load(REGISTRY)

    return (
        data,
        profiles.selected_profile(data)
    )


def profile_name(profile):
    if not profile:
        return "None"

    return profile.get(
        "name",
        profile.get("id", "Unknown")
    )


def show_status():
    data, selected = selected_profile()

    message = (
        "Platform: {platform}\n"
        "Mode: {mode}\n"
        "\n"
        "VPN path: {path}\n"
        "Status: {status}\n"
        "Public IP: {public_ip}\n"
        "Interface: {interface}\n"
        "Tunnel IP: {tunnel_ip}\n"
        "Server: {server}\n"
        "Kill switch: {killswitch}\n"
        "Verification: {verification}\n"
        "\n"
        "Selected profile: {profile}"
    ).format(
        platform=CAPABILITIES["name"],
        mode=CAPABILITIES["mode"].title(),
        path=prop("VPNPath"),
        status=prop("VPNStatus"),
        public_ip=prop("PublicIP"),
        interface=prop("VPNInterface"),
        tunnel_ip=prop("VPNTunnelIP"),
        server=prop("VPNServer"),
        killswitch=prop("VPNKillSwitch"),
        verification=prop("VPNVerification"),
        profile=profile_name(selected),
    )

    DIALOG.textviewer(
        "Kodi VPN Manager",
        message
    )



def choose_profile():
    data = profiles.load(REGISTRY)

    available = [
        profile
        for profile in profiles.profiles(data)
        if profile.get("enabled", True)
    ]

    if not available:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No enabled managed VPN profiles are configured."
        )
        return

    current = profiles.selected_profile(data)

    labels = []

    for profile in available:
        prefix = (
            "✓ "
            if current
            and profile["id"] == current["id"]
            else ""
        )

        labels.append(
            "{}{} [{}]".format(
                prefix,
                profile["name"],
                profile["type"].upper(),
            )
        )

    choice = DIALOG.select(
        "Select VPN Profile",
        labels
    )

    if choice < 0:
        return

    selected = available[choice]

    data = profiles.set_selected(
        data,
        selected["id"]
    )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Selected: {}".format(
            selected["name"]
        ),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def supported_profile_types():
    getter = getattr(
        BACKEND,
        "supported_profile_types",
        None
    )

    if not getter:
        return []

    try:
        return list(getter())
    except Exception:
        return []


def add_profile():
    types = supported_profile_types()

    if not types:
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform has no supported managed VPN profile types."
        )
        return

    if len(types) == 1:
        profile_type = types[0]

    else:
        labels = [
            item.upper()
            for item in types
        ]

        choice = DIALOG.select(
            "VPN Profile Type",
            labels
        )

        if choice < 0:
            return

        profile_type = types[choice]

    if profile_type == "openvpn":
        mask = ".ovpn"
        heading = "Select OpenVPN Profile"

    elif profile_type == "wireguard":
        mask = ".conf"
        heading = "Select WireGuard Profile"

    else:
        return

    selected_path = DIALOG.browseSingle(
        1,
        heading,
        "",
        mask,
        False,
        False,
        ""
    )

    if not selected_path:
        return

    selected_path = xbmcvfs.translatePath(
        selected_path
    )

    default_name = os.path.splitext(
        os.path.basename(selected_path)
    )[0]

    name = DIALOG.input(
        "Profile Name",
        defaultt=default_name
    ).strip()

    if not name:
        return

    data = profiles.load(REGISTRY)

    profile = {
        "id": profiles.make_id(profile_type),
        "name": name,
        "type": profile_type,
        "path": selected_path,
        "enabled": True,
    }

    data = profiles.upsert(
        data,
        profile
    )

    #
    # First profile becomes selected automatically.
    #
    if not profiles.selected_profile(data):
        data = profiles.set_selected(
            data,
            profile["id"]
        )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Added: {}".format(name),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def remove_profile():
    data = profiles.load(REGISTRY)
    available = profiles.profiles(data)

    if not available:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No managed VPN profiles are configured."
        )
        return

    current = profiles.selected_profile(data)

    labels = []

    for profile in available:
        prefix = (
            "✓ "
            if current
            and profile["id"] == current["id"]
            else ""
        )

        labels.append(
            "{}{} [{}]".format(
                prefix,
                profile["name"],
                profile["type"].upper(),
            )
        )

    choice = DIALOG.select(
        "Remove VPN Profile",
        labels
    )

    if choice < 0:
        return

    profile = available[choice]

    if not DIALOG.yesno(
        "Kodi VPN Manager",
        "Remove profile '{}' ?".format(
            profile["name"]
        )
    ):
        return

    data = profiles.remove(
        data,
        profile["id"]
    )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Removed: {}".format(
            profile["name"]
        ),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def can_manage(profile):
    if not CAPABILITIES["can_manage"]:
        return False

    checker = getattr(
        BACKEND,
        "can_manage_profile",
        None
    )

    if not checker:
        return False

    return bool(checker(profile))


def show_result(title, result):
    if not isinstance(result, dict):
        DIALOG.ok(
            title,
            str(result)
        )
        return

    ok = bool(result.get("ok"))

    message = result.get(
        "message",
        "Completed" if ok else "Failed"
    )

    state = result.get("state")

    if state:
        message += "\n\nState: {}".format(
            state
        )

    DIALOG.ok(
        title,
        message
    )


def connect_selected():
    data, profile = selected_profile()

    if not profile:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No VPN profile is selected."
        )
        return

    if not can_manage(profile):
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform cannot manage the selected profile."
        )
        return

    connector = getattr(
        BACKEND,
        "connect",
        None
    )

    if not connector:
        return

    result = connector(profile)

    show_result(
        "VPN Connection",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )


def disconnect_selected():
    data, profile = selected_profile()

    if not profile:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No VPN profile is selected."
        )
        return

    if not can_manage(profile):
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform cannot manage the selected profile."
        )
        return

    disconnect = getattr(
        BACKEND,
        "disconnect",
        None
    )

    if not disconnect:
        return

    result = disconnect(profile)

    show_result(
        "VPN Disconnect",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )







def _publish_dashboard_core():
    data, selected = selected_profile()

    WINDOW.setProperty(
        "VPNManager.Platform",
        CAPABILITIES["name"]
    )

    WINDOW.setProperty(
        "VPNManager.Mode",
        CAPABILITIES["mode"].title()
    )

    selected_name = profile_name(selected)

    selected_country = str(
        (selected or {}).get("country")
        or ""
    ).strip()

    if selected_name and selected_country:
        match = re.match(
            r"^(.*?)(\s*\[[^\]]+\]\s*)$",
            selected_name,
        )

        if match:
            base_name = match.group(1).strip()
            protocol_suffix = match.group(2).strip()

            if (
                selected_country.casefold()
                not in base_name.casefold()
            ):
                selected_name = "{}, {} {}".format(
                    base_name,
                    selected_country,
                    protocol_suffix,
                )

        elif (
            selected_country.casefold()
            not in selected_name.casefold()
        ):
            selected_name = "{}, {}".format(
                selected_name,
                selected_country,
            )

    protocol = ""

    if selected:
        options = (
            selected.get("protocol_options")
            or {}
        )

        raw_protocol = str(
            options.get("protocol")
            or ""
        ).strip().lower()

        if raw_protocol.startswith("tcp"):
            protocol = "TCP"

        elif raw_protocol.startswith("udp"):
            protocol = "UDP"

        elif raw_protocol.startswith("wireguard"):
            protocol = "WireGuard"

        if not protocol:
            upper_name = selected_name.upper()

            if "[TCP" in upper_name:
                protocol = "TCP"

            elif "[UDP" in upper_name:
                protocol = "UDP"

            elif (
                str(
                    selected.get("type")
                    or ""
                ).strip().lower()
                == "wireguard"
            ):
                protocol = "WireGuard"

    WINDOW.setProperty(
        "VPNManager.SelectedProfile",
        selected_name
    )

    WINDOW.setProperty(
        "VPNManager.SelectedProtocol",
        protocol
    )



class ProfileManagerWindow(xbmcgui.WindowXMLDialog):

    PROVIDER_LIST = 200
    PROFILE_LIST = 201

    PROFILE_HEADER = 202
    STATUS_HEADER = 203
    PROTOCOL_HEADER = 204

    PROFILE_UNDERLINE = 205
    STATUS_UNDERLINE = 206
    PROTOCOL_UNDERLINE = 207
    FILTER_INFO = 208
    FILTER_UNDERLINE = 209

    ADD_BUTTON = 210
    IMPORT_BUTTON = 211
    EDIT_BUTTON = 212
    DELETE_BUTTON = 213
    CREDENTIALS_BUTTON = 214
    CLOSE_BUTTON = 215

    FILTER_BUTTON = 216
    SORT_BUTTON = 217

    SORT_INFO = 218
    SORT_UNDERLINE = 219


    RECENT_LIST = 220
    RECENT_HEADER = 221
    RECENT_UNDERLINE = 222
    RECENT_SEPARATOR = 223
    def onInit(self):
        self._data = profiles.load(REGISTRY)
        self._active_provider_id = None

        self._browser_country = None
        self._last_browser_country = None

        # Profile-browser view state.
        #
        # These affect presentation only. They never alter
        # registry contents or VPN activation behaviour.
        _vpn_saved_filter = xbmcgui.Window(
            10000
        ).getProperty(
            "VPNManager.ProfileFilter"
        )

        if _vpn_saved_filter not in (
            "all",
            "tcp",
            "udp",
            "wireguard",
            "verified",
            "imported",
            "city",
            "auto",
        ):
            _vpn_saved_filter = "all"

        self._profile_filter = (
            _vpn_saved_filter
        )
        self._profile_sort = "location"

        self._update_profile_filter_sort_buttons()

        self._management_context = (
            "profile"
            if profiles.providers(self._data)
            else "provider"
        )

        current = profiles.selected_profile(
            self._data
        )

        preferred_provider = (
            current.get("provider_id")
            if current
            else None
        )

        self._load_providers(
            preferred_provider
        )

        self._update_management_buttons()

        # Start on the currently selected service so its
        # focus/highlight is immediately visible.
        if profiles.providers(self._data):
            self.setFocusId(
                self.RECENT_LIST
            )
        else:
            self.setFocusId(
                self.ADD_BUTTON
            )

    def _load_providers(
        self,
        preferred_provider=None,
    ):
        control = self.getControl(
            self.PROVIDER_LIST
        )

        control.reset()

        available = list(
            profiles.providers(
                self._data
            )
        )

        active_profile_id = (
            self._active_profile_id()
        )

        active_provider_id = None

        if active_profile_id:
            for profile in profiles.profiles(
                self._data
            ):
                if (
                    profile.get("id")
                    == active_profile_id
                ):
                    active_provider_id = (
                        profile.get(
                            "provider_id"
                        )
                    )
                    break

        # Active service goes first.
        # Other services keep their existing ordering.
        if active_provider_id:
            available.sort(
                key=lambda provider: (
                    0
                    if provider.get("id")
                    == active_provider_id
                    else 1
                )
            )

            # Also highlight the active service initially.
            preferred_provider = (
                active_provider_id
            )

        chosen_index = 0

        for index, provider in enumerate(
            available
        ):
            provider_id = provider["id"]

            provider_profiles = (
                profiles.profiles_for_provider(
                    self._data,
                    provider_id,
                )
            )

            count = len(
                provider_profiles
            )

            item = xbmcgui.ListItem(
                label="{} [{}]".format(
                    provider["name"],
                    count,
                ),
                label2=(
                    "Active"
                    if provider_id
                    == active_provider_id
                    else ""
                ),
            )

            item.setProperty(
                "provider_id",
                provider_id,
            )

            control.addItem(
                item
            )

            if (
                provider_id
                == preferred_provider
            ):
                chosen_index = index

        if not available:
            self._active_provider_id = None
            self._load_profiles(None)
            return

        control.selectItem(
            chosen_index
        )

        self._active_provider_id = (
            available[
                chosen_index
            ]["id"]
        )

        self._load_profiles(
            self._active_provider_id
        )


    def _active_profile_id(self):
        # Prefer a backend-provided verified profile identity.
        getter = getattr(
            BACKEND,
            "active_profile_id",
            None,
        )

        if getter:
            try:
                profile_id = getter()

                if profile_id:
                    return profile_id

            except Exception:
                pass

        return None

    def _update_profile_browser_header(self):
        country = self._browser_country

        if country:
            title = _country_display_name(
                country
            )

            underline_width = max(
                65,
                min(
                    260,
                    len(country) * 10 + 15,
                ),
            )

            show_protocol = True

        else:
            title = "Countries"

            # Slightly longer than before.
            underline_width = 110
            show_protocol = False

        filter_names = {
            "all": "All",
            "tcp": "TCP",
            "udp": "UDP",
            "wireguard": "WireGuard",
            "verified": "Verified",
            "imported": "Imported",
            "city": "City",
            "auto": "Auto",
        }

        sort_names = {
            "location": "Location",
            "name": "Name",
            "protocol": "Protocol",
            "verified": "Verified",
            "imported": "Imported",
        }

        filter_name = filter_names.get(
            getattr(
                self,
                "_profile_filter",
                "all",
            ),
            "All",
        )

        sort_name = sort_names.get(
            getattr(
                self,
                "_profile_sort",
                "location",
            ),
            "Location",
        )

        try:
            self.getControl(
                self.PROFILE_HEADER
            ).setLabel(
                "[B]{}[/B]".format(
                    title
                )
            )
        except Exception:
            pass

        try:
            self.getControl(
                self.PROFILE_UNDERLINE
            ).setWidth(
                underline_width
            )
        except Exception:
            pass

        # Filter / Sort footer.
        filter_text = "Filter: {}".format(
            filter_name
        )

        sort_text = "Sort: {}".format(
            sort_name
        )

        try:
            self.getControl(
                self.FILTER_INFO
            ).setLabel(
                "[I]{}[/I]".format(
                    filter_text
                )
            )
        except Exception:
            pass

        try:
            self.getControl(
                self.SORT_INFO
            ).setLabel(
                "[I]{}[/I]".format(
                    sort_text
                )
            )
        except Exception:
            pass

        # Individually sized Filter underline.
        try:
            width = max(
                70,
                min(
                    150,
                    len(filter_text) * 8 + 8,
                ),
            )

            underline = self.getControl(
                self.FILTER_UNDERLINE
            )

            underline.setWidth(width)

            underline.setPosition(
                int(395 - width / 2),
                574,
            )

        except Exception:
            pass

        # Individually sized Sort underline.
        try:
            width = max(
                70,
                min(
                    170,
                    len(sort_text) * 8 + 8,
                ),
            )

            underline = self.getControl(
                self.SORT_UNDERLINE
            )

            underline.setWidth(width)

            underline.setPosition(
                int(565 - width / 2),
                574,
            )

        except Exception:
            pass

        # Fixed right-hand columns on every browser level:
        #
        #   Location / Country | Protocol | Status
        #
        # Protocol and Status never move between pages.
        try:
            status_header = self.getControl(
                self.STATUS_HEADER
            )
            status_header.setPosition(
                655,
                115,
            )
            status_header.setWidth(
                160
            )
            status_header.setVisible(
                True
            )

            status_underline = self.getControl(
                self.STATUS_UNDERLINE
            )
            status_underline.setPosition(
                749,
                151,
            )
            status_underline.setWidth(
                66
            )
            status_underline.setVisible(
                True
            )

        except Exception:
            pass

        try:
            protocol_header = self.getControl(
                self.PROTOCOL_HEADER
            )
            protocol_header.setPosition(
                510,
                115,
            )
            protocol_header.setWidth(
                135
            )
            protocol_header.setVisible(
                True
            )

            protocol_underline = self.getControl(
                self.PROTOCOL_UNDERLINE
            )
            protocol_underline.setPosition(
                563,
                151,
            )
            protocol_underline.setWidth(
                82
            )
            protocol_underline.setVisible(
                True
            )

        except Exception:
            pass

        # Split Recent/Countries root layout.
        #
        # Recent Connections is shown only at the country root.
        # Inside a country the profile browser expands back to
        # the original full-height layout.
        root_view = not bool(
            self._browser_country
        )

        for control_id in (
            self.RECENT_HEADER,
            self.RECENT_UNDERLINE,
            self.RECENT_LIST,
            self.RECENT_SEPARATOR,
        ):
            try:
                self.getControl(
                    control_id
                ).setVisible(
                    root_view
                )
            except Exception:
                pass

        try:
            profile_header = self.getControl(
                self.PROFILE_HEADER
            )
            profile_underline = self.getControl(
                self.PROFILE_UNDERLINE
            )
            protocol_header = self.getControl(
                self.PROTOCOL_HEADER
            )
            protocol_underline = self.getControl(
                self.PROTOCOL_UNDERLINE
            )
            status_header = self.getControl(
                self.STATUS_HEADER
            )
            status_underline = self.getControl(
                self.STATUS_UNDERLINE
            )
            profile_list = self.getControl(
                self.PROFILE_LIST
            )

            if root_view:
                # Recent occupies the upper half.
                # Countries are clearly separated below.
                profile_header.setPosition(
                    90,
                    305,
                )

                profile_underline.setPosition(
                    90,
                    341,
                )

                protocol_header.setPosition(
                    510,
                    305,
                )

                protocol_underline.setPosition(
                    563,
                    341,
                )

                status_header.setPosition(
                    655,
                    305,
                )

                status_underline.setPosition(
                    749,
                    341,
                )

                profile_list.setPosition(
                    90,
                    345,
                )

                profile_list.setHeight(
                    185
                )

            else:
                profile_header.setPosition(
                    90,
                    115,
                )

                profile_underline.setPosition(
                    90,
                    151,
                )

                protocol_header.setPosition(
                    510,
                    115,
                )

                protocol_underline.setPosition(
                    563,
                    151,
                )

                status_header.setPosition(
                    655,
                    115,
                )

                status_underline.setPosition(
                    749,
                    151,
                )

                profile_list.setPosition(
                    90,
                    155,
                )

                profile_list.setHeight(
                    375
                )

        except Exception:
            pass

        # Requested root underline sizes.
        try:
            self.getControl(
                self.RECENT_UNDERLINE
            ).setWidth(205)

            if root_view:
                self.getControl(
                    self.PROFILE_UNDERLINE
                ).setWidth(90)

        except Exception:
            pass

        # Browser root underline final sizes.
        try:
            self.getControl(
                self.RECENT_UNDERLINE
            ).setWidth(
                205
            )

            if root_view:
                self.getControl(
                    self.PROFILE_UNDERLINE
                ).setWidth(
                    105
                )

        except Exception:
            pass


    def _profile_transport(self, profile):
        options = (
            profile.get("protocol_options")
            or {}
        )

        protocol = str(
            options.get(
                "protocol",
                "",
            )
            or ""
        ).strip().lower()

        if protocol in (
            "tcp",
            "udp",
        ):
            return protocol

        profile_type = str(
            profile.get(
                "type",
                "",
            )
            or ""
        ).strip().lower()

        if profile_type == "wireguard":
            return "wireguard"

        # Compatibility for older profiles that have
        # protocol information only in their name.
        name = str(
            profile.get(
                "name",
                "",
            )
            or ""
        ).upper()

        if "[TCP" in name:
            return "tcp"

        if "[UDP" in name:
            return "udp"

        return (
            profile_type
            or "unknown"
        )

    def _profile_is_verified(
        self,
        profile,
    ):
        options = (
            profile.get("protocol_options")
            or {}
        )

        verification = str(
            options.get(
                "verification",
                "",
            )
            or ""
        ).strip().lower()

        path = str(
            profile.get(
                "path",
                "",
            )
            or ""
        ).replace(
            "\\",
            "/",
        ).lower()

        return bool(
            verification
            in (
                "live-tunnel+geo",
                "live-tunnel",
                "verified",
            )
            or "/verified-openvpn/"
            in path
        )

    def _profile_is_imported(
        self,
        profile,
    ):
        path = str(
            profile.get(
                "path",
                "",
            )
            or ""
        ).replace(
            "\\",
            "/",
        )

        root = str(
            MANAGED_PROFILE_ROOT
            or ""
        ).replace(
            "\\",
            "/",
        ).rstrip("/")

        if (
            root
            and path.startswith(
                root + "/"
            )
        ):
            return True

        return (
            "/imported/"
            in path.lower()
        )

    def _profile_location_info(
        self,
        profile,
    ):
        options = (
            profile.get("protocol_options")
            or {}
        )

        city = str(
            options.get(
                "city",
                "",
            )
            or ""
        ).strip()

        name = str(
            profile.get(
                "name",
                profile.get(
                    "id",
                    "",
                ),
            )
            or ""
        ).strip()

        clean_name = re.sub(
            r"\s*\[[^\]]+\]\s*$",
            "",
            name,
        ).strip()

        if city:
            location = city

        elif " - " in clean_name:
            location = clean_name.rsplit(
                " - ",
                1,
            )[1].strip()

        else:
            location = clean_name

        name_words = (
            " "
            + clean_name.casefold()
            + " "
        )

        is_auto = (
            " auto "
            in name_words
        )

        return (
            location,
            city,
            is_auto,
        )

    def _profile_matches_filter(
        self,
        profile,
    ):
        mode = getattr(
            self,
            "_profile_filter",
            "all",
        )

        if mode == "all":
            return True

        if mode == "recent":
            recent_ids = getattr(
                self,
                "_recent_profile_id_set",
                None,
            )

            if recent_ids is None:
                recent_ids = set(
                    _load_recent_profile_ids()
                )

            return (
                str(
                    profile.get(
                        "id",
                        "",
                    )
                    or ""
                )
                in recent_ids
            )

        transport = (
            self._profile_transport(
                profile
            )
        )

        if mode in (
            "tcp",
            "udp",
            "wireguard",
        ):
            return (
                transport == mode
            )

        if mode == "verified":
            return (
                self._profile_is_verified(
                    profile
                )
            )

        if mode == "imported":
            return (
                self._profile_is_imported(
                    profile
                )
            )

        location, city, is_auto = (
            self._profile_location_info(
                profile
            )
        )

        if mode == "city":
            return bool(
                city
                or (
                    location
                    and not is_auto
                )
            )

        if mode == "auto":
            return bool(
                is_auto
                or not location
            )

        return True

    def _profile_sort_key(
        self,
        profile,
    ):
        mode = getattr(
            self,
            "_profile_sort",
            "location",
        )

        name = str(
            profile.get(
                "name",
                profile.get(
                    "id",
                    "",
                ),
            )
            or ""
        ).strip()

        location, city, is_auto = (
            self._profile_location_info(
                profile
            )
        )

        transport = (
            self._profile_transport(
                profile
            )
        )

        protocol_rank = {
            "tcp": 0,
            "udp": 1,
            "wireguard": 2,
        }.get(
            transport,
            9,
        )

        verified_rank = (
            0
            if self._profile_is_verified(
                profile
            )
            else 1
        )

        imported_rank = (
            0
            if self._profile_is_imported(
                profile
            )
            else 1
        )

        auto_rank = (
            1
            if is_auto
            else 0
        )

        location_key = (
            location
            or name
        ).casefold()

        name_key = name.casefold()

        if mode == "name":
            return (
                name_key,
                protocol_rank,
                location_key,
            )

        if mode == "protocol":
            return (
                protocol_rank,
                auto_rank,
                location_key,
                name_key,
            )

        if mode == "verified":
            return (
                verified_rank,
                auto_rank,
                location_key,
                protocol_rank,
                name_key,
            )

        if mode == "imported":
            return (
                imported_rank,
                auto_rank,
                location_key,
                protocol_rank,
                name_key,
            )

        # Default: human-friendly location ordering.
        #
        # Specific city/location entries first,
        # generic Auto entries afterward.
        return (
            auto_rank,
            location_key,
            protocol_rank,
            name_key,
        )

    def _update_profile_filter_sort_buttons(
        self,
    ):
        filter_labels = {
            "all": "All",
            "tcp": "TCP",
            "udp": "UDP",
            "wireguard": "WireGuard",
            "verified": "Verified",
            "imported": "Imported",
            "city": "City",
            "auto": "Auto / Other",
        }

        sort_labels = {
            "location": "Location",
            "name": "Name A-Z",
            "protocol": "Protocol",
            "verified": "Verified First",
            "imported": "Imported First",
        }

        filter_value = getattr(
            self,
            "_profile_filter",
            "all",
        )

        sort_value = getattr(
            self,
            "_profile_sort",
            "location",
        )

        try:
            self.getControl(
                self.FILTER_BUTTON
            ).setLabel(
                "Filter: {}".format(
                    filter_labels.get(
                        filter_value,
                        "All",
                    )
                )
            )
        except Exception:
            pass

        try:
            self.getControl(
                self.SORT_BUTTON
            ).setLabel(
                "Sort: {}".format(
                    sort_labels.get(
                        sort_value,
                        "Location",
                    )
                )
            )
        except Exception:
            pass

    def _choose_profile_filter(self):
        choices = [
            ("all", "All profiles"),
            ("tcp", "TCP only"),
            ("udp", "UDP only"),
            (
                "wireguard",
                "WireGuard only",
            ),
            (
                "verified",
                "Verified only",
            ),
            (
                "imported",
                "Imported only",
            ),
            (
                "city",
                "City / specific locations",
            ),
            (
                "auto",
                "Auto / other entries",
            ),
        ]

        current = getattr(
            self,
            "_profile_filter",
            "all",
        )

        labels = [
            "{}{}".format(
                "✓ "
                if key == current
                else "",
                label,
            )
            for key, label
            in choices
        ]

        choice = DIALOG.select(
            "Filter VPN Profiles",
            labels,
        )

        if (
            choice < 0
            or choice >= len(
                choices
            )
        ):
            return

        self._profile_filter = (
            choices[choice][0]
        )

        xbmcgui.Window(
            10000
        ).setProperty(
            "VPNManager.ProfileFilter",
            self._profile_filter,
        )

        self._update_profile_filter_sort_buttons()

        self._load_profiles(
            self._active_provider_id
        )

    def _choose_profile_sort(self):
        choices = [
            (
                "location",
                "Location A-Z "
                "(Auto last)",
            ),
            (
                "name",
                "Profile name A-Z",
            ),
            (
                "protocol",
                "Protocol "
                "(TCP, UDP, WireGuard)",
            ),
            (
                "verified",
                "Verified first",
            ),
            (
                "imported",
                "Imported first",
            ),
        ]

        current = getattr(
            self,
            "_profile_sort",
            "location",
        )

        labels = [
            "{}{}".format(
                "✓ "
                if key == current
                else "",
                label,
            )
            for key, label
            in choices
        ]

        choice = DIALOG.select(
            "Sort VPN Profiles",
            labels,
        )

        if (
            choice < 0
            or choice >= len(
                choices
            )
        ):
            return

        self._profile_sort = (
            choices[choice][0]
        )

        self._update_profile_filter_sort_buttons()

        self._load_profiles(
            self._active_provider_id
        )

    def _load_recent_profiles(
        self,
        provider_id,
        recent_ids=None,
    ):
        control = self.getControl(
            self.RECENT_LIST
        )

        control.reset()

        if not provider_id:
            return

        if recent_ids is None:
            recent_ids = (
                _load_recent_profile_ids()
            )

        provider_profiles = list(
            profiles.profiles_for_provider(
                self._data,
                provider_id,
            )
        )

        by_id = {
            profile.get("id"): profile
            for profile
            in provider_profiles
        }

        active_id = (
            self._active_profile_id()
        )

        added = 0

        for profile_id in recent_ids:
            profile = by_id.get(
                profile_id
            )

            if not profile:
                continue

            country = str(
                profile.get(
                    "country",
                    "Unassigned",
                )
                or "Unassigned"
            ).strip() or "Unassigned"

            name = str(
                profile.get(
                    "name",
                    profile_id,
                )
                or profile_id
            ).strip()

            protocol = (
                self._profile_transport(
                    profile
                ).upper()
            )

            # The country prefix makes the Recent section
            # useful without first navigating into a country.
            label = "{} — {}".format(
                _country_display_name(
                    country
                ),
                name,
            )

            state = (
                "Active"
                if profile_id == active_id
                else ""
            )

            item = xbmcgui.ListItem(
                label=label,
                label2=protocol,
            )

            item.setProperty(
                "browser_kind",
                "profile",
            )

            item.setProperty(
                "profile_id",
                profile_id,
            )

            item.setProperty(
                "country",
                country,
            )

            item.setProperty(
                "flag_path",
                _country_flag_path(
                    country
                ),
            )

            item.setProperty(
                "vpn_status",
                state,
            )

            control.addItem(
                item
            )

            added += 1

        if not added:
            item = xbmcgui.ListItem(
                label="No recent connections yet",
                label2="",
            )

            item.setProperty(
                "browser_kind",
                "info",
            )

            item.setProperty(
                "vpn_status",
                "",
            )

            control.addItem(
                item
            )


    def _load_profiles(
        self,
        provider_id,
    ):
        control = self.getControl(
            self.PROFILE_LIST
        )

        control.reset()

        self._update_profile_browser_header()

        if not provider_id:
            return

        all_provider_profiles = list(
            profiles.profiles_for_provider(
                self._data,
                provider_id,
            )
        )

        recent_ids = (
            _load_recent_profile_ids()
        )

        self._recent_profile_ids_cache = (
            recent_ids
        )

        self._recent_profile_id_set = set(
            recent_ids
        )

        self._load_recent_profiles(
            provider_id,
            recent_ids,
        )

        available = [
            profile
            for profile
            in all_provider_profiles
            if self._profile_matches_filter(
                profile
            )
        ]

        # VPN_COUNTRY_COUNTS_BEGIN
        _vpn_country_counts = {}

        for _vpn_profile in available:
            _vpn_country = str(
                _vpn_profile.get(
                    "country",
                    "",
                )
                or ""
            ).strip()

            if _vpn_country:
                _vpn_country_counts[
                    _vpn_country
                ] = (
                    _vpn_country_counts.get(
                        _vpn_country,
                        0,
                    )
                    + 1
                )
        # VPN_COUNTRY_COUNTS_END

        active_id = (
            self._active_profile_id()
        )

        selected = profiles.selected_profile(
            self._data
        )

        preferred_id = (
            selected.get("id")
            if selected
            else None
        )

        selected_country = None

        if (
            selected
            and selected.get(
                "provider_id"
            )
            == provider_id
        ):
            selected_country = str(
                selected.get(
                    "country"
                )
                or "Unassigned"
            ).strip() or "Unassigned"

        active_country = None
        active_protocol = ""

        if active_id:
            for profile in all_provider_profiles:
                if (
                    profile.get("id")
                    == active_id
                ):
                    active_country = str(
                        profile.get(
                            "country"
                        )
                        or "Unassigned"
                    ).strip() or "Unassigned"

                    active_protocol = (
                        self._profile_transport(
                            profile
                        ).upper()
                    )

                    break

        # ==================================================
        # Countries
        # ==================================================

        if not self._browser_country:
            #
            # Country ordering:
            #
            #   1. Five most recently used unique countries
            #      in recent-connection order.
            #
            #   2. Every remaining visible country
            #      alphabetically.
            #
            # A country that falls out of the recent five
            # automatically returns to its alphabetical position.
            #
            _vpn_alphabetical_countries = sorted(
                {
                    str(
                        profile.get(
                            "country",
                            "Unassigned",
                        )
                        or "Unassigned"
                    ).strip()
                    or "Unassigned"
                    for profile
                    in available
                },
                key=lambda value: (
                    value.casefold()
                    == "unassigned",
                    value.casefold(),
                ),
            )

            _vpn_visible_countries = set(
                _vpn_alphabetical_countries
            )

            _vpn_profiles_by_id = {
                profile.get("id"): profile
                for profile
                in all_provider_profiles
                if profile.get("id")
            }

            _vpn_recent_countries = []

            for _vpn_recent_id in recent_ids:
                _vpn_recent_profile = (
                    _vpn_profiles_by_id.get(
                        _vpn_recent_id
                    )
                )

                if not _vpn_recent_profile:
                    continue

                _vpn_recent_country = str(
                    _vpn_recent_profile.get(
                        "country",
                        "Unassigned",
                    )
                    or "Unassigned"
                ).strip() or "Unassigned"

                #
                # Respect the current profile filter. A recent
                # country is promoted only if that country still
                # exists in the currently visible country list.
                #
                if (
                    _vpn_recent_country
                    not in _vpn_visible_countries
                ):
                    continue

                if (
                    _vpn_recent_country
                    in _vpn_recent_countries
                ):
                    continue

                _vpn_recent_countries.append(
                    _vpn_recent_country
                )

                if len(
                    _vpn_recent_countries
                ) >= 5:
                    break

            _vpn_recent_country_set = set(
                _vpn_recent_countries
            )

            _vpn_alphabetical_remainder = [
                country
                for country
                in _vpn_alphabetical_countries
                if country
                not in _vpn_recent_country_set
            ]

            countries = (
                _vpn_recent_countries
                + _vpn_alphabetical_remainder
            )

            #
            # Visual rows for the Countries browser.
            #
            # Separator rows are marked with browser_kind=separator
            # and navigation code skips them automatically.
            #
            _vpn_country_rows = []

            if _vpn_recent_countries:
                _vpn_country_rows.append(
                    (
                        "separator",
                        "Recent:",
                    )
                )

                _vpn_country_rows.extend(
                    (
                        "country",
                        country,
                    )
                    for country
                    in _vpn_recent_countries
                )

                if _vpn_alphabetical_remainder:
                    _vpn_country_rows.append(
                        (
                            "separator",
                            "Alphabetical:",
                        )
                    )

            _vpn_country_rows.extend(
                (
                    "country",
                    country,
                )
                for country
                in _vpn_alphabetical_remainder
            )

            #
            # With no recent history, retain the ordinary
            # alphabetical list without an unnecessary heading.
            #
            if not _vpn_recent_countries:
                _vpn_country_rows = [
                    (
                        "country",
                        country,
                    )
                    for country
                    in _vpn_alphabetical_remainder
                ]

            preferred_country = (
                self._last_browser_country
                or active_country
                or selected_country
            )

            chosen_index = (
                1
                if _vpn_recent_countries
                else 0
            )

            for index, _vpn_country_row in enumerate(
                _vpn_country_rows
            ):
                (
                    _vpn_country_row_kind,
                    _vpn_country_row_value,
                ) = _vpn_country_row

                if (
                    _vpn_country_row_kind
                    == "separator"
                ):
                    item = xbmcgui.ListItem(
                        label=_vpn_country_row_value,
                        label2="",
                    )

                    item.setProperty(
                        "browser_kind",
                        "separator",
                    )

                    item.setProperty(
                        "country",
                        "",
                    )

                    item.setProperty(
                        "flag_path",
                        "",
                    )

                    item.setProperty(
                        "vpn_status",
                        "",
                    )

                    control.addItem(
                        item
                    )

                    continue

                country = (
                    _vpn_country_row_value
                )
                state = ""

                if (
                    active_country
                    and country
                    == active_country
                ):
                    state = "Active"

                elif (
                    not active_country
                    and selected_country
                    and country
                    == selected_country
                ):
                    state = "Fallback"

                item = xbmcgui.ListItem(
                    label="{} ({})".format(
                        _country_display_name(
                            country
                        ),
                        _vpn_country_counts.get(
                            country,
                            0,
                        ),
                    ),
                    label2=(
                        active_protocol
                        if state == "Active"
                        else ""
                    ),
                )

                item.setProperty(
                    "browser_kind",
                    "country",
                )

                item.setProperty(
                    "country",
                    country,
                )

                item.setProperty(
                    "flag_path",
                    _country_flag_path(
                        country
                    ),
                )

                item.setProperty(
                    "vpn_status",
                    state,
                )

                control.addItem(
                    item
                )

                if (
                    country
                    == preferred_country
                ):
                    chosen_index = index

            if countries:
                control.selectItem(
                    chosen_index
                )

            return

        # ==================================================
        # Profiles in country
        # ==================================================

        country = self._browser_country

        back_item = xbmcgui.ListItem(
            label="..",
            label2="",
        )

        back_item.setProperty(
            "browser_kind",
            "back",
        )

        back_item.setProperty(
            "country",
            country,
        )

        back_item.setProperty(
            "vpn_status",
            "",
        )

        control.addItem(
            back_item
        )

        country_profiles = [
            profile
            for profile
            in available
            if (
                str(
                    profile.get(
                        "country",
                        "Unassigned",
                    )
                    or "Unassigned"
                ).strip()
                or "Unassigned"
            )
            == country
        ]

        country_profiles.sort(
            key=self._profile_sort_key
        )

        chosen_index = 0

        for index, profile in enumerate(
            country_profiles,
            start=1,
        ):
            profile_id = profile["id"]

            protocol = (
                self._profile_transport(
                    profile
                ).upper()
            )

            state = ""

            if profile_id == active_id:
                state = "ACTIVE"
                chosen_index = index

            elif (
                active_id is None
                and profile_id
                == preferred_id
            ):
                state = "FALLBACK"
                chosen_index = index

            item = xbmcgui.ListItem(
                label=profile["name"],
                label2=protocol,
            )

            item.setProperty(
                "browser_kind",
                "profile",
            )

            item.setProperty(
                "profile_id",
                profile_id,
            )

            item.setProperty(
                "country",
                country,
            )

            item.setProperty(
                "flag_path",
                _country_flag_path(
                    country
                ),
            )

            item.setProperty(
                "vpn_status",
                state,
            )

            control.addItem(
                item
            )

        control.selectItem(
            chosen_index
        )


    def _selected_provider_id(self):
        item = self.getControl(
            self.PROVIDER_LIST
        ).getSelectedItem()

        if not item:
            return None

        return item.getProperty(
            "provider_id"
        ) or None

    def _selected_profile_id(self):
        source_list = self.PROFILE_LIST

        if (
            not self._browser_country
            and getattr(
                self,
                "_vpn_last_root_list",
                self.PROFILE_LIST,
            )
            == self.RECENT_LIST
        ):
            source_list = self.RECENT_LIST

        item = self.getControl(
            source_list
        ).getSelectedItem()

        if not item:
            return None

        return item.getProperty(
            "profile_id"
        ) or None

    def _activate_profile(self):
        # Defensive guard against an immediate duplicate
        # activation callback. Normal list activation is owned
        # exclusively by onClick().
        now = time.monotonic()

        previous = getattr(
            self,
            "_profile_activation_time",
            0.0,
        )

        if now - previous < 0.35:
            return

        self._profile_activation_time = now

        source_list = (
            self.PROFILE_LIST
        )

        try:
            if (
                self.getFocusId()
                == self.RECENT_LIST
            ):
                source_list = (
                    self.RECENT_LIST
                )
        except Exception:
            pass

        item = self.getControl(
            source_list
        ).getSelectedItem()

        if not item:
            return

        kind = item.getProperty(
            "browser_kind"
        )

        if kind == "country":
            country = item.getProperty(
                "country"
            )

            if not country:
                return

            self._browser_country = (
                country
            )

            self._last_browser_country = (
                country
            )

            self._load_profiles(
                self._active_provider_id
            )

            self.setFocusId(
                self.PROFILE_LIST
            )

            return

        if kind == "back":
            self._last_browser_country = (
                self._browser_country
            )

            self._browser_country = None

            self._load_profiles(
                self._active_provider_id
            )

            self.setFocusId(
                self.PROFILE_LIST
            )

            return

        profile_id = (
            item.getProperty(
                "profile_id"
            )
            or None
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile["id"]
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        executor = getattr(
            BACKEND,
            "execute_handoff",
            None,
        )

        if not executor:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Protected profile switching "
                "is not available on this "
                "platform yet.",
            )
            return

        target_name = target.get(
            "name",
            profile_id,
        )

        #
        # Always ask the backend to prove the transaction is
        # safe before allowing any mutation.
        #
        try:
            preview = executor(
                target,
                dry_run=True,
            )

        except Exception as exc:
            xbmc.log(
                "Kodi VPN Manager: protected handoff validation "
                "raised an exception for {}: {}".format(
                    target_name,
                    exc,
                ),
                xbmc.LOGERROR,
            )
            DIALOG.ok(
                "Kodi VPN Manager",
                "Profile validation failed.\n\n"
                "{}".format(exc),
            )
            return

        if not preview.get("ok"):
            errors = (
                preview.get("errors")
                or []
            )

            detail = (
                str(errors[0])
                if errors
                else "No additional details."
            )

            validation_stage = preview.get(
                "stage",
                "preflight",
            )

            xbmc.log(
                "Kodi VPN Manager: protected handoff validation "
                "failed for {} at stage {}: {}".format(
                    target_name,
                    validation_stage,
                    detail,
                ),
                xbmc.LOGERROR,
            )

            DIALOG.ok(
                "Kodi VPN Manager",
                "Profile validation failed.\n\n"
                "Stage: {}\n\n{}".format(
                    validation_stage,
                    detail,
                ),
            )
            return

        action = preview.get("action")

        if action == "already_active":
            DIALOG.notification(
                "Kodi VPN Manager",
                "Already active: {}".format(
                    target_name
                ),
                time=2500,
                sound=False,
            )
            return

        if (
            action
            == "router_selection_unchanged"
        ):
            DIALOG.notification(
                "Kodi VPN Manager",
                "Already preferred fallback: "
                "{}".format(
                    target_name
                ),
                time=2500,
                sound=False,
            )
            return

        #
        # Changing the preferred fallback while the router VPN
        # is authoritative does not touch networking.
        #
        if action == "select_fallback":
            confirmed = True

        #
        # A local-to-local handoff changes the live tunnel.
        # Require an explicit confirmation.
        #
        elif action == "protected_switch":
            previous_id = preview.get(
                "previous_profile_id"
            )

            previous = next(
                (
                    profile
                    for profile
                    in profiles.profiles(
                        self._data
                    )
                    if profile.get("id")
                    == previous_id
                ),
                None,
            )

            previous_name = (
                previous.get("name")
                if previous
                else previous_id
                or "current VPN"
            )

            confirmed = DIALOG.yesno(
                "Kodi VPN Manager",
                "Switch local VPN from "
                "{} to {}?\n\n"
                "Traffic remains fail-closed. "
                "If the new VPN cannot be "
                "verified, the previous profile "
                "will be restored automatically."
                .format(
                    previous_name,
                    target_name,
                ),
            )

        else:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The backend returned an "
                "unsupported profile action:\n\n"
                "{}".format(
                    action or "unknown"
                ),
            )
            return

        if not confirmed:
            return

        #
        # Execute only after the dry-run path succeeded.
        #
        try:
            result = executor(
                target,
                dry_run=False,
            )

        except Exception as exc:
            xbmc.log(
                "Kodi VPN Manager: protected handoff "
                "raised an exception for {}: {}".format(
                    target_name,
                    exc,
                ),
                xbmc.LOGERROR,
            )
            DIALOG.ok(
                "Kodi VPN Manager",
                "Profile transaction failed "
                "before completion.\n\n"
                "{}".format(exc),
            )
            return

        #
        # Only a verified committed live handoff belongs in
        # Recent. Fallback-only selections and failed switches
        # are deliberately excluded.
        #
        if (
            result.get("ok")
            and result.get("stage")
            == "committed"
        ):
            try:
                _record_recent_profile(
                    profile_id
                )
            except Exception as exc:
                xbmc.log(
                    "VPN Manager: could not update "
                    "Recent profiles: {}".format(
                        exc
                    ),
                    xbmc.LOGWARNING,
                )

        #
        # Reload registry and verified live state regardless of
        # success/failure so the list never displays stale data.
        #
        try:
            self._data = profiles.load(
                REGISTRY
            )

            self._load_profiles(
                self._active_provider_id
            )

        except Exception:
            pass

        if result.get("ok"):
            stage = result.get("stage")

            if stage == "committed":
                xbmc.log(
                    "Kodi VPN Manager: protected handoff "
                    "committed successfully: {}".format(
                        target_name
                    ),
                    xbmc.LOGINFO,
                )

            if stage == "fallback_selected":
                DIALOG.notification(
                    "Kodi VPN Manager",
                    "Preferred fallback: "
                    "{}".format(
                        target_name
                    ),
                    time=3000,
                    sound=False,
                )

            elif stage == "committed":
                DIALOG.notification(
                    "Kodi VPN Manager",
                    "VPN active: {}".format(
                        target_name
                    ),
                    time=3000,
                    sound=False,
                )

            else:
                DIALOG.notification(
                    "Kodi VPN Manager",
                    "{}".format(
                        target_name
                    ),
                    time=2500,
                    sound=False,
                )

            return

        errors = (
            result.get("errors")
            or []
        )

        detail = (
            str(errors[0])
            if errors
            else "No additional details."
        )

        stage = result.get(
            "stage",
            "unknown",
        )

        rollback_stage = result.get(
            "rollback_stage"
        )
        fallback_attempted = bool(
            result.get("fallback_attempted")
        )
        fallback_profile_id = result.get(
            "fallback_profile_id"
        )
        fallback_restored = bool(
            result.get("fallback_restored")
        )

        if stage == "handoff_busy":
            xbmc.log(
                "Kodi VPN Manager: protected handoff for {} "
                "did not start because another protected VPN "
                "transaction is active: {}".format(
                    target_name,
                    detail,
                ),
                xbmc.LOGWARNING,
            )

            message = (
                "VPN switch did not start.\n\n"
                "Another protected VPN transaction is currently "
                "active. The existing VPN connection was not "
                "changed.\n\n"
                "{}"
            ).format(
                detail,
            )

        elif result.get("rolled_back"):
            xbmc.log(
                "Kodi VPN Manager: protected handoff failed "
                "for {} at stage {}; previous VPN restored "
                "at rollback stage {}: {}".format(
                    target_name,
                    stage,
                    rollback_stage or "rolled_back",
                    detail,
                ),
                xbmc.LOGWARNING,
            )

            message = (
                "VPN switch failed at stage:\n"
                "{}\n\n"
                "The previous VPN profile was "
                "restored automatically.\n\n"
                "{}"
            ).format(
                stage,
                detail,
            )

        elif fallback_restored:
            xbmc.log(
                "Kodi VPN Manager: protected handoff failed "
                "for {} at stage {}; rollback stage {}; "
                "emergency fallback {} restored verified "
                "VPN protection: {}".format(
                    target_name,
                    stage,
                    rollback_stage or "unknown",
                    fallback_profile_id or "unknown",
                    detail,
                ),
                xbmc.LOGWARNING,
            )

            message = (
                "VPN switch failed at stage:\n"
                "{}\n\n"
                "The previous VPN could not be restored, "
                "but the configured fallback VPN restored "
                "verified protection.\n\n"
                "{}"
            ).format(
                stage,
                detail,
            )

        elif fallback_attempted:
            xbmc.log(
                "Kodi VPN Manager: protected handoff failed "
                "for {} at stage {}; rollback stage {}; "
                "emergency fallback {} was attempted but "
                "did not restore verified protection; "
                "fail-closed protection retained: {}".format(
                    target_name,
                    stage,
                    rollback_stage or "unknown",
                    fallback_profile_id or "unknown",
                    detail,
                ),
                xbmc.LOGERROR,
            )

            message = (
                "VPN switch failed at stage:\n"
                "{}\n\n"
                "Neither the previous VPN nor the configured "
                "fallback VPN could be restored. Network "
                "protection remains fail-closed.\n\n"
                "{}"
            ).format(
                stage,
                detail,
            )

        else:
            xbmc.log(
                "Kodi VPN Manager: protected handoff failed "
                "for {} at stage {}; rollback stage {}; "
                "no emergency fallback was restored; "
                "fail-closed protection retained: {}".format(
                    target_name,
                    stage,
                    rollback_stage or "unknown",
                    detail,
                ),
                xbmc.LOGERROR,
            )

            message = (
                "VPN switch failed at stage:\n"
                "{}\n\n"
                "Automatic rollback was not confirmed and "
                "no fallback VPN restored protection. "
                "Network protection remains fail-closed.\n\n"
                "{}"
            ).format(
                stage,
                detail,
            )

        DIALOG.ok(
            "Kodi VPN Manager",
            message,
        )

    def _update_management_buttons(self):
        provider_context = (
            self._management_context
            == "provider"
        )

        labels = {
            self.ADD_BUTTON: (
                "Add Service"
                if provider_context
                else "Add"
            ),
            self.EDIT_BUTTON: (
                "Edit Service"
                if provider_context
                else "Edit"
            ),
            self.DELETE_BUTTON: (
                "Delete Service"
                if provider_context
                else "Delete"
            ),
        }

        for control_id, label in labels.items():
            try:
                self.getControl(
                    control_id
                ).setLabel(label)
            except Exception:
                pass


    def _set_management_context(
        self,
        context,
    ):
        if context not in (
            "provider",
            "profile",
        ):
            return

        self._management_context = context
        self._update_management_buttons()


    def _add_provider(self):
        name = DIALOG.input(
            "Service Name"
        ).strip()

        if not name:
            return

        if any(
            str(
                item.get("name", "")
            ).strip().casefold()
            == name.casefold()
            for item in profiles.providers(
                self._data
            )
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "A service with that name "
                "already exists.",
            )
            return

        provider_id = profiles.make_id(
            "provider-{}".format(name)
        )

        record = {
            "id": provider_id,
            "name": name,
            "enabled": True,
            "default_authentication_id":
                None,
            "metadata": {},
        }

        data = profiles.upsert_provider(
            self._data,
            record,
        )

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The service could not be "
                "created."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        self._set_management_context(
            "provider"
        )

        try:
            self.setFocusId(
                self.PROVIDER_LIST
            )
        except Exception:
            pass

        DIALOG.notification(
            "Kodi VPN Manager",
            "Service added: {}".format(
                name
            ),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _edit_selected_provider(self):
        provider_id = (
            self._selected_provider_id()
        )

        if not provider_id:
            return

        target = profiles.provider(
            self._data,
            provider_id,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected service could "
                "not be found.",
            )
            return

        current_name = target.get(
            "name",
            provider_id,
        )

        name = DIALOG.input(
            "Service Name",
            defaultt=current_name,
        ).strip()

        if not name:
            return

        if name == current_name:
            return

        if any(
            item.get("id") != provider_id
            and str(
                item.get("name", "")
            ).strip().casefold()
            == name.casefold()
            for item in profiles.providers(
                self._data
            )
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "A service with that name "
                "already exists.",
            )
            return

        updated = dict(target)
        updated["name"] = name

        data = profiles.upsert_provider(
            self._data,
            updated,
        )

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The service could not be "
                "updated."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        self._set_management_context(
            "provider"
        )

        try:
            self.setFocusId(
                self.PROVIDER_LIST
            )
        except Exception:
            pass

        DIALOG.notification(
            "Kodi VPN Manager",
            "Service renamed: {}".format(
                name
            ),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _delete_selected_provider(self):
        provider_id = (
            self._selected_provider_id()
        )

        if not provider_id:
            return

        target = profiles.provider(
            self._data,
            provider_id,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected service could "
                "not be found.",
            )
            return

        provider_profiles = (
            profiles.profiles_for_provider(
                self._data,
                provider_id,
            )
        )

        if provider_profiles:
            count = len(
                provider_profiles
            )

            DIALOG.ok(
                "Kodi VPN Manager",
                "This service still contains "
                "{} profile{}.\n\n"
                "Move or delete those profiles "
                "before deleting the service."
                .format(
                    count,
                    "" if count == 1 else "s",
                ),
            )
            return

        name = target.get(
            "name",
            provider_id,
        )

        if not DIALOG.yesno(
            "Kodi VPN Manager",
            "Delete service '{}'?"
            "\n\n"
            "The service must be empty."
            .format(name),
        ):
            return

        provider_auth = (
            profiles.authentications(
                self._data,
                provider_id,
            )
        )

        candidate_secret_refs = {
            auth.get("secret_ref")
            for auth in provider_auth
            if auth.get("secret_ref")
        }

        data = profiles.remove_provider(
            self._data,
            provider_id,
        )

        if profiles.provider(
            data,
            provider_id,
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The service could not be "
                "removed.",
            )
            return

        secret_before = (
            secret_store.load(
                SECRET_STORE
            )
        )

        secret_after = secret_before

        remaining_refs = {
            auth.get("secret_ref")
            for auth in profiles.authentications(
                data
            )
            if auth.get("secret_ref")
        }

        refs_to_remove = (
            candidate_secret_refs
            - remaining_refs
        )

        for secret_ref in refs_to_remove:
            secret_after = (
                secret_store.remove_secret(
                    secret_after,
                    secret_ref,
                )
            )

        secrets_changed = bool(
            refs_to_remove
        )

        if secrets_changed:
            try:
                secret_store.save(
                    SECRET_STORE,
                    secret_after,
                )

            except Exception as exc:
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The service was not deleted "
                    "because its stored credentials "
                    "could not be cleaned up."
                    "\n\n{}".format(exc),
                )
                return

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            if secrets_changed:
                try:
                    secret_store.save(
                        SECRET_STORE,
                        secret_before,
                    )
                except Exception:
                    pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The service could not be "
                "removed."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers()

        self._set_management_context(
            "provider"
        )

        remaining = profiles.providers(
            self._data
        )

        try:
            self.setFocusId(
                self.PROVIDER_LIST
                if remaining
                else self.ADD_BUTTON
            )
        except Exception:
            pass

        DIALOG.notification(
            "Kodi VPN Manager",
            "Service deleted: {}".format(
                name
            ),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _add_openvpn_profile(self):
        if (
            "openvpn"
            not in supported_profile_types()
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "OpenVPN profile creation is not "
                "supported on this platform.",
            )
            return

        name = DIALOG.input(
            "Profile Name"
        ).strip()

        if not name:
            return

        import ipaddress as _ipaddress
        import re as _re
        import socket as _socket

        while True:
            host = DIALOG.input(
                "VPN Server",
            ).strip()

            if not host:
                return

            if (
                "://" in host
                or "/" in host
                or "\\" in host
                or any(
                    ch.isspace()
                    for ch in host
                )
            ):
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "Enter only a VPN server "
                    "hostname or IP address.\n\n"
                    "Do not enter a URL, path, "
                    "or port number.",
                )
                continue

            is_ip = False

            try:
                _ipaddress.ip_address(host)
                is_ip = True

            except ValueError:
                dns_host = host.rstrip(".")

                try:
                    ascii_host = (
                        dns_host
                        .encode("idna")
                        .decode("ascii")
                    )
                except Exception:
                    ascii_host = ""

                labels = ascii_host.split(".")

                valid_hostname = (
                    bool(ascii_host)
                    and len(ascii_host) <= 253
                    and all(
                        len(label) <= 63
                        and _re.fullmatch(
                            r"[A-Za-z0-9]"
                            r"(?:[A-Za-z0-9-]{0,61}"
                            r"[A-Za-z0-9])?",
                            label,
                        )
                        for label in labels
                    )
                )

                if not valid_hostname:
                    DIALOG.ok(
                        "Kodi VPN Manager",
                        "The VPN server name is "
                        "not valid.",
                    )
                    continue

                host = ascii_host

            if not is_ip:
                try:
                    _socket.getaddrinfo(
                        host,
                        None,
                    )

                except _socket.gaierror:
                    choice = DIALOG.select(
                        "Server could not be resolved",
                        [
                            "Retry server name",
                            "Save Anyway",
                            "Cancel",
                        ],
                    )

                    if choice == 0:
                        continue

                    if choice != 1:
                        return

            break

        port_text = DIALOG.input(
            "VPN Port",
            defaultt="1194",
        ).strip()

        if not port_text:
            return

        try:
            port = int(port_text)
        except ValueError:
            port = 0

        if not 1 <= port <= 65535:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The VPN port must be between "
                "1 and 65535.",
            )
            return

        protocol_index = DIALOG.select(
            "VPN Protocol",
            [
                "UDP",
                "TCP",
            ],
        )

        if protocol_index < 0:
            return

        protocol = (
            "udp"
            if protocol_index == 0
            else "tcp"
        )

        provider_id = (
            self._selected_provider_id()
            or self._active_provider_id
            or "legacy"
        )

        #
        # Keep the ID compatible with the existing
        # OpenVPN profile naming convention without
        # depending on UI-visible profile names.
        #
        import time as _time

        stamp = int(_time.time())
        suffix = int(
            _time.time() * 1000000
        ) % 1000000

        while True:
            profile_id = (
                "openvpn-{}-{:06d}".format(
                    stamp,
                    suffix,
                )
            )

            profile_dir = os.path.join(
                MANAGED_PROFILE_ROOT,
                profile_id,
            )

            if not os.path.exists(
                profile_dir
            ):
                break

            suffix = (
                suffix + 1
            ) % 1000000

        config_path = os.path.join(
            profile_dir,
            "profile.ovpn",
        )

        config_text = (
            "client\n"
            "dev tun\n"
            "proto {protocol}\n"
            "remote {host} {port}\n"
            "resolv-retry infinite\n"
            "nobind\n"
            "persist-key\n"
            "persist-tun\n"
            "verb 3\n"
        ).format(
            protocol=protocol,
            host=host,
            port=port,
        )

        try:
            os.makedirs(
                profile_dir,
                exist_ok=False,
            )

            with open(
                config_path,
                "x",
                encoding="utf-8",
            ) as f:
                f.write(config_text)

        except Exception as exc:
            try:
                if os.path.isfile(
                    config_path
                ):
                    os.unlink(config_path)

                if (
                    os.path.isdir(profile_dir)
                    and not os.listdir(
                        profile_dir
                    )
                ):
                    os.rmdir(profile_dir)

            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The managed OpenVPN profile "
                "could not be created."
                "\n\n{}".format(exc),
            )
            return

        item = {
            "id": profile_id,
            "name": name,
            "type": "openvpn",
            "path": config_path,
            "enabled": True,
            "provider_id": provider_id,
            "authentication_id": None,
            "protocol_options": {},
        }

        data = profiles.upsert(
            self._data,
            item,
        )

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            try:
                if os.path.isfile(
                    config_path
                ):
                    os.unlink(config_path)

                if (
                    os.path.isdir(profile_dir)
                    and not os.listdir(
                        profile_dir
                    )
                ):
                    os.rmdir(profile_dir)

            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The profile could not be "
                "saved to the registry."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(
            control.size()
        ):
            row = control.getListItem(
                index
            )

            if (
                row
                and row.getProperty(
                    "profile_id"
                ) == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Added: {}".format(name),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _import_vpn_profile(self):
        supported = supported_profile_types()

        choices = []
        actions = []

        if "openvpn" in supported:
            choices.append("OpenVPN")
            actions.append(self._import_openvpn_profile)

        if "wireguard" in supported:
            choices.append("WireGuard")
            actions.append(self._import_wireguard_profile)

        if not actions:
            DIALOG.ok(
                "Kodi VPN Manager",
                "VPN profile import is not supported "
                "on this platform.",
            )
            return

        if len(actions) == 1:
            actions[0]()
            return

        choice = DIALOG.select(
            "Import VPN Profiles",
            choices,
        )

        if choice < 0:
            return

        actions[choice]()


    def _import_wireguard_profile(self):
        if (
            "wireguard"
            not in supported_profile_types()
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "WireGuard import is not supported "
                "on this platform.",
            )
            return

        provider_id = (
            self._selected_provider_id()
            or self._active_provider_id
        )

        if not provider_id:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Select a provider before importing "
                "a WireGuard profile.",
            )
            return

        source_path = DIALOG.browseSingle(
            1,
            "Import WireGuard Profile",
            "",
            ".conf",
            False,
            False,
            "",
        )

        if not source_path:
            return

        source_path = xbmcvfs.translatePath(
            source_path
        )

        if not os.path.isfile(source_path):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected WireGuard profile "
                "could not be found.",
            )
            return

        default_name = os.path.splitext(
            os.path.basename(source_path)
        )[0]

        name = DIALOG.input(
            "Profile Name",
            defaultt=default_name,
        ).strip()

        if not name:
            return

        country = DIALOG.input(
            "Country",
        ).strip()

        if not country:
            return

        country = _country_display_name(
            country
        )

        city = DIALOG.input(
            "City (optional)",
        ).strip()

        country_key = _country_flag_key(country)
        city_key = _country_flag_key(city)
        registry_data = profiles.load(REGISTRY)
        duplicates = []

        if city_key:
            for existing in profiles.profiles(registry_data):
                options = existing.get("protocol_options") or {}
                if (
                    str(existing.get("provider_id", "")) == str(provider_id)
                    and str(existing.get("type", "")).strip().lower() == "wireguard"
                    and _country_flag_key(existing.get("country", "")) == country_key
                    and _country_flag_key(options.get("city", "")) == city_key
                ):
                    duplicates.append(existing)

        replace_existing = None
        if duplicates:
            choices = [
                "Replace: {}".format(
                    str(item.get("name") or "Unnamed profile").strip()
                )
                for item in duplicates
            ]
            skip_choice = len(choices)
            separate_choice = skip_choice + 1
            choices.extend((
                "Keep existing and skip import",
                "Import as a separate profile",
            ))
            choice = DIALOG.select(
                "Matching WireGuard profile found",
                choices,
            )
            if choice < 0 or choice == skip_choice:
                return
            if choice != separate_choice:
                replace_existing = duplicates[choice]

        storage_id = profiles.make_id("wireguard")
        profile_id = (
            replace_existing.get("id")
            if replace_existing
            else storage_id
        )
        profile_dir = os.path.join(
            MANAGED_PROFILE_ROOT,
            storage_id,
        )

        config_path = os.path.join(
            profile_dir,
            "profile.conf",
        )

        try:
            os.makedirs(
                profile_dir,
                exist_ok=False,
            )

            with open(
                source_path,
                "rb",
            ) as source:
                config_bytes = source.read()

            with open(
                config_path,
                "xb",
            ) as target:
                target.write(config_bytes)

            try:
                os.chmod(
                    config_path,
                    0o600,
                )
            except OSError:
                pass

        except Exception as exc:
            try:
                if os.path.isfile(config_path):
                    os.unlink(config_path)

                if (
                    os.path.isdir(profile_dir)
                    and not os.listdir(profile_dir)
                ):
                    os.rmdir(profile_dir)

            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The WireGuard profile could not "
                "be imported.\n\n{}".format(exc),
            )
            return

        keepalive = (
            self._wireguard_persistent_keepalive(
                config_path
            )
        )

        protocol_options = {
            "city": city,
        }

        if keepalive is not None:
            protocol_options[
                "persistent_keepalive"
            ] = keepalive
            protocol_options[
                "persistent_keepalive_default"
            ] = keepalive
            protocol_options[
                "persistent_keepalive_source"
            ] = "provider"

        item = {
            "id": profile_id,
            "name": name,
            "type": "wireguard",
            "path": config_path,
            "enabled": True,
            "provider_id": provider_id,
            "authentication_id": None,
            "country": country,
            "protocol_options": protocol_options,
        }

        check = BACKEND.preflight_profile(
            item
        )

        if not check.get("ok"):
            try:
                os.unlink(config_path)
                os.rmdir(profile_dir)
            except Exception:
                pass

            errors = check.get("errors") or [
                "WireGuard profile validation failed"
            ]

            DIALOG.ok(
                "Kodi VPN Manager",
                "The WireGuard profile is not "
                "compatible with managed protection."
                "\n\n{}".format(
                    "\n".join(errors)
                ),
            )
            return

        data = profiles.upsert(
            registry_data,
            item,
        )

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            try:
                os.unlink(config_path)
                os.rmdir(profile_dir)
            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The WireGuard profile could not "
                "be saved to the registry."
                "\n\n{}".format(exc),
            )
            return

        if replace_existing:
            old_path = str(replace_existing.get("path") or "")
            managed_root = os.path.abspath(MANAGED_PROFILE_ROOT)
            old_path_abs = os.path.abspath(old_path) if old_path else ""
            if (
                old_path_abs.startswith(managed_root + os.sep)
                and os.path.dirname(old_path_abs) != os.path.abspath(profile_dir)
            ):
                try:
                    import shutil as _shutil
                    _shutil.rmtree(os.path.dirname(old_path_abs))
                except Exception:
                    pass

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(control.size()):
            row = control.getListItem(index)

            if (
                row
                and row.getProperty("profile_id")
                == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "{}: {}".format(
                "Replaced" if replace_existing else "Imported",
                name,
            ),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _import_openvpn_profile(self):
        choice = DIALOG.select(
            "Import OpenVPN Profiles",
            [
                "Single .ovpn profile",
                "Batch import ZIP",
            ],
        )

        if choice == 0:
            self._import_single_openvpn_profile()
            return

        if choice == 1:
            self._import_openvpn_zip()
            return


    def _import_openvpn_zip(self):
        if (
            "openvpn"
            not in supported_profile_types()
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "OpenVPN import is not supported "
                "on this platform.",
            )
            return

        provider_id = (
            self._selected_provider_id()
            or self._active_provider_id
        )

        if not provider_id:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Select a provider before importing "
                "OpenVPN profiles.",
            )
            return

        source_path = DIALOG.browseSingle(
            1,
            "Import OpenVPN ZIP",
            "",
            ".zip",
            False,
            False,
            "",
        )

        if not source_path:
            return

        source_path = xbmcvfs.translatePath(
            source_path
        )

        if not os.path.isfile(source_path):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected ZIP archive could "
                "not be opened.",
            )
            return

        if not zipfile.is_zipfile(source_path):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected file is not a valid "
                "ZIP archive.",
            )
            return

        #
        # Archive limits protect Kodi from malformed or
        # unexpectedly huge archives.
        #
        MAX_MEMBERS = 5000
        MAX_ARCHIVE_BYTES = (
            256 * 1024 * 1024
        )
        MAX_PROFILE_BYTES = (
            2 * 1024 * 1024
        )
        MAX_COMPANION_BYTES = (
            16 * 1024 * 1024
        )

        file_directives = {
            "auth-user-pass",
            "ca",
            "cert",
            "crl-verify",
            "dh",
            "extra-certs",
            "key",
            "pkcs12",
            "tls-auth",
            "tls-crypt",
            "tls-crypt-v2",
        }


        #
        # PureVPN Recommended-CA2 location metadata.
        #
        # Country is decoded only for PureVPN hostnames matching
        # their current CA2 naming convention. Explicit city
        # codes below are based on PureVPN's published server
        # location table.
        #
        PUREVPN_COUNTRIES = {
            "ae": "United Arab Emirates",
            "af": "Afghanistan",
            "al": "Albania",
            "ao": "Angola",
            "ar": "Argentina",
            "at": "Austria",
            "au": "Australia",
            "aw": "Aruba",
            "bb": "Barbados",
            "bd": "Bangladesh",
            "be": "Belgium",
            "bg": "Bulgaria",
            "bh": "Bahrain",
            "bm": "Bermuda",
            "bn": "Brunei",
            "bo": "Bolivia",
            "br": "Brazil",
            "bs": "Bahamas",
            "ca": "Canada",
            "ch": "Switzerland",
            "cl": "Chile",
            "cn": "China",
            "cz": "Czech Republic",
            "de": "Germany",
            "dk": "Denmark",
            "dz": "Algeria",
            "ee": "Estonia",
            "eg": "Egypt",
            "es": "Spain",
            "fi": "Finland",
            "fr": "France",
            "gr": "Greece",
            "hk": "Hong Kong",
            "hu": "Hungary",
            "ie": "Ireland",
            "in": "India",
            "it": "Italy",
            "jp": "Japan",
            "kr": "South Korea",
            "ky": "Cayman Islands",
            "lt": "Lithuania",
            "lu": "Luxembourg",
            "lv": "Latvia",
            "mc": "Monaco",
            "md": "Moldova",
            "ng": "Nigeria",
            "nl": "Netherlands",
            "no": "Norway",
            "om": "Oman",
            "pa": "Panama",
            "ph": "Philippines",
            "pl": "Poland",
            "pr": "Puerto Rico",
            "pt": "Portugal",
            "ro": "Romania",
            "rs": "Serbia",
            "ru": "Russia",
            "se": "Sweden",
            "sg": "Singapore",
            "sk": "Slovakia",
            "tr": "Turkey",
            "uk": "United Kingdom",
            "us": "United States",
            "vg": "British Virgin Islands",
            "vn": "Vietnam",
            "za": "South Africa",
        }

        PUREVPN_CITIES = {
            "aupe": "Perth",
            "ausd": "Sydney",
            "aume": "Melbourne",
            "aubn": "Brisbane",

            "cato": "Toronto",
            "cav": "Vancouver",

            "ukl": "London",
            "ukm": "Manchester",

            "usfl": "Miami",
            "usphx": "Phoenix",
            "usca": "Los Angeles",
            "usil": "Chicago",
            "usnj": "New Jersey",
            "usny": "New York",
            "ustx": "Houston",
            "usga": "Atlanta",
            "uswdc": "Washington DC",
            "usva": "Ashburn",
            "ussf": "San Francisco",
            "ussa": "Seattle",
            "usut": "Salt Lake City",
        }


        def purevpn_location(
            hostname,
        ):
            host = str(
                hostname or ""
            ).strip().lower().rstrip(".")

            if not (
                host.endswith(
                    ".ptoserver.com"
                )
                or host.endswith(
                    ".pointtoserver.com"
                )
            ):
                return {
                    "country":
                        "Unassigned",
                    "city": "",
                    "location_code": "",
                }

            first_label = host.split(
                ".",
                1,
            )[0]

            match = re.match(
                r"^([a-z]{2})"
                r"([a-z]*?)"
                r"\d+"
                r"-auto-",
                first_label,
            )

            if not match:
                return {
                    "country":
                        "Unassigned",
                    "city": "",
                    "location_code": "",
                }

            country_code = (
                match.group(1)
            )

            suffix = (
                match.group(2)
                or ""
            )

            location_code = (
                country_code
                + suffix
            )

            return {
                "country":
                    PUREVPN_COUNTRIES.get(
                        country_code,
                        "Unassigned",
                    ),
                "city":
                    PUREVPN_CITIES.get(
                        location_code,
                        "",
                    ),
                "location_code":
                    location_code,
            }


        def normalize_protocol(
            value,
            hostname="",
        ):
            proto = str(
                value or ""
            ).strip().lower()

            if proto.startswith("tcp"):
                return "tcp"

            if proto.startswith("udp"):
                return "udp"

            host = str(
                hostname or ""
            ).lower()

            if "-tcp-" in host:
                return "tcp"

            if "-udp-" in host:
                return "udp"

            return ""


        def verify_profile_remotes(
            remotes,
            default_protocol,
        ):
            results = []

            for remote in remotes:
                if not remote:
                    return (
                        False,
                        "remote directive has no host",
                        [],
                    )

                host = str(
                    remote[0]
                ).strip()

                if not host:
                    return (
                        False,
                        "remote directive has no host",
                        [],
                    )

                port = 1194

                if len(remote) >= 2:
                    try:
                        port = int(
                            remote[1]
                        )
                    except Exception:
                        return (
                            False,
                            (
                                "invalid port for {}"
                            ).format(
                                host
                            ),
                            [],
                        )

                if not (
                    1 <= port <= 65535
                ):
                    return (
                        False,
                        (
                            "invalid port for {}"
                        ).format(
                            host
                        ),
                        [],
                    )

                remote_protocol = (
                    remote[2]
                    if len(remote) >= 3
                    else default_protocol
                )

                protocol = normalize_protocol(
                    remote_protocol,
                    host,
                )

                socket_type = (
                    socket.SOCK_STREAM
                    if protocol == "tcp"
                    else socket.SOCK_DGRAM
                )

                try:
                    answers = socket.getaddrinfo(
                        host,
                        port,
                        socket.AF_INET,
                        socket_type,
                    )

                except Exception as exc:
                    return (
                        False,
                        (
                            "DNS failed for {}: {}"
                        ).format(
                            host,
                            exc,
                        ),
                        [],
                    )

                addresses = []

                for answer in answers:
                    try:
                        address = answer[4][0]
                    except Exception:
                        continue

                    if (
                        address
                        and address
                        not in addresses
                    ):
                        addresses.append(
                            address
                        )

                if not addresses:
                    return (
                        False,
                        (
                            "DNS returned no IPv4 "
                            "address for {}"
                        ).format(
                            host
                        ),
                        [],
                    )

                verification = "dns"

                if protocol == "tcp":
                    reachable = False

                    for address in addresses:
                        sock = None

                        try:
                            sock = socket.create_connection(
                                (
                                    address,
                                    port,
                                ),
                                timeout=1.5,
                            )

                            reachable = True
                            break

                        except Exception:
                            pass

                        finally:
                            try:
                                if sock is not None:
                                    sock.close()
                            except Exception:
                                pass

                    if not reachable:
                        return (
                            False,
                            (
                                "TCP endpoint did not "
                                "accept a connection: "
                                "{}:{}"
                            ).format(
                                host,
                                port,
                            ),
                            [],
                        )

                    verification = (
                        "dns+tcp-connect"
                    )

                results.append(
                    {
                        "host": host,
                        "port": port,
                        "protocol":
                            protocol,
                        "addresses":
                            addresses,
                        "verification":
                            verification,
                    }
                )

            return (
                True,
                "",
                results,
            )

        def safe_member_name(name):
            value = str(
                name or ""
            ).replace(
                "\\",
                "/",
            )

            if not value:
                return ""

            if value.startswith("/"):
                return ""

            if re.match(
                r"^[A-Za-z]:",
                value,
            ):
                return ""

            normalized = posixpath.normpath(
                value
            )

            if normalized in (
                "",
                ".",
                "..",
            ):
                return ""

            if normalized.startswith("../"):
                return ""

            return normalized

        def ignored_member(name):
            parts = name.split("/")

            base = (
                parts[-1]
                if parts
                else ""
            )

            if "__MACOSX" in parts:
                return True

            if base == ".DS_Store":
                return True

            if base.startswith("._"):
                return True

            return False

        def is_symlink(info):
            mode = (
                info.external_attr >> 16
            ) & 0xFFFF

            return (
                mode & 0o170000
            ) == 0o120000

        def analyze_profile(
            member_name,
            profile_bytes,
            archive_files,
        ):
            try:
                profile_text = profile_bytes.decode(
                    "utf-8",
                    errors="replace",
                )
            except Exception as exc:
                return (
                    None,
                    "could not decode profile: {}".format(
                        exc
                    ),
                )

            source_lines = (
                profile_text.splitlines(
                    keepends=True
                )
            )

            remotes = []
            companions = []
            parse_errors = []
            profile_protocol = ""

            profile_directory = (
                posixpath.dirname(
                    member_name
                )
            )

            for line_number, raw in enumerate(
                source_lines,
                1,
            ):
                stripped = raw.strip()

                if (
                    not stripped
                    or stripped.startswith("#")
                    or stripped.startswith(";")
                    or stripped.startswith("<")
                ):
                    continue

                try:
                    parts = shlex.split(
                        stripped,
                        comments=False,
                        posix=True,
                    )

                except ValueError as exc:
                    parse_errors.append(
                        "line {}: {}".format(
                            line_number,
                            exc,
                        )
                    )
                    continue

                if not parts:
                    continue

                key = parts[0].lower()

                if (
                    key == "proto"
                    and len(parts) >= 2
                ):
                    profile_protocol = (
                        parts[1].strip()
                    )

                if key == "remote":
                    if len(parts) < 2:
                        parse_errors.append(
                            "line {}: remote has no host".format(
                                line_number
                            )
                        )
                    else:
                        remotes.append(
                            parts[1:]
                        )

                if (
                    key in file_directives
                    and len(parts) >= 2
                ):
                    reference = (
                        parts[1].strip()
                    )

                    if (
                        not reference
                        or reference == "[inline]"
                    ):
                        continue

                    reference_normalized = (
                        reference.replace(
                            "\\",
                            "/",
                        )
                    )

                    if (
                        reference_normalized.startswith(
                            "/"
                        )
                        or re.match(
                            r"^[A-Za-z]:",
                            reference_normalized,
                        )
                    ):
                        return (
                            None,
                            (
                                "absolute external file "
                                "reference: {}"
                            ).format(
                                reference
                            ),
                        )

                    #
                    # Keep imported companion files beneath
                    # the managed profile directory.
                    #
                    relative_normalized = (
                        posixpath.normpath(
                            reference_normalized
                        )
                    )

                    if (
                        relative_normalized in (
                            "",
                            ".",
                            "..",
                        )
                        or relative_normalized.startswith(
                            "../"
                        )
                    ):
                        return (
                            None,
                            (
                                "external file escapes "
                                "profile directory: {}"
                            ).format(
                                reference
                            ),
                        )

                    archive_reference = (
                        posixpath.normpath(
                            posixpath.join(
                                profile_directory,
                                relative_normalized,
                            )
                        )
                    )

                    if (
                        not safe_member_name(
                            archive_reference
                        )
                    ):
                        return (
                            None,
                            (
                                "unsafe external file "
                                "reference: {}"
                            ).format(
                                reference
                            ),
                        )

                    if (
                        archive_reference
                        not in archive_files
                    ):
                        return (
                            None,
                            (
                                "missing external file: {}"
                            ).format(
                                reference
                            ),
                        )

                    companions.append(
                        (
                            relative_normalized,
                            archive_reference,
                        )
                    )

            if parse_errors:
                return (
                    None,
                    parse_errors[0],
                )

            if not remotes:
                return (
                    None,
                    "no remote server directive",
                )

            #
            # Remove repeated companion references while
            # preserving their first-seen order.
            #
            unique_companions = []
            seen_companions = set()

            for item in companions:
                if item in seen_companions:
                    continue

                seen_companions.add(item)
                unique_companions.append(item)

            return (
                {
                    "text": profile_text,
                    "bytes": profile_bytes,
                    "companions":
                        unique_companions,
                    "remotes":
                        remotes,
                    "protocol":
                        profile_protocol,
                },
                "",
            )

        try:
            archive = zipfile.ZipFile(
                source_path,
                "r",
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Could not open the ZIP archive."
                "\n\n{}".format(exc),
            )
            return

        created_dirs = []

        try:
            infos = archive.infolist()

            if len(infos) > MAX_MEMBERS:
                raise RuntimeError(
                    "Archive contains too many files."
                )

            total_size = sum(
                int(info.file_size or 0)
                for info in infos
            )

            if total_size > MAX_ARCHIVE_BYTES:
                raise RuntimeError(
                    "Archive is too large after extraction."
                )

            archive_files = {}
            profile_members = []

            for info in infos:
                if info.is_dir():
                    continue

                name = safe_member_name(
                    info.filename
                )

                if not name:
                    continue

                if ignored_member(name):
                    continue

                if is_symlink(info):
                    continue

                if name in archive_files:
                    #
                    # Do not allow one ZIP entry to shadow
                    # another normalized path.
                    #
                    continue

                archive_files[name] = info

                if name.lower().endswith(
                    ".ovpn"
                ):
                    profile_members.append(
                        name
                    )

            profile_members.sort(
                key=lambda item: item.lower()
            )

            if not profile_members:
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The ZIP archive contains no "
                    ".ovpn profiles.",
                )
                return

            data = profiles.load(
                REGISTRY
            )

            existing_hashes = set()
            used_names = set()

            for existing in profiles.profiles(
                data
            ):
                if (
                    str(
                        existing.get(
                            "provider_id",
                            "",
                        )
                    )
                    != provider_id
                ):
                    continue

                existing_name = str(
                    existing.get(
                        "name",
                        "",
                    )
                ).strip()

                if existing_name:
                    used_names.add(
                        existing_name.casefold()
                    )

                if (
                    str(
                        existing.get(
                            "type",
                            "",
                        )
                    ).lower()
                    != "openvpn"
                ):
                    continue

                existing_path = str(
                    existing.get(
                        "path",
                        "",
                    )
                ).strip()

                if not existing_path:
                    continue

                try:
                    with open(
                        existing_path,
                        "rb",
                    ) as handle:
                        digest = hashlib.sha256(
                            handle.read()
                        ).hexdigest()

                    existing_hashes.add(
                        digest
                    )

                except Exception:
                    pass

            imported = []
            skipped = []
            failed = []

            tcp_verified = 0
            udp_dns_verified = 0
            locations_identified = 0

            batch_hashes = set()

            for member_name in profile_members:
                info = archive_files[
                    member_name
                ]

                display_source = (
                    posixpath.basename(
                        member_name
                    )
                )

                if (
                    int(info.file_size or 0)
                    > MAX_PROFILE_BYTES
                ):
                    failed.append(
                        (
                            display_source,
                            "profile is too large",
                        )
                    )
                    continue

                try:
                    profile_bytes = archive.read(
                        info
                    )

                except Exception as exc:
                    failed.append(
                        (
                            display_source,
                            "read failed: {}".format(
                                exc
                            ),
                        )
                    )
                    continue

                digest = hashlib.sha256(
                    profile_bytes
                ).hexdigest()

                if (
                    digest in existing_hashes
                    or digest in batch_hashes
                ):
                    skipped.append(
                        (
                            display_source,
                            "duplicate profile",
                        )
                    )
                    continue

                analysis, reason = (
                    analyze_profile(
                        member_name,
                        profile_bytes,
                        archive_files,
                    )
                )

                if not analysis:
                    failed.append(
                        (
                            display_source,
                            reason,
                        )
                    )
                    continue

                (
                    verified,
                    verify_reason,
                    remote_results,
                ) = verify_profile_remotes(
                    analysis["remotes"],
                    analysis["protocol"],
                )

                if not verified:
                    failed.append(
                        (
                            display_source,
                            verify_reason,
                        )
                    )
                    continue

                primary_remote = (
                    remote_results[0]
                )

                location = purevpn_location(
                    primary_remote["host"]
                )

                country = location[
                    "country"
                ]

                city = location[
                    "city"
                ]

                location_code = location[
                    "location_code"
                ]

                protocol = primary_remote[
                    "protocol"
                ]

                resolved_ipv4 = []

                for remote_result in (
                    remote_results
                ):
                    for address in remote_result[
                        "addresses"
                    ]:
                        if (
                            address
                            not in resolved_ipv4
                        ):
                            resolved_ipv4.append(
                                address
                            )

                if protocol == "tcp":
                    tcp_verified += 1

                elif protocol == "udp":
                    udp_dns_verified += 1

                if country != "Unassigned":
                    locations_identified += 1

                base_name = os.path.splitext(
                    display_source
                )[0].strip()

                if (
                    country != "Unassigned"
                ):
                    location_label = country

                    if city:
                        location_label += (
                            " - " + city
                        )
                    else:
                        location_label += " Auto"

                    protocol_label = (
                        protocol.upper()
                        if protocol
                        else "OpenVPN"
                    )

                    base_name = (
                        "{} [{}]".format(
                            location_label,
                            protocol_label,
                        )
                    )

                if not base_name:
                    base_name = "OpenVPN Profile"

                profile_name = base_name
                suffix = 2

                while (
                    profile_name.casefold()
                    in used_names
                ):
                    profile_name = (
                        "{} ({})".format(
                            base_name,
                            suffix,
                        )
                    )
                    suffix += 1

                profile_id = ""

                for _ in range(100):
                    candidate = profiles.make_id(
                        "openvpn"
                    )

                    candidate_dir = os.path.join(
                        MANAGED_PROFILE_ROOT,
                        candidate,
                    )

                    if (
                        candidate
                        not in {
                            item.get("id")
                            for item in imported
                        }
                        and not os.path.exists(
                            candidate_dir
                        )
                    ):
                        profile_id = candidate
                        break

                    time.sleep(0.002)

                if not profile_id:
                    failed.append(
                        (
                            display_source,
                            "could not allocate profile ID",
                        )
                    )
                    continue

                destination_dir = os.path.join(
                    MANAGED_PROFILE_ROOT,
                    profile_id,
                )

                destination_path = os.path.join(
                    destination_dir,
                    "profile.ovpn",
                )

                try:
                    os.makedirs(
                        destination_dir,
                        exist_ok=False,
                    )

                    created_dirs.append(
                        destination_dir
                    )

                    with open(
                        destination_path,
                        "wb",
                    ) as handle:
                        handle.write(
                            analysis["bytes"]
                        )

                    try:
                        os.chmod(
                            destination_path,
                            0o600,
                        )
                    except Exception:
                        pass

                    for (
                        relative_name,
                        archive_name,
                    ) in analysis[
                        "companions"
                    ]:
                        companion_info = (
                            archive_files[
                                archive_name
                            ]
                        )

                        if (
                            int(
                                companion_info.file_size
                                or 0
                            )
                            > MAX_COMPANION_BYTES
                        ):
                            raise RuntimeError(
                                (
                                    "companion file is "
                                    "too large: {}"
                                ).format(
                                    relative_name
                                )
                            )

                        destination_companion = (
                            os.path.join(
                                destination_dir,
                                *relative_name.split(
                                    "/"
                                )
                            )
                        )

                        destination_parent = (
                            os.path.dirname(
                                destination_companion
                            )
                        )

                        if destination_parent:
                            os.makedirs(
                                destination_parent,
                                exist_ok=True,
                            )

                        companion_bytes = (
                            archive.read(
                                companion_info
                            )
                        )

                        with open(
                            destination_companion,
                            "wb",
                        ) as handle:
                            handle.write(
                                companion_bytes
                            )

                        try:
                            os.chmod(
                                destination_companion,
                                0o600,
                            )
                        except Exception:
                            pass

                    profile = {
                        "id": profile_id,
                        "name": profile_name,
                        "type": "openvpn",
                        "path": destination_path,
                        "enabled": True,
                        "provider_id":
                            provider_id,
                        #
                        # None intentionally inherits the
                        # provider's default credentials.
                        #
                        "authentication_id":
                            None,
                        "country":
                            country,
                        "protocol_options": {
                            "protocol":
                                protocol,
                            "remote_host":
                                primary_remote[
                                    "host"
                                ],
                            "remote_port":
                                primary_remote[
                                    "port"
                                ],
                            "resolved_ipv4":
                                resolved_ipv4,
                            "location_code":
                                location_code,
                            "city":
                                city,
                            "verification":
                                primary_remote[
                                    "verification"
                                ],
                            "verified_at":
                                int(time.time()),
                        },
                    }

                    imported.append(
                        profile
                    )

                    used_names.add(
                        profile_name.casefold()
                    )

                    existing_hashes.add(
                        digest
                    )

                    batch_hashes.add(
                        digest
                    )

                except Exception as exc:
                    failed.append(
                        (
                            display_source,
                            str(exc),
                        )
                    )

                    try:
                        import shutil as _shutil

                        if os.path.isdir(
                            destination_dir
                        ):
                            _shutil.rmtree(
                                destination_dir
                            )

                        if (
                            destination_dir
                            in created_dirs
                        ):
                            created_dirs.remove(
                                destination_dir
                            )

                    except Exception:
                        pass

            if imported:
                new_data = data

                for profile in imported:
                    new_data = profiles.upsert(
                        new_data,
                        profile,
                    )

                if not profiles.selected_profile(
                    new_data
                ):
                    new_data = profiles.set_selected(
                        new_data,
                        imported[0]["id"],
                    )

                try:
                    #
                    # One registry write commits the entire
                    # successful batch atomically.
                    #
                    profiles.save(
                        REGISTRY,
                        new_data,
                    )

                except Exception:
                    import shutil as _shutil

                    for directory in created_dirs:
                        try:
                            if os.path.isdir(
                                directory
                            ):
                                _shutil.rmtree(
                                    directory
                                )
                        except Exception:
                            pass

                    raise

                self._data = profiles.load(
                    REGISTRY
                )

                self._load_providers(
                    provider_id
                )

                control = self.getControl(
                    self.PROFILE_LIST
                )

                first_id = imported[0][
                    "id"
                ]

                for index in range(
                    control.size()
                ):
                    item = control.getListItem(
                        index
                    )

                    if (
                        item
                        and item.getProperty(
                            "profile_id"
                        ) == first_id
                    ):
                        control.selectItem(
                            index
                        )
                        break

                self.setFocusId(
                    self.PROFILE_LIST
                )

            summary = (
                "Imported: {imported}\n"
                "Skipped: {skipped}\n"
                "Failed: {failed}\n\n"
                "TCP endpoints verified: {tcp}\n"
                "UDP hosts DNS verified: {udp}\n"
                "Locations identified: {located}"
            ).format(
                imported=len(imported),
                skipped=len(skipped),
                failed=len(failed),
                tcp=tcp_verified,
                udp=udp_dns_verified,
                located=locations_identified,
            )

            details = []

            for name, reason in (
                skipped[:3]
                + failed[:5]
            ):
                details.append(
                    "{}: {}".format(
                        name,
                        reason,
                    )
                )

            if details:
                summary += (
                    "\n\n"
                    + "\n".join(details)
                )

            DIALOG.ok(
                "OpenVPN Batch Import",
                summary,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "OpenVPN ZIP import failed."
                "\n\n{}".format(exc),
            )

        finally:
            try:
                archive.close()
            except Exception:
                pass


    def _import_single_openvpn_profile(self):
        if (
            "openvpn"
            not in supported_profile_types()
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "OpenVPN import is not supported "
                "on this platform.",
            )
            return

        provider_id = (
            self._selected_provider_id()
            or self._active_provider_id
        )

        if not provider_id:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Select a provider before importing "
                "an OpenVPN profile.",
            )
            return

        source_path = DIALOG.browseSingle(
            1,
            "Import OpenVPN Profile",
            "",
            ".ovpn",
            False,
            False,
            "",
        )

        if not source_path:
            return

        source_path = xbmcvfs.translatePath(
            source_path
        )

        if not os.path.isfile(source_path):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected OpenVPN profile "
                "could not be opened.",
            )
            return

        try:
            with open(
                source_path,
                "r",
                encoding="utf-8",
                errors="replace",
            ) as handle:
                source_lines = handle.readlines()

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Could not read the selected "
                "OpenVPN profile.\n\n{}".format(
                    exc
                ),
            )
            return

        file_directives = {
            "auth-user-pass",
            "ca",
            "cert",
            "crl-verify",
            "dh",
            "extra-certs",
            "key",
            "pkcs12",
            "tls-auth",
            "tls-crypt",
            "tls-crypt-v2",
        }

        remotes = []
        relative_files = []
        parse_errors = []

        for line_number, raw in enumerate(
            source_lines,
            1,
        ):
            stripped = raw.strip()

            if (
                not stripped
                or stripped.startswith("#")
                or stripped.startswith(";")
                or stripped.startswith("<")
            ):
                continue

            try:
                parts = shlex.split(
                    stripped,
                    comments=False,
                    posix=True,
                )

            except ValueError as exc:
                parse_errors.append(
                    "line {}: {}".format(
                        line_number,
                        exc,
                    )
                )
                continue

            if not parts:
                continue

            key = parts[0].lower()

            if key == "remote":
                if len(parts) < 2:
                    parse_errors.append(
                        "line {}: remote has no host".format(
                            line_number
                        )
                    )
                else:
                    remotes.append(parts[1:])

            if (
                key in file_directives
                and len(parts) >= 2
            ):
                reference = parts[1].strip()

                if reference == "[inline]":
                    continue

                if (
                    reference
                    and not os.path.isabs(reference)
                ):
                    relative_files.append(
                        "{} {}".format(
                            key,
                            reference,
                        )
                    )

        if parse_errors:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The OpenVPN profile contains an "
                "invalid directive.\n\n{}".format(
                    parse_errors[0]
                ),
            )
            return

        if not remotes:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The OpenVPN profile contains no "
                "remote server directive.",
            )
            return

        if relative_files:
            preview = "\n".join(
                relative_files[:5]
            )

            if len(relative_files) > 5:
                preview += "\n..."

            DIALOG.ok(
                "Kodi VPN Manager",
                "This profile uses relative external "
                "files. Moving only the .ovpn file "
                "would break those references.\n\n"
                "{}\n\n"
                "Companion-file import will be "
                "added separately.".format(
                    preview
                ),
            )
            return

        source_name = os.path.basename(
            source_path
        )

        default_name = os.path.splitext(
            source_name
        )[0]

        name = DIALOG.input(
            "Imported Profile Name",
            defaultt=default_name,
        ).strip()

        if not name:
            return

        profile_id = profiles.make_id(
            "openvpn"
        )

        destination_dir = os.path.join(
            MANAGED_PROFILE_ROOT,
            profile_id,
        )

        destination_path = os.path.join(
            destination_dir,
            "profile.ovpn",
        )

        try:
            os.makedirs(
                destination_dir,
                exist_ok=False,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Could not create managed profile "
                "storage.\n\n{}".format(exc),
            )
            return

        try:
            copied = xbmcvfs.copy(
                source_path,
                destination_path,
            )

            if (
                not copied
                or not os.path.isfile(
                    destination_path
                )
            ):
                raise RuntimeError(
                    "Kodi could not copy the profile."
                )

            data = profiles.load(REGISTRY)

            profile = {
                "id": profile_id,
                "name": name,
                "type": "openvpn",
                "path": destination_path,
                "enabled": True,
                "provider_id": provider_id,
                "authentication_id": None,
                "protocol_options": {},
            }

            data = profiles.upsert(
                data,
                profile,
            )

            if not profiles.selected_profile(
                data
            ):
                data = profiles.set_selected(
                    data,
                    profile_id,
                )

            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            try:
                if os.path.isfile(
                    destination_path
                ):
                    os.unlink(destination_path)

                if os.path.isdir(
                    destination_dir
                ):
                    os.rmdir(destination_dir)

            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "OpenVPN profile import failed."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(control.size()):
            item = control.getListItem(index)

            if (
                item
                and item.getProperty("profile_id")
                == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Imported: {}".format(name),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _credentials_for_selected_provider(self):
        provider_id = self._active_provider_id

        if not provider_id:
            return

        target = profiles.provider(
            self._data,
            provider_id,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected service could "
                "not be found.",
            )
            return

        auth_id = (
            target.get(
                "default_authentication_id"
            )
            or None
        )

        existing_auth = None

        if auth_id:
            existing_auth = (
                profiles.authentication(
                    self._data,
                    auth_id,
                )
            )

            if not existing_auth:
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The service refers to a "
                    "credential record that "
                    "could not be found.\n\n"
                    "Authentication ID: {}"
                    .format(auth_id),
                )
                return

            if (
                existing_auth.get(
                    "provider_id"
                )
                != provider_id
            ):
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The service credential "
                    "record belongs to another "
                    "service.\n\n"
                    "Credentials were not "
                    "changed.",
                )
                return

        try:
            secret_data_before = (
                secret_store.load(
                    SECRET_STORE
                )
            )
        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The credential store could "
                "not be read.\n\n{}".format(
                    exc
                ),
            )
            return

        current_username = ""

        if existing_auth:
            current_username = str(
                existing_auth.get(
                    "username",
                    ""
                )
            ).strip()

        current_password = ""

        if existing_auth:
            secret_ref = (
                existing_auth.get(
                    "secret_ref"
                )
            )

            if secret_ref:
                item = (
                    secret_data_before.get(
                        "items",
                        {}
                    ).get(
                        secret_ref,
                        {}
                    )
                )

                if isinstance(item, dict):
                    values = item.get(
                        "values",
                        {}
                    )

                    if isinstance(
                        values,
                        dict,
                    ):
                        current_password = str(
                            values.get(
                                "password",
                                ""
                            )
                        )

        username = DIALOG.input(
            "VPN Username",
            current_username,
            xbmcgui.INPUT_ALPHANUM,
        )

        username = str(
            username or ""
        ).strip()

        if not username:
            DIALOG.ok(
                "Kodi VPN Manager",
                "A username is required.",
            )
            return

        if (
            "\n" in username
            or "\r" in username
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The username cannot contain "
                "line breaks.",
            )
            return

        prompt = (
            "VPN Password"
            if not current_password
            else
            "VPN Password "
            "(leave blank to keep current)"
        )

        entered_password = DIALOG.input(
            prompt,
            "",
            xbmcgui.INPUT_ALPHANUM,
            xbmcgui.ALPHANUM_HIDE_INPUT,
        )

        if entered_password:
            confirmed_password = DIALOG.input(
                "Confirm VPN Password",
                "",
                xbmcgui.INPUT_ALPHANUM,
                xbmcgui.ALPHANUM_HIDE_INPUT,
            )

            if (
                entered_password
                != confirmed_password
            ):
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The passwords do not "
                    "match.\n\n"
                    "Credentials were not "
                    "changed.",
                )
                return

            password = entered_password

        else:
            password = current_password

        if not password:
            DIALOG.ok(
                "Kodi VPN Manager",
                "A password is required.",
            )
            return

        if (
            "\n" in password
            or "\r" in password
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The password cannot contain "
                "line breaks.",
            )
            return

        new_auth_id = (
            existing_auth.get("id")
            if existing_auth
            else
            "auth-provider-{}"
            .format(provider_id)
        )

        secret_ref = (
            existing_auth.get(
                "secret_ref"
            )
            if existing_auth
            else None
        )

        if not secret_ref:
            secret_ref = (
                "secret-{}"
                .format(new_auth_id)
            )

        auth_record = {
            "id": new_auth_id,
            "provider_id": provider_id,
            "label":
                "{} service credentials"
                .format(
                    target.get(
                        "name",
                        provider_id,
                    )
                ),
            "type": "username_password",
            "username": username,
            "secret_ref": secret_ref,
            "options": {},
        }

        new_secret_data = (
            secret_store.set_secret(
                secret_data_before,
                secret_ref,
                "username_password",
                {
                    "password": password,
                },
            )
        )

        new_data = (
            profiles.upsert_authentication(
                self._data,
                auth_record,
            )
        )

        updated_provider = dict(target)

        updated_provider[
            "default_authentication_id"
        ] = new_auth_id

        new_data = profiles.upsert_provider(
            new_data,
            updated_provider,
        )

        try:
            secret_store.save(
                SECRET_STORE,
                new_secret_data,
            )

            profiles.save(
                REGISTRY,
                new_data,
            )

        except Exception as exc:
            try:
                secret_store.save(
                    SECRET_STORE,
                    secret_data_before,
                )
            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The service credentials "
                "could not be saved."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        self._load_profiles(
            provider_id
        )

        self.setFocusId(
            self.PROVIDER_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Service credentials saved: {}"
            .format(
                target.get(
                    "name",
                    provider_id,
                )
            ),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _credentials_for_selected_profile(self):
        profile_id = self._selected_profile_id()

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile in profiles.profiles(
                    self._data
                )
                if profile.get("id")
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        if (
            str(
                target.get("type", "")
            ).strip().lower()
            != "openvpn"
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "Username/password credentials "
                "are currently supported only "
                "for OpenVPN profiles.",
            )
            return

        provider_id = (
            target.get("provider_id")
            or "legacy"
        )

        existing_auth = None

        existing_auth_id = target.get(
            "authentication_id"
        )

        if existing_auth_id:
            existing_auth = (
                profiles.authentication(
                    self._data,
                    existing_auth_id,
                )
            )

        current_username = ""

        if existing_auth:
            current_username = str(
                existing_auth.get(
                    "username",
                    ""
                )
            ).strip()

        secret_data_before = (
            secret_store.load(
                SECRET_STORE
            )
        )

        current_password = ""

        if existing_auth:
            old_ref = existing_auth.get(
                "secret_ref"
            )

            if old_ref:
                old_secret = (
                    secret_store.get_secret(
                        secret_data_before,
                        old_ref,
                    )
                )

                if old_secret:
                    current_password = str(
                        old_secret.get(
                            "values",
                            {}
                        ).get(
                            "password",
                            ""
                        )
                    )

        username = DIALOG.input(
            "VPN Username",
            defaultt=current_username,
        ).strip()

        if not username:
            return

        if (
            "\n" in username
            or "\r" in username
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The username cannot contain "
                "line breaks.",
            )
            return

        password_heading = (
            "VPN Password"
            if not current_password
            else
            "VPN Password "
            "(leave blank to keep current)"
        )

        entered_password = DIALOG.input(
            password_heading,
            "",
            xbmcgui.INPUT_ALPHANUM,
            xbmcgui.ALPHANUM_HIDE_INPUT,
        )

        if entered_password:
            confirmed_password = DIALOG.input(
                "Confirm VPN Password",
                "",
                xbmcgui.INPUT_ALPHANUM,
                xbmcgui.ALPHANUM_HIDE_INPUT,
            )

            if (
                entered_password
                != confirmed_password
            ):
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The passwords do not match.\n\n"
                    "Credentials were not changed.",
                )
                return

            password = entered_password

        else:
            password = current_password

        if not password:
            DIALOG.ok(
                "Kodi VPN Manager",
                "A password is required.",
            )
            return

        if (
            "\n" in password
            or "\r" in password
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The password cannot contain "
                "line breaks.",
            )
            return

        auth_id = (
            existing_auth.get("id")
            if existing_auth
            else
            "auth-{}".format(profile_id)
        )

        secret_ref = (
            existing_auth.get("secret_ref")
            if existing_auth
            and existing_auth.get(
                "secret_ref"
            )
            else
            "secret-{}".format(auth_id)
        )

        auth_record = {
            "id": auth_id,
            "provider_id": provider_id,
            "label": "{} credentials".format(
                target.get(
                    "name",
                    profile_id,
                )
            ),
            "type": "username_password",
            "username": username,
            "secret_ref": secret_ref,
            "options": {},
        }

        new_secret_data = (
            secret_store.set_secret(
                secret_data_before,
                secret_ref,
                "username_password",
                {
                    "password": password,
                },
            )
        )

        new_data = (
            profiles.upsert_authentication(
                self._data,
                auth_record,
            )
        )

        updated_profile = dict(target)
        updated_profile[
            "authentication_id"
        ] = auth_id

        new_data = profiles.upsert(
            new_data,
            updated_profile,
        )

        try:
            secret_store.save(
                SECRET_STORE,
                new_secret_data,
            )

            profiles.save(
                REGISTRY,
                new_data,
            )

        except Exception as exc:
            try:
                secret_store.save(
                    SECRET_STORE,
                    secret_data_before,
                )
            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The credentials could not "
                "be saved."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(
            control.size()
        ):
            row = control.getListItem(
                index
            )

            if (
                row
                and row.getProperty(
                    "profile_id"
                ) == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Credentials saved: {}".format(
                target.get(
                    "name",
                    profile_id,
                )
            ),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _edit_selected_profile(self):
        profile_id = (
            self._selected_profile_id()
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile.get("id")
                == profile_id
            ),
            None,
        )

        choices = [
            "Rename profile",
            "Move to service",
        ]

        if (
            target
            and str(
                target.get("type") or ""
            ).strip().lower()
            == "wireguard"
        ):
            current = (
                self._wireguard_persistent_keepalive(
                    target.get("path")
                )
            )

            options = (
                target.get("protocol_options")
                if isinstance(
                    target.get("protocol_options"),
                    dict,
                )
                else {}
            )

            source = str(
                options.get(
                    "persistent_keepalive_source"
                )
                or ""
            ).strip().lower()

            if current is None:
                label = "Keep-alive: Off"
            elif source == "user":
                label = (
                    "Keep-alive: {} seconds"
                    .format(current)
                )
            else:
                label = (
                    "Keep-alive: {} seconds"
                    .format(current)
                )

            choices.append(label)

        choice = DIALOG.select(
            "Edit Profile",
            choices,
        )

        if choice == 0:
            self._rename_selected_profile()
            return

        if choice == 1:
            self._move_selected_profile()
            return

        if (
            choice == 2
            and target
            and str(
                target.get("type") or ""
            ).strip().lower()
            == "wireguard"
        ):
            self._edit_wireguard_keepalive()
            return


    @staticmethod
    def _wireguard_persistent_keepalive(path):
        path = str(path or "").strip()

        if (
            not path
            or not os.path.isfile(path)
        ):
            return None

        try:
            with open(
                path,
                "r",
                encoding="utf-8",
                errors="replace",
            ) as handle:
                text = handle.read()
        except Exception:
            return None

        section = None
        values = []

        for raw_line in text.splitlines():
            line = raw_line.strip()

            if (
                not line
                or line.startswith("#")
                or line.startswith(";")
            ):
                continue

            if (
                line.startswith("[")
                and line.endswith("]")
            ):
                section = (
                    line[1:-1]
                    .strip()
                    .lower()
                )
                continue

            if (
                section != "peer"
                or "=" not in line
            ):
                continue

            key, value = line.split("=", 1)

            if (
                key.strip().lower()
                != "persistentkeepalive"
            ):
                continue

            try:
                parsed = int(value.strip())
            except (TypeError, ValueError):
                return None

            if not 0 <= parsed <= 65535:
                return None

            values.append(parsed)

        if len(values) != 1:
            return None

        return (
            values[0]
            if values[0] > 0
            else None
        )


    @staticmethod
    def _wireguard_set_persistent_keepalive(
        text,
        value,
    ):
        if value is not None:
            value = int(value)

            if not 1 <= value <= 65535:
                raise ValueError(
                    "WireGuard keepalive must be "
                    "between 1 and 65535 seconds"
                )

        lines = text.splitlines(
            keepends=True
        )

        peer_count = 0
        section = None
        directive_indexes = []
        peer_end = None

        for index, raw_line in enumerate(lines):
            stripped = raw_line.strip()

            if (
                stripped.startswith("[")
                and stripped.endswith("]")
            ):
                next_section = (
                    stripped[1:-1]
                    .strip()
                    .lower()
                )

                if (
                    section == "peer"
                    and peer_end is None
                ):
                    peer_end = index

                section = next_section

                if section == "peer":
                    peer_count += 1

                continue

            if (
                section == "peer"
                and "=" in stripped
                and not stripped.startswith("#")
                and not stripped.startswith(";")
            ):
                key = stripped.split(
                    "=",
                    1,
                )[0]

                if (
                    key.strip().lower()
                    == "persistentkeepalive"
                ):
                    directive_indexes.append(
                        index
                    )

        if (
            section == "peer"
            and peer_end is None
        ):
            peer_end = len(lines)

        if peer_count != 1:
            raise ValueError(
                "Managed WireGuard keepalive "
                "editing requires exactly one "
                "[Peer] section"
            )

        if len(directive_indexes) > 1:
            raise ValueError(
                "WireGuard profile contains "
                "multiple PersistentKeepalive "
                "directives"
            )

        newline = (
            "\r\n"
            if "\r\n" in text
            else "\n"
        )

        if directive_indexes:
            index = directive_indexes[0]

            if value is None:
                del lines[index]
            else:
                lines[index] = (
                    "PersistentKeepalive = {}{}"
                    .format(
                        value,
                        newline,
                    )
                )

        elif value is not None:
            prefix = ""

            if (
                peer_end == len(lines)
                and lines
                and not lines[-1].endswith(
                    ("\n", "\r")
                )
            ):
                prefix = newline

            lines.insert(
                peer_end,
                "{}PersistentKeepalive = {}{}"
                .format(
                    prefix,
                    value,
                    newline,
                ),
            )

        result = "".join(lines)

        if (
            text
            and not text.endswith(
                ("\n", "\r")
            )
            and result.endswith(
                ("\n", "\r")
            )
        ):
            result = result.rstrip(
                "\r\n"
            )

        return result


    def _edit_wireguard_keepalive(self):
        profile_id = (
            self._selected_profile_id()
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile.get("id")
                == profile_id
            ),
            None,
        )

        if (
            not target
            or str(
                target.get("type") or ""
            ).strip().lower()
            != "wireguard"
        ):
            return

        config_path = str(
            target.get("path") or ""
        ).strip()

        current = (
            self._wireguard_persistent_keepalive(
                config_path
            )
        )

        options = (
            target.get("protocol_options")
            if isinstance(
                target.get("protocol_options"),
                dict,
            )
            else {}
        )

        provider_default = options.get(
            "persistent_keepalive_default"
        )

        try:
            provider_default = (
                int(provider_default)
                if provider_default is not None
                else None
            )
        except (TypeError, ValueError):
            provider_default = None

        if (
            provider_default is not None
            and not 1 <= provider_default <= 65535
        ):
            provider_default = None

        if provider_default is None:
            heading = (
                "WireGuard Keep-alive "
                "(1-65535 seconds, 0 = Off)"
            )
        else:
            heading = (
                "WireGuard Keep-alive "
                "(1-65535, 0 = Off, Default: {})"
                .format(provider_default)
            )

        actions = ["Change"]

        if provider_default is not None:
            actions.append(
                "Reset to provider default ({})".format(
                    provider_default
                )
            )

        action = DIALOG.select(
            heading,
            actions,
        )

        if action < 0:
            return

        if action == 1:
            requested = provider_default
        else:
            entered = DIALOG.input(
                heading,
                defaultt=(
                    str(current)
                    if current is not None
                    else "0"
                ),
            ).strip()

            if not entered:
                return

            try:
                requested = int(entered)
            except (TypeError, ValueError):
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "Keepalive must be 0 or "
                    "1-65535 seconds.",
                )
                return

            if not 0 <= requested <= 65535:
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "Keepalive must be 0 or "
                    "1-65535 seconds.",
                )
                return

        new_value = (
            None
            if requested == 0
            else requested
        )

        if new_value == current:
            return

        try:
            with open(
                config_path,
                "r",
                encoding="utf-8",
                errors="replace",
            ) as handle:
                original_config = handle.read()

            updated_config = (
                self._wireguard_set_persistent_keepalive(
                    original_config,
                    new_value,
                )
            )
        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The WireGuard keepalive could "
                "not be prepared."
                "\n\n{}".format(exc),
            )
            return

        rollback_path = (
            config_path
            + ".keepalive.rollback"
        )

        test_path = (
            config_path
            + ".keepalive.test.conf"
        )

        try:
            with open(
                test_path,
                "w",
                encoding="utf-8",
            ) as handle:
                handle.write(updated_config)

            os.chmod(test_path, 0o600)

            test_profile = dict(target)
            test_profile["path"] = test_path

            check = BACKEND.preflight_profile(
                test_profile
            )

            if not check.get("ok"):
                raise RuntimeError(
                    "; ".join(
                        check.get("errors")
                        or [
                            "WireGuard profile "
                            "validation failed"
                        ]
                    )
                )

            with open(
                rollback_path,
                "w",
                encoding="utf-8",
            ) as handle:
                handle.write(original_config)

            os.chmod(
                rollback_path,
                0o600,
            )

            os.replace(
                test_path,
                config_path,
            )

            options = dict(
                target.get("protocol_options")
                if isinstance(
                    target.get(
                        "protocol_options"
                    ),
                    dict,
                )
                else {}
            )

            options[
                "persistent_keepalive"
            ] = (
                0
                if new_value is None
                else new_value
            )
            options[
                "persistent_keepalive_source"
            ] = (
                "provider"
                if (
                    provider_default is not None
                    and requested == provider_default
                )
                else "user"
            )

            updated = dict(target)
            updated[
                "protocol_options"
            ] = options

            data = profiles.upsert(
                self._data,
                updated,
            )

            original_data = self._data

            try:
                profiles.save(
                    REGISTRY,
                    data,
                )
            except Exception:
                os.replace(
                    rollback_path,
                    config_path,
                )
                raise

            live_result = (
                BACKEND.apply_wireguard_keepalive(
                    profile_id,
                    new_value,
                )
                if hasattr(
                    BACKEND,
                    "apply_wireguard_keepalive",
                )
                else {
                    "ok": False,
                    "active": True,
                    "error": (
                        "WireGuard live keepalive update "
                        "is unavailable"
                    ),
                }
            )

            if not live_result.get("ok"):
                rollback_error = None

                try:
                    os.replace(
                        rollback_path,
                        config_path,
                    )
                except Exception as exc:
                    rollback_error = exc

                try:
                    profiles.save(
                        REGISTRY,
                        original_data,
                    )
                except Exception as exc:
                    if rollback_error is None:
                        rollback_error = exc

                message = (
                    live_result.get("error")
                    or
                    "WireGuard live keepalive update failed"
                )

                if rollback_error is not None:
                    message += (
                        "; rollback also failed: {}"
                        .format(rollback_error)
                    )

                raise RuntimeError(message)

            if os.path.isfile(
                rollback_path
            ):
                os.unlink(
                    rollback_path
                )

        except Exception as exc:
            try:
                if os.path.isfile(test_path):
                    os.unlink(test_path)
            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The WireGuard keepalive could "
                "not be updated."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        provider_id = target.get(
            "provider_id"
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(control.size()):
            item = control.getListItem(index)

            if (
                item
                and item.getProperty(
                    "profile_id"
                )
                == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            (
                "WireGuard keepalive disabled"
                if new_value is None
                else
                "WireGuard keepalive: "
                "{} seconds".format(
                    new_value
                )
            ),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _rename_selected_profile(self):
        profile_id = (
            self._selected_profile_id()
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile.get("id")
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        current_name = target.get(
            "name",
            profile_id,
        )

        new_name = DIALOG.input(
            "Profile Name",
            defaultt=current_name,
        ).strip()

        if not new_name:
            return

        if new_name == current_name:
            return

        updated = dict(target)
        updated["name"] = new_name

        data = profiles.upsert(
            self._data,
            updated,
        )

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The profile could not be updated."
                "\n\n{}".format(exc),
            )
            return

        provider_id = updated.get(
            "provider_id"
        )

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(control.size()):
            item = control.getListItem(index)

            if (
                item
                and item.getProperty("profile_id")
                == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Renamed: {}".format(new_name),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _move_selected_profile(self):
        profile_id = (
            self._selected_profile_id()
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile.get("id")
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        current_provider_id = target.get(
            "provider_id"
        )

        destinations = [
            provider
            for provider
            in profiles.providers(
                self._data
            )
            if (
                provider.get("id")
                != current_provider_id
            )
        ]

        if not destinations:
            DIALOG.ok(
                "Kodi VPN Manager",
                "There is no other service "
                "to move this profile to.",
            )
            return

        choice = DIALOG.select(
            "Move Profile to Service",
            [
                provider.get(
                    "name",
                    provider.get(
                        "id",
                        "Unknown",
                    ),
                )
                for provider
                in destinations
            ],
        )

        if (
            choice < 0
            or choice >= len(destinations)
        ):
            return

        destination = destinations[
            choice
        ]

        destination_id = destination.get(
            "id"
        )

        if not destination_id:
            return

        updated = dict(target)
        updated["provider_id"] = (
            destination_id
        )

        data = profiles.upsert(
            self._data,
            updated,
        )

        # Keep profile-specific authentication
        # ownership consistent with the service.
        auth_id = target.get(
            "authentication_id"
        )

        if auth_id:
            auths = list(
                data.get(
                    "authentications",
                    []
                )
            )

            auth_index = next(
                (
                    index
                    for index, auth
                    in enumerate(auths)
                    if auth.get("id")
                    == auth_id
                ),
                None,
            )

            if auth_index is not None:
                auth = dict(
                    auths[auth_index]
                )

                profile_refs = [
                    profile
                    for profile
                    in data.get(
                        "profiles",
                        []
                    )
                    if (
                        profile.get(
                            "authentication_id"
                        )
                        == auth_id
                    )
                ]

                provider_default_refs = [
                    provider
                    for provider
                    in data.get(
                        "providers",
                        []
                    )
                    if (
                        provider.get(
                            "default_authentication_id"
                        )
                        == auth_id
                    )
                ]

                exclusive = (
                    len(profile_refs) == 1
                    and not provider_default_refs
                )

                if exclusive:
                    auth[
                        "provider_id"
                    ] = destination_id

                    auths[
                        auth_index
                    ] = auth

                else:
                    new_auth = dict(auth)

                    new_auth_id = (
                        profiles.make_id(
                            "auth-{}".format(
                                profile_id
                            )
                        )
                    )

                    new_auth["id"] = (
                        new_auth_id
                    )

                    new_auth[
                        "provider_id"
                    ] = destination_id

                    auths.append(
                        new_auth
                    )

                    for index, profile in enumerate(
                        data.get(
                            "profiles",
                            []
                        )
                    ):
                        if (
                            profile.get("id")
                            == profile_id
                        ):
                            copied = dict(
                                profile
                            )

                            copied[
                                "authentication_id"
                            ] = new_auth_id

                            data[
                                "profiles"
                            ][index] = copied

                            break

                data[
                    "authentications"
                ] = auths

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The profile could not be moved."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            destination_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(
            control.size()
        ):
            item = control.getListItem(
                index
            )

            if (
                item
                and item.getProperty(
                    "profile_id"
                )
                == profile_id
            ):
                control.selectItem(
                    index
                )
                break

        self._set_management_context(
            "profile"
        )

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Moved {} to {}".format(
                target.get(
                    "name",
                    profile_id,
                ),
                destination.get(
                    "name",
                    destination_id,
                ),
            ),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )

    def _delete_selected_profile(self):
        profile_id = (
            self._selected_profile_id()
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile.get("id")
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        active_id = self._active_profile_id()

        if (
            active_id
            and active_id == profile_id
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The active local VPN profile "
                "cannot be deleted.\n\n"
                "Switch to another VPN profile "
                "first.",
            )
            return

        name = target.get(
            "name",
            profile_id,
        )

        if not DIALOG.yesno(
            "Kodi VPN Manager",
            "Delete profile '{}'?\n\n"
            "This removes it from VPN Manager."
            .format(name),
        ):
            return

        profile_path = str(
            target.get("path") or ""
        ).strip()

        provider_id = target.get(
            "provider_id"
        )

        auth_id = target.get(
            "authentication_id"
        )

        auth_record = (
            profiles.authentication(
                self._data,
                auth_id,
            )
            if auth_id
            else None
        )

        secret_ref = (
            auth_record.get("secret_ref")
            if auth_record
            else None
        )

        #
        # Remove the profile first in memory. Its authentication
        # record is removed only if nothing else still uses it.
        #
        data = profiles.remove(
            self._data,
            profile_id,
        )

        remove_auth = False

        if auth_id:
            profile_still_uses_auth = any(
                item.get(
                    "authentication_id"
                ) == auth_id
                for item
                in profiles.profiles(data)
            )

            provider_still_uses_auth = any(
                item.get(
                    "default_authentication_id"
                ) == auth_id
                for item
                in data.get(
                    "providers",
                    [],
                )
            )

            if (
                not profile_still_uses_auth
                and not provider_still_uses_auth
            ):
                data = (
                    profiles.remove_authentication(
                        data,
                        auth_id,
                    )
                )
                remove_auth = True

        secret_data_before = (
            secret_store.load(
                SECRET_STORE
            )
        )

        secret_data_after = (
            secret_data_before
        )

        remove_secret = False

        if (
            remove_auth
            and secret_ref
        ):
            secret_still_used = any(
                item.get("secret_ref")
                == secret_ref
                for item
                in profiles.authentications(
                    data
                )
            )

            if not secret_still_used:
                secret_data_after = (
                    secret_store.remove_secret(
                        secret_data_before,
                        secret_ref,
                    )
                )
                remove_secret = True

        #
        # Persist the secret-store change first. If the registry
        # write then fails, restore the prior secret store.
        #
        if remove_secret:
            try:
                secret_store.save(
                    SECRET_STORE,
                    secret_data_after,
                )

            except Exception as exc:
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The profile was not deleted "
                    "because its stored credentials "
                    "could not be removed."
                    "\n\n{}".format(exc),
                )
                return

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            if remove_secret:
                try:
                    secret_store.save(
                        SECRET_STORE,
                        secret_data_before,
                    )
                except Exception:
                    pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The profile could not be "
                "removed from the registry."
                "\n\n{}".format(exc),
            )
            return

        #
        # Delete physical files only for profiles that
        # VPN Manager imported into its own managed tree.
        # Externally referenced profiles remain untouched.
        #
        managed_file_removed = False

        if profile_path:
            try:
                root = os.path.realpath(
                    MANAGED_PROFILE_ROOT
                )

                candidate = os.path.realpath(
                    profile_path
                )

                if (
                    os.path.commonpath(
                        [root, candidate]
                    ) == root
                ):
                    if os.path.isfile(candidate):
                        os.unlink(candidate)
                        managed_file_removed = True

                    parent = os.path.dirname(
                        candidate
                    )

                    if (
                        parent != root
                        and os.path.isdir(parent)
                        and not os.listdir(parent)
                    ):
                        os.rmdir(parent)

            except Exception as exc:
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The profile was removed from "
                    "VPN Manager, but its managed "
                    "file could not be cleaned up."
                    "\n\n{}".format(exc),
                )

        #
        # Remove any stale runtime credential file belonging
        # specifically to this deleted profile.
        #
        try:
            safe_id = "".join(
                ch
                if (
                    ch.isalnum()
                    or ch in "-_."
                )
                else "_"
                for ch in str(profile_id)
            )

            runtime_auth_dir = (
                "/run/vpn-manager-openvpn-auth"
            )

            runtime_auth_path = os.path.join(
                runtime_auth_dir,
                safe_id + ".auth",
            )

            if os.path.isfile(
                runtime_auth_path
            ):
                os.unlink(
                    runtime_auth_path
                )

            if (
                os.path.isdir(
                    runtime_auth_dir
                )
                and not os.listdir(
                    runtime_auth_dir
                )
            ):
                os.rmdir(
                    runtime_auth_dir
                )

        except Exception:
            pass

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Deleted: {}".format(name),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def onClick(self, control_id):

        if control_id == self.PROVIDER_LIST:
            self._set_management_context(
                "provider"
            )

            provider_id = (
                self._selected_provider_id()
            )

            if provider_id:
                self._active_provider_id = (
                    provider_id
                )

                self._browser_country = None

                self._load_profiles(
                    provider_id
                )

            return

        if control_id in (self.PROFILE_LIST, self.RECENT_LIST):
            #
            # Kodi/remotes can occasionally deliver the same OK
            # activation twice. This is particularly destructive
            # when the first click rebuilds PROFILE_LIST:
            #
            #   country -> contents -> duplicate click
            #
            # The second click then acts on the newly selected row
            # (often ".." or the active profile).
            #
            _vpn_click_now = time.monotonic()

            _vpn_last_click_control = getattr(
                self,
                "_vpn_last_profile_click_control",
                None,
            )

            _vpn_last_click_time = getattr(
                self,
                "_vpn_last_profile_click_time",
                0.0,
            )

            if (
                control_id == _vpn_last_click_control
                and (
                    _vpn_click_now
                    - _vpn_last_click_time
                ) < 0.50
            ):
                return

            self._vpn_last_profile_click_control = (
                control_id
            )

            self._vpn_last_profile_click_time = (
                _vpn_click_now
            )

            self._set_management_context(
                "profile"
            )

            self._activate_profile()
            return

        if control_id == self.ADD_BUTTON:
            if (
                self._management_context
                == "provider"
            ):
                self._add_provider()
            else:
                self._add_openvpn_profile()
            return

        if control_id == self.IMPORT_BUTTON:
            self._import_vpn_profile()
            return

        if control_id == self.EDIT_BUTTON:
            if (
                self._management_context
                == "provider"
            ):
                self._edit_selected_provider()
            else:
                self._edit_selected_profile()
            return

        if control_id == self.DELETE_BUTTON:
            if (
                self._management_context
                == "provider"
            ):
                self._delete_selected_provider()
            else:
                self._delete_selected_profile()
            return

        if (
            control_id
            == self.CREDENTIALS_BUTTON
        ):
            if (
                self._management_context
                == "provider"
            ):
                self._credentials_for_selected_provider()
            else:
                self._credentials_for_selected_profile()
            return

        if control_id == self.FILTER_BUTTON:
            self._set_management_context(
                "profile"
            )
            self._choose_profile_filter()
            return

        if control_id == self.SORT_BUTTON:
            self._set_management_context(
                "profile"
            )
            self._choose_profile_sort()
            return

        if control_id == self.CLOSE_BUTTON:
            self.close()

    def onAction(self, action):
        action_id = action.getId()
        focus_id = self.getFocusId()

        #
        # Remember the last root browser list used so returning
        # from Services restores the user's previous context.
        #
        if (
            not self._browser_country
            and focus_id in (
                self.RECENT_LIST,
                self.PROFILE_LIST,
            )
        ):
            self._vpn_last_root_list = (
                focus_id
            )

        nav_now = time.monotonic()

        if (
            action_id
            == getattr(
                self,
                "_cross_list_nav_action",
                None,
            )
            and nav_now
            - getattr(
                self,
                "_cross_list_nav_time",
                0.0,
            )
            < 0.25
        ):
            self._cross_list_nav_action = None
            return

        # Services:
        # Left  -> service action buttons
        # Right -> Profiles / Servers
        if focus_id == self.PROVIDER_LIST:
            self._set_management_context(
                "provider"
            )

            # Services is on the right.
            if action_id == 1:
                self._set_management_context(
                    "profile"
                )

                if self._browser_country:
                    _vpn_return_list = (
                        self.PROFILE_LIST
                    )

                else:
                    _vpn_return_list = getattr(
                        self,
                        "_vpn_last_root_list",
                        self.RECENT_LIST,
                    )

                    if _vpn_return_list not in (
                        self.RECENT_LIST,
                        self.PROFILE_LIST,
                    ):
                        _vpn_return_list = (
                            self.RECENT_LIST
                        )

                self.setFocusId(
                    _vpn_return_list
                )
                return

            if action_id == 2:
                self.setFocusId(
                    self.ADD_BUTTON
                )
                return

        elif focus_id == self.RECENT_LIST:
            self._set_management_context(
                "profile"
            )

            if action_id == 1:
                self._vpn_recent_down_armed = False

                self.setFocusId(
                    self.ADD_BUTTON
                )
                return

            if action_id == 2:
                self._vpn_recent_down_armed = False

                self._set_management_context(
                    "provider"
                )

                self.setFocusId(
                    self.PROVIDER_LIST
                )
                return

        elif focus_id == self.PROFILE_LIST:
            self._set_management_context(
                "profile"
            )

            #
            # Root Countries vertical navigation.
            #
            # Recent Connections and Countries are intentionally
            # independent vertical lists. The bottom action buttons
            # are the navigation bridge between them.
            #
            # The heading rows are visual only:
            #
            #   Recent:
            #       recent countries...
            #
            #   Alphabetical:
            #       remaining countries...
            #
            # If Kodi lands on either heading, immediately move to
            # the correct real country in the requested direction.
            #
            if (
                not self._browser_country
                and action_id in (
                    3,
                    4,
                )
            ):
                try:
                    _vpn_country_control = (
                        self.getControl(
                            self.PROFILE_LIST
                        )
                    )

                    _vpn_country_size = (
                        _vpn_country_control.size()
                    )

                    _vpn_country_item = (
                        _vpn_country_control
                        .getSelectedItem()
                    )

                    if (
                        _vpn_country_size
                        and _vpn_country_item
                        and _vpn_country_item.getProperty(
                            "browser_kind"
                        )
                        == "separator"
                    ):
                        _vpn_heading = (
                            _vpn_country_item
                            .getLabel()
                            .strip()
                        )

                        _vpn_real_positions = []
                        _vpn_recent_heading_position = None
                        _vpn_alpha_heading_position = None

                        for _vpn_index in range(
                            _vpn_country_size
                        ):
                            _vpn_item = (
                                _vpn_country_control
                                .getListItem(
                                    _vpn_index
                                )
                            )

                            _vpn_kind = (
                                _vpn_item.getProperty(
                                    "browser_kind"
                                )
                            )

                            if _vpn_kind != "separator":
                                _vpn_real_positions.append(
                                    _vpn_index
                                )

                                continue

                            _vpn_label = (
                                _vpn_item
                                .getLabel()
                                .strip()
                            )

                            if _vpn_label == "Recent:":
                                _vpn_recent_heading_position = (
                                    _vpn_index
                                )

                            elif _vpn_label == "Alphabetical:":
                                _vpn_alpha_heading_position = (
                                    _vpn_index
                                )

                        _vpn_target = None

                        #
                        # Recent: is also the wrap boundary for the
                        # entire Countries list.
                        #
                        # Up through it:
                        #     first recent -> last alphabetical
                        #
                        # Down through it:
                        #     last alphabetical -> first recent
                        #
                        if (
                            _vpn_heading
                            == "Recent:"
                            and _vpn_real_positions
                        ):
                            if action_id == 3:
                                _vpn_target = (
                                    _vpn_real_positions[-1]
                                )

                            else:
                                _vpn_target = (
                                    _vpn_real_positions[0]
                                )

                        #
                        # Alphabetical: is the internal boundary.
                        #
                        # Up:
                        #     first alphabetical -> last recent
                        #
                        # Down:
                        #     last recent -> first alphabetical
                        #
                        elif (
                            _vpn_heading
                            == "Alphabetical:"
                            and
                            _vpn_alpha_heading_position
                            is not None
                        ):
                            if action_id == 3:
                                _vpn_before = [
                                    position
                                    for position
                                    in _vpn_real_positions
                                    if position
                                    < _vpn_alpha_heading_position
                                ]

                                if _vpn_before:
                                    _vpn_target = (
                                        _vpn_before[-1]
                                    )

                            else:
                                _vpn_after = [
                                    position
                                    for position
                                    in _vpn_real_positions
                                    if position
                                    > _vpn_alpha_heading_position
                                ]

                                if _vpn_after:
                                    _vpn_target = (
                                        _vpn_after[0]
                                    )

                        #
                        # Defensive fallback for an unexpected
                        # separator label.
                        #
                        if (
                            _vpn_target is None
                            and _vpn_real_positions
                        ):
                            _vpn_target = (
                                _vpn_real_positions[-1]
                                if action_id == 3
                                else _vpn_real_positions[0]
                            )

                        if _vpn_target is not None:
                            _vpn_country_control.selectItem(
                                _vpn_target
                            )

                            return

                except Exception:
                    pass

            if action_id == 117:
                choice = DIALOG.contextmenu(
                    [
                        "Filter...",
                        "Sort...",
                        "Reset Filter / Sort",
                    ]
                )

                if choice == 0:
                    self._choose_profile_filter()
                    return

                if choice == 1:
                    self._choose_profile_sort()
                    return

                if choice == 2:
                    self._profile_filter = "all"
                    self._profile_sort = "location"

                    xbmcgui.Window(
                        10000
                    ).setProperty(
                        "VPNManager.ProfileFilter",
                        "all",
                    )

                    self._load_profiles(
                        self._active_provider_id
                    )

                    self.setFocusId(
                        self.PROFILE_LIST
                    )
                    return

                return

            if action_id == 1:
                self.setFocusId(
                    self.ADD_BUTTON
                )
                return

            if action_id == 2:
                self._set_management_context(
                    "provider"
                )

                self.setFocusId(
                    self.PROVIDER_LIST
                )
                return


        elif focus_id in (
            self.FILTER_BUTTON,
            self.SORT_BUTTON,
        ):
            self._set_management_context(
                "profile"
            )

            if action_id == 1:
                self.setFocusId(
                    self.PROFILE_LIST
                )
                return

            if action_id == 2:
                self.setFocusId(
                    self.ADD_BUTTON
                )
                return

            if action_id in (
                3,
                4,
            ):
                self.setFocusId(
                    self.SORT_BUTTON
                    if focus_id
                    == self.FILTER_BUTTON
                    else self.FILTER_BUTTON
                )
                return

        # Vertical navigation from the action buttons.
        #
        # At the country root:
        #   Up   -> Countries
        #   Down -> Recent Connections
        #
        # Each list retains its own selected row, making the
        # action-button row a convenient bridge between the two
        # vertical lists.
        #
        # Inside a country, Recent Connections is not shown, so
        # both vertical directions return to the profile browser.
        elif (
            focus_id in (
                self.ADD_BUTTON,
                self.IMPORT_BUTTON,
                self.EDIT_BUTTON,
                self.DELETE_BUTTON,
                self.CREDENTIALS_BUTTON,
                self.CLOSE_BUTTON,
                self.FILTER_BUTTON,
                self.SORT_BUTTON,
            )
            and action_id in (
                3,
                4,
            )
        ):
            if (
                self._management_context
                == "provider"
            ):
                self.setFocusId(
                    self.PROVIDER_LIST
                )

            elif action_id == 3:
                # Up -> Countries / current profile browser.
                self.setFocusId(
                    self.PROFILE_LIST
                )

            elif self._browser_country:
                # Recent is hidden inside a country.
                self.setFocusId(
                    self.PROFILE_LIST
                )

            else:
                # Down -> current Recent Connections selection.
                self.setFocusId(
                    self.RECENT_LIST
                )

            return

        if action_id in (
            9,
            10,
            92,
        ):
            if self._browser_country:
                self._last_browser_country = (
                    self._browser_country
                )

                self._browser_country = None

                self._load_profiles(
                    self._active_provider_id
                )

                self.setFocusId(
                    self.PROFILE_LIST
                )

                return

            self.close()




def open_profile_manager():
    window = ProfileManagerWindow(
        "VPNProfileManager.xml",
        ADDON.getAddonInfo("path"),
        "Default",
        "720p",
    )

    window.doModal()

    del window



# SYSTEM_METRICS
# Kodi-native information is preferred wherever Kodi exposes it.
# Linux/CoreELEC probes are fallbacks for metrics Kodi does not expose.


def _metric_setting(
    setting_id,
    default=True,
):
    try:
        return bool(
            ADDON.getSettingBool(
                setting_id
            )
        )

    except Exception:
        try:
            value = str(
                ADDON.getSetting(
                    setting_id
                )
            ).strip().lower()

        except Exception:
            return default

        if value in (
            "true",
            "1",
            "yes",
            "on",
        ):
            return True

        if value in (
            "false",
            "0",
            "no",
            "off",
        ):
            return False

        return default


def _dashboard_metrics_enabled():
    return not _metric_setting(
        "dashboard_metrics_disable_all",
        default=False,
    )

def _info_label(*names):
    for name in names:
        try:
            value = xbmc.getInfoLabel(
                name
            )
        except Exception:
            continue

        value = " ".join(
            str(value or "").split()
        )

        if (
            value
            and value.lower()
            not in (
                "n/a",
                "na",
                "none",
                "unknown",
                "unavailable",
                "-",
            )
        ):
            return value

    return None


def _read_text(path):
    try:
        with open(
            path,
            "r",
            encoding="utf-8",
            errors="replace",
        ) as handle:
            return handle.read().strip()

    except Exception:
        return None


def _thermal_by_type(*wanted):
    root = "/sys/class/thermal"

    try:
        names = os.listdir(root)
    except Exception:
        return None

    wanted = {
        str(value).strip().lower()
        for value in wanted
    }

    for name in names:
        if not name.startswith(
            "thermal_zone"
        ):
            continue

        base = os.path.join(
            root,
            name,
        )

        zone_type = _read_text(
            os.path.join(
                base,
                "type",
            )
        )

        if not zone_type:
            continue

        if (
            zone_type.strip().lower()
            not in wanted
        ):
            continue

        raw = _read_text(
            os.path.join(
                base,
                "temp",
            )
        )

        if not raw:
            continue

        try:
            value = float(raw)

            if abs(value) >= 1000:
                value /= 1000.0

            return "{}°C".format(
                int(round(value))
            )

        except Exception:
            continue

    return None


def _percent_value(value):
    if value is None:
        return None

    text = str(value).strip()

    if not text:
        return None

    match = re.search(
        r"-?\d+(?:\.\d+)?",
        text,
    )

    if not match:
        return None

    try:
        number = float(
            match.group(0)
        )
    except Exception:
        return None

    if (
        number < 0
        or number > 100
    ):
        return None

    return "{}%".format(
        int(round(number))
    )


def _linux_gpu_usage():
    # Amlogic/CoreELEC exposes GPU utilization here.
    # Values observed on this platform are percentage-like 0..100.
    value = _read_text(
        "/sys/class/mpgpu/utilization"
    )

    return _percent_value(value)


def _linux_ram_usage():
    raw = _read_text(
        "/proc/meminfo"
    )

    if not raw:
        return None

    values = {}

    for line in raw.splitlines():
        if ":" not in line:
            continue

        key, value = line.split(
            ":",
            1,
        )

        fields = value.strip().split()

        if not fields:
            continue

        try:
            values[key] = float(
                fields[0]
            )
        except Exception:
            pass

    total = values.get(
        "MemTotal"
    )

    available = values.get(
        "MemAvailable"
    )

    if (
        not total
        or available is None
    ):
        return None

    used_percent = (
        (total - available)
        / total
        * 100.0
    )

    return _percent_value(
        used_percent
    )


def _cpu_temperature():
    return (
        _info_label(
            "System.CPUTemperature",
        )
        or _thermal_by_type(
            "soc_thermal",
            "cpu_thermal",
            "cpu-thermal",
        )
    )


_CPU_USAGE_SAMPLE = None


def _linux_cpu_usage():
    global _CPU_USAGE_SAMPLE

    raw = _read_text("/proc/stat")

    if not raw:
        return None

    line = next(
        (
            value
            for value in raw.splitlines()
            if value.startswith("cpu ")
        ),
        None,
    )

    if not line:
        return None

    try:
        values = [
            int(value)
            for value in line.split()[1:]
        ]
    except Exception:
        return None

    while len(values) < 8:
        values.append(0)

    idle = values[3] + values[4]
    total = sum(values)

    previous = _CPU_USAGE_SAMPLE

    _CPU_USAGE_SAMPLE = (
        total,
        idle,
    )

    if previous is None:
        return None

    delta_total = total - previous[0]
    delta_idle = idle - previous[1]

    if delta_total <= 0:
        return None

    usage = (
        100.0
        * (delta_total - delta_idle)
        / delta_total
    )

    return _percent_value(usage)


def _kodi_cpu_usage():
    value = _info_label(
        "System.CpuUsage",
        "System.CPUUsage",
    )

    if not value:
        return None

    percentages = [
        float(item)
        for item in re.findall(
            r"(\d+(?:\.\d+)?)\s*%",
            value,
        )
    ]

    if percentages:
        return _percent_value(
            sum(percentages)
            / len(percentages)
        )

    return _percent_value(value)


def _cpu_usage():
    # Linux/CoreELEC: aggregate all CPUs using
    # the kernel's cumulative CPU counters.
    if os.path.exists("/proc/stat"):
        return _linux_cpu_usage()

    # Cross-platform Kodi fallback.
    return _kodi_cpu_usage()


def _gpu_temperature():
    # Do not substitute SoC/DDR temperature for a GPU sensor.
    return _info_label(
        "System.GPUTemperature",
    )


def _gpu_usage():
    # Kodi has no standard GPU-usage InfoLabel.
    # Amlogic/CoreELEC exposes the Mali driver's
    # utilization counter through mpgpu.
    return _linux_gpu_usage()


def _ddr_temperature():
    return _thermal_by_type(
        "ddr_thermal",
        "ddr-thermal",
        "ddr thermal",
    )


def _ram_usage():
    return (
        _percent_value(
            _info_label(
                "System.Memory(used.percent)",
            )
        )
        or _linux_ram_usage()
    )


def _kodi_ram_usage():
    rss_kb = None
    total_kb = None

    try:
        with open(
            "/proc/self/status",
            "r",
            encoding="utf-8",
        ) as handle:
            for line in handle:
                if line.startswith("VmRSS:"):
                    parts = line.split()

                    if len(parts) >= 2:
                        rss_kb = int(parts[1])

                    break
    except Exception:
        rss_kb = None

    try:
        with open(
            "/proc/meminfo",
            "r",
            encoding="utf-8",
        ) as handle:
            for line in handle:
                if line.startswith("MemTotal:"):
                    parts = line.split()

                    if len(parts) >= 2:
                        total_kb = int(parts[1])

                    break
    except Exception:
        total_kb = None

    mb_value = None
    percent_value = None

    if rss_kb is not None:
        mb_value = "{} MB".format(
            int(round(rss_kb / 1024.0))
        )

    if (
        rss_kb is not None
        and total_kb
        and total_kb > 0
    ):
        percent_value = "{}%".format(
            int(round(
                rss_kb * 100.0 / total_kb
            ))
        )

    return mb_value, percent_value


def _publish_system_metrics_core():
    if not _dashboard_metrics_enabled():
        for name in (
            "SystemCPU",
            "SystemGPU",
            "SystemDDR",
            "SystemRAM",
            "SystemKodiRAM",
        ):
            WINDOW.clearProperty(
                "VPNManager." + name
            )
        WINDOW.clearProperty(
            "VPNManager.SystemMetrics"
        )
        return
    cpu_temp = (
        _cpu_temperature()
        if _metric_setting(
            "show_cpu_temperature"
        )
        else None
    )

    cpu_usage = (
        _cpu_usage()
        if _metric_setting(
            "show_cpu_usage"
        )
        else None
    )

    gpu_temp = (
        _gpu_temperature()
        if _metric_setting(
            "show_gpu_temperature"
        )
        else None
    )

    gpu_usage = (
        _gpu_usage()
        if _metric_setting(
            "show_gpu_usage"
        )
        else None
    )

    ddr_temp = (
        _ddr_temperature()
        if _metric_setting(
            "show_ddr_temperature"
        )
        else None
    )

    ram_usage = (
        _ram_usage()
        if _metric_setting(
            "show_ddr_usage"
        )
        else None
    )

    kodi_ram_mb, kodi_ram_percent = (
        _kodi_ram_usage()
    )

    if not _metric_setting(
        "show_kodi_ram_mb"
    ):
        kodi_ram_mb = None

    if not _metric_setting(
        "show_kodi_ram_percent"
    ):
        kodi_ram_percent = None

    kodi_ram_values = [
        value
        for value in (
            kodi_ram_mb,
            kodi_ram_percent,
        )
        if value
    ]

    cpu_values = [
        value
        for value in (
            cpu_temp,
            cpu_usage,
        )
        if value
    ]

    gpu_values = [
        value
        for value in (
            gpu_temp,
            gpu_usage,
        )
        if value
    ]

    metric_properties = {
        "SystemCPU": (
            "CPU: {}".format(
                "/".join(cpu_values)
            )
            if cpu_values
            else None
        ),
        "SystemGPU": (
            "GPU: {}".format(
                "/".join(gpu_values)
            )
            if gpu_values
            else None
        ),
        "SystemDDR": (
            "DDR: {}".format(
                ddr_temp
            )
            if ddr_temp
            else None
        ),
        "SystemRAM": (
            "RAM: {}".format(
                ram_usage
            )
            if ram_usage
            else None
        ),
        "SystemKodiRAM": (
            "K-RAM: {}".format(
                "/".join(kodi_ram_values)
            )
            if kodi_ram_values
            else None
        ),
    }

    for name, value in metric_properties.items():
        property_name = (
            "VPNManager." + name
        )

        if value:
            WINDOW.setProperty(
                property_name,
                value,
            )
        else:
            WINDOW.clearProperty(
                property_name
            )

    # Remove the old single-line dashboard property.
    WINDOW.clearProperty(
        "VPNManager.SystemMetrics"
    )


# Preserve the existing dashboard publisher and extend it
# without changing the VPN-state implementation.



def _system_metric_interval():
    try:
        value = int(
            ADDON.getSetting(
                "dashboard_refresh_seconds"
            )
            or "1"
        )
    except Exception:
        value = 1

    return max(
        1,
        min(
            value,
            60,
        ),
    )


# VPN_DASHBOARD_WORKER_LIFECYCLE_BEGIN

_vpn_dashboard_worker_lock = threading.Lock()
_vpn_dashboard_worker_stop = threading.Event()
_vpn_dashboard_workers = set()


def _vpn_register_dashboard_worker(thread):
    with _vpn_dashboard_worker_lock:
        _vpn_dashboard_workers.add(
            thread
        )


def _vpn_unregister_dashboard_worker(thread):
    with _vpn_dashboard_worker_lock:
        _vpn_dashboard_workers.discard(
            thread
        )


def _vpn_stop_dashboard_workers():
    _vpn_dashboard_worker_stop.set()


def _vpn_join_dashboard_workers(timeout=3.0):
    deadline = (
        time.monotonic()
        + max(
            0.0,
            float(timeout),
        )
    )

    current = threading.current_thread()

    while True:
        with _vpn_dashboard_worker_lock:
            workers = [
                thread
                for thread
                in _vpn_dashboard_workers
                if (
                    thread is not current
                    and thread.is_alive()
                )
            ]

        if not workers:
            break

        remaining = (
            deadline
            - time.monotonic()
        )

        if remaining <= 0:
            break

        for thread in workers:
            remaining = (
                deadline
                - time.monotonic()
            )

            if remaining <= 0:
                break

            try:
                thread.join(
                    timeout=min(
                        0.25,
                        remaining,
                    )
                )
            except Exception:
                pass

    with _vpn_dashboard_worker_lock:
        dead = [
            thread
            for thread
            in _vpn_dashboard_workers
            if not thread.is_alive()
        ]

        for thread in dead:
            _vpn_dashboard_workers.discard(
                thread
            )


def _vpn_begin_dashboard_workers():
    #
    # A reused Kodi Python interpreter must not inherit workers from
    # a previous manager.py invocation.
    #
    _vpn_stop_dashboard_workers()
    _vpn_join_dashboard_workers(
        timeout=3.0
    )

    _vpn_dashboard_worker_stop.clear()


def _vpn_dashboard_worker_wait(
    monitor,
    delay,
):
    deadline = (
        time.monotonic()
        + max(
            0.0,
            float(delay),
        )
    )

    while True:
        if _vpn_dashboard_worker_stop.is_set():
            return True

        remaining = (
            deadline
            - time.monotonic()
        )

        if remaining <= 0:
            return False

        step = min(
            0.10,
            remaining,
        )

        try:
            if monitor.waitForAbort(
                step
            ):
                return True
        except Exception:
            if _vpn_dashboard_worker_stop.wait(
                step
            ):
                return True


def _vpn_start_dashboard_worker(
    target,
    name,
):
    if _vpn_dashboard_worker_stop.is_set():
        return None

    def runner():
        try:
            target()
        finally:
            _vpn_unregister_dashboard_worker(
                threading.current_thread()
            )

    thread = threading.Thread(
        target=runner,
        name=name,
    )

    thread.daemon = True

    _vpn_register_dashboard_worker(
        thread
    )

    try:
        thread.start()

    except Exception:
        _vpn_unregister_dashboard_worker(
            thread
        )
        raise

    return thread


# VPN_DASHBOARD_WORKER_LIFECYCLE_END


class DashboardWindow(xbmcgui.WindowXMLDialog):
    REFRESH_BUTTON = 100
    SETTINGS_BUTTON = 101
    CHANGE_PROFILE_BUTTON = 102
    BACK_ACTIONS = (9, 10, 92)

    def onInit(self):
        self._metric_stop = (
            threading.Event()
        )

        publish_dashboard_properties()

        self.setFocusId(
            self.REFRESH_BUTTON
        )

        self._metric_thread = None
        self._sync_metric_loop()

        _vpn_sync_exit_country_flag()
        _vpn_schedule_exit_country_flag_sync()


    def _sync_metric_loop(self):
        thread = self._metric_thread

        if _dashboard_metrics_enabled():
            if thread is not None and thread.is_alive():
                return

            self._metric_stop.clear()
            thread = threading.Thread(
                target=self._metric_loop,
                name="vpn-manager-metrics",
            )
            thread.daemon = True
            self._metric_thread = thread
            thread.start()
            return

        self._stop_metric_loop()

        if (
            thread is not None
            and thread is not threading.current_thread()
        ):
            try:
                thread.join(timeout=2.0)
            except Exception:
                pass

        self._metric_thread = None
        publish_system_metrics()

    def _metric_loop(self):
        while not self._metric_stop.is_set():
            try:
                publish_system_metrics()
            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: "
                    "system metric refresh failed: "
                    "{}".format(exc),
                    xbmc.LOGWARNING,
                )

            self._metric_stop.wait(
                _system_metric_interval()
            )

    def _stop_metric_loop(self):
        try:
            self._metric_stop.set()
        except Exception:
            pass

    def _shutdown_workers(self):
        self._stop_metric_loop()
        _vpn_stop_dashboard_workers()

        thread = getattr(
            self,
            "_metric_thread",
            None,
        )

        if (
            thread is not None
            and thread is not threading.current_thread()
        ):
            try:
                thread.join(
                    timeout=2.0
                )
            except Exception:
                pass

        _vpn_join_dashboard_workers(
            timeout=3.0
        )

    def close(self):
        #
        # Signal every worker immediately. The actual joins happen
        # after doModal() returns so Kodi's UI thread is never held
        # waiting for background worker teardown.
        #
        self._stop_metric_loop()
        _vpn_stop_dashboard_workers()

        return super(
            DashboardWindow,
            self,
        ).close()

    def onClick(self, control_id):
        if control_id == self.REFRESH_BUTTON:
            _vpn_refresh_dashboard()

        elif control_id == self.SETTINGS_BUTTON:
            ADDON.openSettings()
            self._sync_metric_loop()
            publish_dashboard_properties()

        elif control_id == self.CHANGE_PROFILE_BUTTON:
            before_id = (
                _vpn_selected_profile_id()
            )

            open_profile_manager()

            after_id = (
                _vpn_selected_profile_id()
            )

            if (
                after_id
                and after_id != before_id
            ):
                _vpn_refresh_dashboard()

            else:
                publish_dashboard_properties()

    def onAction(self, action):
        if action.getId() in self.BACK_ACTIONS:
            self.close()



def main():
    #
    # Each manager.py invocation owns one bounded set of dashboard
    # workers. Clean up any stale registered worker state first,
    # then create a fresh cancellation window for this invocation.
    #
    _vpn_begin_dashboard_workers()

    dashboard = None

    try:
        publish_dashboard_properties()

        dashboard = DashboardWindow(
            "VPNManagerDashboard.xml",
            ADDON.getAddonInfo("path"),
            "Default",
            "720p"
        )

        dashboard.doModal()

    finally:
        #
        # Kodi must never regain control while manager.py still owns
        # live Python worker threads. This is what prevents
        # CPythonInvoker "waiting on thread" accumulation.
        #
        if dashboard is not None:
            try:
                dashboard._shutdown_workers()
            except Exception:
                _vpn_stop_dashboard_workers()
                _vpn_join_dashboard_workers(
                    timeout=3.0
                )
        else:
            _vpn_stop_dashboard_workers()
            _vpn_join_dashboard_workers(
                timeout=3.0
            )

        if dashboard is not None:
            del dashboard





# VPN_REFRESH_FLOW_CLEANUP_BEGIN


def _vpn_selected_profile_id():
    try:
        data = profiles.load(
            REGISTRY
        )

        selected = profiles.selected_profile(
            data
        )

        if not selected:
            return ""

        return str(
            selected.get(
                "id",
                "",
            )
            or ""
        )

    except Exception:
        return ""




def _vpn_refresh_dashboard():
    # Use the same backend request used by the existing
    # Trigger the background refresh without opening show_status().
    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )

    # Keep metric behaviour from the original dashboard
    # Refresh button.
    publish_system_metrics()

    started = time.monotonic()

    while (
        time.monotonic() - started
        < 60
    ):
        xbmc.sleep(
            250
        )

        requested = WINDOW.getProperty(
            "VPNManager.RefreshVPN"
        )

        status = prop(
            "VPNStatus"
        )

        verification = prop(
            "VPNVerification"
        )

        if (
            requested != "1"
            and status != "Refreshing..."
            and verification != "Checking now..."
        ):
            break

    # The backend has now settled. Publish once, at the end.
    publish_system_metrics()
    publish_dashboard_properties()

    _vpn_sync_exit_country_flag()
    _vpn_schedule_exit_country_flag_sync()


_vpn_activate_profile_base = (
    ProfileManagerWindow._activate_profile
)


def _vpn_activate_profile_and_close(
    self,
    *args,
    **kwargs
):
    before_id = (
        _vpn_selected_profile_id()
    )

    result = _vpn_activate_profile_base(
        self,
        *args,
        **kwargs
    )

    after_id = (
        _vpn_selected_profile_id()
    )

    # A changed selected ID means the profile switch committed.
    # Close the modal only; DashboardWindow performs the actual
    # refresh after open_profile_manager() returns.
    if (
        after_id
        and after_id != before_id
    ):
        try:
            self.close()

        except Exception:
            pass

    return result


ProfileManagerWindow._activate_profile = (
    _vpn_activate_profile_and_close
)

# VPN_REFRESH_FLOW_CLEANUP_END



# VPN_EXIT_FLAG_SYNC_BEGIN

import threading as _vpn_threading


def _vpn_sync_exit_country_flag():
    try:
        location = str(
            WINDOW.getProperty(
                "VPNManager.VPNExitLocation"
            )
            or ""
        ).strip()

        if not location:
            # Preserve the current flag while location
            # data is temporarily unavailable.
            return False

        flag = _country_flag_from_location(
            location
        )

        if not flag:
            return False

        current = WINDOW.getProperty(
            "VPNManager.ExitCountryFlag"
        )

        if current != flag:
            WINDOW.clearProperty(
                "VPNManager.ExitCountryFlag"
            )

            WINDOW.setProperty(
                "VPNManager.ExitCountryFlag",
                flag,
            )

        return True

    except Exception:
        return False


def _vpn_schedule_exit_country_flag_sync():
    def worker():
        try:
            monitor = xbmc.Monitor()

            # The verification/backend fields can settle after
            # the first dashboard publish. Recheck for several
            # seconds without blocking the UI.
            for delay in (
                0.05,
                0.20,
                0.35,
                0.60,
                1.00,
                1.50,
                2.00,
            ):
                if _vpn_dashboard_worker_wait(
                    monitor,
                    delay,
                ):
                    return

                _vpn_sync_exit_country_flag()

        except Exception:
            pass


    try:
        thread = _vpn_start_dashboard_worker(
            target=worker,
            name="VPNExitFlagSync",
        )

        if thread is None:
            _vpn_sync_exit_country_flag()

    except Exception:
        _vpn_sync_exit_country_flag()



# Keep the Exit flag synchronized whenever the dashboard's
# normal metric publisher runs.

def publish_system_metrics():
    result = _publish_system_metrics_core()

    _vpn_sync_exit_country_flag()

    return result


# VPN_EXIT_FLAG_SYNC_END



# VPN_GEO_DIAGNOSTIC_BEGIN


def _vpn_geo_first(*values):
    for value in values:
        value = str(
            value or ""
        ).strip()

        if value:
            return value

    return ""


def _vpn_geo_window(*names):
    for name in names:
        try:
            value = WINDOW.getProperty(
                name
            )

            if value:
                return str(
                    value
                ).strip()

        except Exception:
            pass

    return ""


def _vpn_geo_backend(*names):
    for name in names:
        try:
            value = prop(
                name
            )

            if value:
                return str(
                    value
                ).strip()

        except Exception:
            pass

    return ""


def _vpn_geo_clean_place(value):
    value = unicodedata.normalize(
        "NFKD",
        str(value or "").strip(),
    )

    value = "".join(
        char
        for char in value
        if not unicodedata.combining(char)
    ).casefold()

    value = (
        value
        .replace("\u2018", "'")
        .replace("\u2019", "'")
        .replace("\u2013", "-")
        .replace("\u2014", "-")
    )

    value = "".join(
        char
        if char.isalnum()
        else " "
        for char in value
    )

    return " ".join(
        value.split()
    )


def _vpn_geo_profile_city(name):
    name = str(
        name or ""
    ).strip()

    if " - " in name:
        name = name.rsplit(
            " - ",
            1,
        )[-1]

    if (
        name.endswith("]")
        and "[" in name
    ):
        name = name.rsplit(
            "[",
            1,
        )[0].strip()

    if "," in name:
        name = name.split(
            ",",
            1,
        )[0].strip()

    return name


def _vpn_geo_mask_ip(value):
    value = str(
        value or ""
    ).strip()

    try:
        address = ipaddress.ip_address(
            value
        )

    except ValueError:
        return value

    if address.version == 4:
        first = str(address).split(
            ".",
            1,
        )[0]

        return "{}.x.x.x".format(
            first
        )

    first = (
        address.exploded
        .split(":", 1)[0]
        .lstrip("0")
        or "0"
    )

    return (
        first
        + ":x:x:x:x:x:x:x"
    )


def _vpn_publish_geo_diagnostic():
    selected_name = _vpn_geo_window(
        "VPNManager.SelectedProfile"
    )

    selected_city = ""
    selected_country = ""
    server_endpoint = ""

    try:
        data = profiles.load(
            REGISTRY
        )

        selected = profiles.selected_profile(
            data
        ) or {}

        selected_name = _vpn_geo_first(
            selected.get("name"),
            selected.get("label"),
            selected_name,
        )

        protocol_options = (
            selected.get("protocol_options")
            or {}
        )

        if not isinstance(
            protocol_options,
            dict,
        ):
            protocol_options = {}

        selected_city = _vpn_geo_first(
            protocol_options.get("city"),
            selected.get("city"),
            selected.get("location"),
            _vpn_geo_profile_city(
                selected_name
            ),
        )

        selected_country = str(
            selected.get(
                "country",
                "",
            )
            or ""
        ).strip()

        for key in (
            "server_ip",
            "server",
            "remote",
            "host",
            "hostname",
            "address",
            "ip",
        ):
            candidate = selected.get(
                key
            )

            if candidate:
                server_endpoint = str(
                    candidate
                ).strip()
                break

    except Exception:
        pass


    server_endpoint = _vpn_geo_first(
        server_endpoint,
        _vpn_geo_window(
            "VPNManager.VPNServer",
            "VPNManager.Server",
            "VPNManager.VPNServerIP",
            "VPNManager.ServerIP",
        ),
        _vpn_geo_backend(
            "VPNServer",
            "Server",
            "VPNServerIP",
            "ServerIP",
            "RemoteServer",
        ),
    )


    public_ip = _vpn_geo_first(
        _vpn_geo_window(
            "VPNManager.PublicIP",
            "VPNManager.VPNPublicIP",
            "VPNManager.ExternalIP",
        ),
        _vpn_geo_backend(
            "PublicIP",
            "VPNPublicIP",
            "ExternalIP",
        ),
    )


    geo_location = _vpn_geo_window(
        "VPNManager.VPNExitLocation"
    )

    geo_network = _vpn_geo_window(
        "VPNManager.VPNExitNetwork"
    )


    geo_city = ""
    geo_country = ""

    if geo_location:
        parts = [
            part.strip()
            for part in geo_location.split(",")
            if part.strip()
        ]

        if parts:
            geo_city = parts[0]

        if len(parts) >= 2:
            geo_country = parts[-1]


    selected_city_norm = (
        _vpn_geo_clean_place(
            selected_city
        )
    )

    selected_country_norm = (
        _vpn_geo_clean_place(
            selected_country
        )
    )

    geo_city_norm = (
        _vpn_geo_clean_place(
            geo_city
        )
    )

    geo_country_norm = (
        _vpn_geo_clean_place(
            geo_country
        )
    )


    city_match = (
        bool(selected_city_norm)
        and bool(geo_city_norm)
        and selected_city_norm
        == geo_city_norm
    )

    country_match = (
        bool(selected_country_norm)
        and bool(geo_country_norm)
        and selected_country_norm
        == geo_country_norm
    )

    if city_match and country_match:
        verdict = "city_country_match"
        location_verification = "Match"

    elif country_match:
        verdict = (
            "city_mismatch_country_match"
        )

        location_verification = (
            "Country match; city differs"
        )

    elif (
        selected_country_norm
        and geo_country_norm
    ):
        verdict = "country_mismatch"
        location_verification = "Mismatch"

    elif city_match:
        verdict = (
            "city_match_country_unverified"
        )

        location_verification = (
            "City match; country unverified"
        )

    else:
        verdict = "location_unverified"
        location_verification = "Unverified"


    endpoint_public_same = (
        bool(server_endpoint)
        and bool(public_ip)
        and server_endpoint.strip()
        == public_ip.strip()
    )


    values = {
        "VPNManager.DiagnosticSelectedProfile":
            selected_name,

        "VPNManager.DiagnosticSelectedCity":
            selected_city,

        "VPNManager.DiagnosticSelectedCountry":
            selected_country,

        "VPNManager.DiagnosticServer":
            server_endpoint,

        "VPNManager.DiagnosticPublicIP":
            public_ip,

        "VPNManager.DiagnosticGeoLocation":
            geo_location,

        "VPNManager.DiagnosticGeoNetwork":
            geo_network,

        "VPNManager.DiagnosticGeoVerdict":
            verdict,

        "VPNManager.LocationVerification":
            location_verification,

        "VPNManager.DiagnosticEndpointEqualsPublic":
            (
                "true"
                if endpoint_public_same
                else "false"
            ),
    }


    for key, value in values.items():
        WINDOW.setProperty(
            key,
            str(value or ""),
        )


    try:
        xbmc.log(
            (
                "VPN Manager diagnostic: "
                "profile={!r}; "
                "server={!r}; "
                "public_ip={!r}; "
                "geo={!r}; "
                "verdict={}"
            ).format(
                selected_name,
                _vpn_geo_mask_ip(
                    server_endpoint
                ),
                _vpn_geo_mask_ip(
                    public_ip
                ),
                geo_location,
                verdict,
            ),
            xbmc.LOGINFO,
        )

    except Exception:
        pass


# VPN_GEO_DIAGNOSTIC_RESYNC_BEGIN

_vpn_geo_sync_lock = threading.Lock()
_vpn_geo_sync_generation = 0


def _vpn_geo_value_pending(value):
    value = str(
        value or ""
    ).strip().casefold()

    return (
        not value
        or value in (
            "updating",
            "updating...",
            "refreshing",
            "refreshing...",
            "checking",
            "checking...",
            "checking now",
            "checking now...",
            "unavailable",
            "unknown",
            "n/a",
            "na",
            "none",
            "-",
        )
    )


def _vpn_schedule_geo_diagnostic_sync():
    global _vpn_geo_sync_generation

    try:
        with _vpn_geo_sync_lock:
            _vpn_geo_sync_generation += 1

            generation = (
                _vpn_geo_sync_generation
            )

    except Exception:
        return


    def worker():
        last_geo = ""
        stable_count = 0

        try:
            monitor = xbmc.Monitor()

            # GeoIP can finish after the backend's main
            # refresh flag has already cleared.
            #
            # Do not trust the first non-pending value:
            # immediately after a profile switch it may
            # still be the previous profile's location.
            for delay in (
                1.50,
                1.00,
                1.00,
                1.00,
                1.50,
                2.00,
                3.00,
                4.00,
            ):
                if _vpn_dashboard_worker_wait(
                    monitor,
                    delay,
                ):
                    return

                with _vpn_geo_sync_lock:
                    if (
                        generation
                        != _vpn_geo_sync_generation
                    ):
                        return

                geo = str(
                    WINDOW.getProperty(
                        "VPNManager.VPNExitLocation"
                    )
                    or ""
                ).strip()

                if _vpn_geo_value_pending(
                    geo
                ):
                    last_geo = ""
                    stable_count = 0
                    continue

                if geo == last_geo:
                    stable_count += 1
                else:
                    last_geo = geo
                    stable_count = 1

                # Require the same settled location on
                # two consecutive checks. This prevents
                # stale Toronto data, for example, from
                # being accepted immediately after a
                # switch to Road Town.
                if stable_count >= 2:
                    _vpn_publish_geo_diagnostic()
                    return

            # If GeoIP never settles, publish one final
            # diagnostic so the dashboard accurately
            # remains Unverified instead of retaining a
            # stale result.
            _vpn_publish_geo_diagnostic()

        except Exception:
            pass


    try:
        _vpn_start_dashboard_worker(
            target=worker,
            name="VPNGeoDiagnosticSync",
        )

    except Exception:
        pass



# VPN_GEO_DIAGNOSTIC_RESYNC_END


def publish_dashboard_properties():
    _publish_dashboard_core()

    publish_system_metrics()

    # Publish the selected-profile country flag once,
    # after the core dashboard and metrics refresh.
    selected_flag = ""

    try:
        data = profiles.load(
            REGISTRY
        )

        selected = profiles.selected_profile(
            data
        )

        if selected:
            selected_flag = _country_flag_path(
                selected.get(
                    "country",
                    "",
                )
            )

    except Exception:
        selected_flag = ""

    WINDOW.clearProperty(
        "VPNManager.SelectedCountryFlag"
    )

    if selected_flag:
        WINDOW.setProperty(
            "VPNManager.SelectedCountryFlag",
            selected_flag,
        )

    # Publish the observed exit-country flag once.
    #
    # Explicitly writing an empty value preserves the
    # previous dashboard chain's behavior when the
    # refreshed location is unavailable or unresolved.
    exit_location = str(
        WINDOW.getProperty(
            "VPNManager.VPNExitLocation"
        )
        or ""
    ).strip()

    exit_flag = _country_flag_from_location(
        exit_location
    )

    WINDOW.setProperty(
        "VPNManager.ExitCountryFlag",
        exit_flag,
    )

    try:
        _vpn_publish_geo_diagnostic()

    except Exception:
        pass

    try:
        _vpn_schedule_geo_diagnostic_sync()

    except Exception:
        pass


# VPN_GEO_DIAGNOSTIC_END


if __name__ == "__main__":
    main()
