import sys

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.backend_loader import get_backend
from resources.lib.log_privacy import install_log_filter


install_log_filter()

ADDON = xbmcaddon.Addon(
    "service.vpn.manager"
)
DIALOG = xbmcgui.Dialog()
WINDOW = xbmcgui.Window(10000)
BACKEND = get_backend()

PROTECTION_SETTING_ID = (
    "protection_enabled"
)
REFRESH_PROPERTY = (
    "VPNManager.ProtectionRefresh"
)


def _set_mirror(enabled):
    try:
        ADDON.setSettingBool(
            PROTECTION_SETTING_ID,
            bool(enabled),
        )

    except Exception:
        ADDON.setSetting(
            PROTECTION_SETTING_ID,
            "true" if enabled else "false",
        )


def _disabled():
    check = getattr(
        BACKEND,
        "protection_disabled",
        None,
    )

    if not check:
        return False

    try:
        return bool(check())

    except Exception:
        return False


def _request_service_refresh(state="refresh"):
    #
    # The persistent service consumes this property on
    # its existing one-second loop.
    #
    try:
        WINDOW.setProperty(
            REFRESH_PROPERTY,
            state,
        )

    except Exception:
        pass


def _offer_save_and_exit(message):
    #
    # Protection itself has already been committed.
    # This question applies only to other pending
    # changes in Kodi's add-on Settings dialog.
    #
    save = DIALOG.yesno(
        "VPN Manager Settings",
        message + (
            "\n\nSave other settings and exit?"
        ),
        nolabel="No",
        yeslabel="Yes",
    )

    if not save:
        return

    #
    # Kodi's Add-on Settings dialog is window 10140.
    # Control 28 is its OK/commit button. SendClick
    # therefore follows the same path as the user
    # pressing OK instead of generically closing the
    # dialog.
    #
    xbmc.executebuiltin(
        "SendClick(10140,28)"
    )


def _normalize_result(result):
    if isinstance(result, dict):
        return result

    return {
        "ok": False,
        "message": "Invalid backend result",
    }


def _call_backend(name):
    method = getattr(
        BACKEND,
        name,
        None,
    )

    if not method:
        return {
            "ok": False,
            "message":
                "{} unsupported".format(name),
        }

    try:
        return _normalize_result(
            method()
        )

    except Exception as exc:
        return {
            "ok": False,
            "message": str(exc),
        }


def _disable():
    #
    # Never infer success from the requested action.
    # The backend's persistent disabled marker is the
    # authority.
    #
    if _disabled():
        _set_mirror(False)
        _request_service_refresh()
        return

    confirmed = DIALOG.yesno(
        "Disable VPN Protection",
        (
            "Turn VPN protection OFF?\n\n"
            "Normal ISP Internet access will be "
            "allowed and automatic VPN reconnect "
            "will be suppressed until protection "
            "is turned back ON."
        ),
    )

    if not confirmed:
        #
        # Nothing was changed, so there is nothing
        # to roll back.
        #
        _set_mirror(True)
        _request_service_refresh()
        return

    _offer_save_and_exit(
        "VPN protection will now be turned OFF."
    )

    result = _call_backend(
        "disable_protection"
    )

    disabled_now = _disabled()

    if result.get("ok") and disabled_now:
        _set_mirror(False)
        _request_service_refresh()

        xbmc.log(
            "Kodi VPN Manager: immediate protection "
            "disable completed",
            xbmc.LOGINFO,
        )

        return

    #
    # A failed disable must not leave the UI claiming
    # protection is OFF unless the backend really did
    # enter deliberate-disabled mode.
    #
    _set_mirror(
        not disabled_now
    )
    _request_service_refresh()

    DIALOG.notification(
        "VPN Protection",
        (
            "Disable did not complete. "
            "Protected mode is being restored."
        ),
        xbmcgui.NOTIFICATION_ERROR,
        6000,
    )


def _enable():
    if not _disabled():
        _set_mirror(True)
        _request_service_refresh()
        return

    _offer_save_and_exit(
        "VPN protection will now be restored."
    )

    #
    # Publish the requested protected mode before the
    # backend operation so the Settings dependency can
    # switch away from the Enable action immediately.
    #
    _set_mirror(True)

    #
    # Request a latched Connecting presentation before
    # entering the synchronous backend transaction.
    #
    _request_service_refresh(
        "connecting"
    )

    result = _call_backend(
        "enable_protection"
    )

    still_disabled = _disabled()

    if result.get("ok") and not still_disabled:
        _set_mirror(True)
        _request_service_refresh()

        xbmc.log(
            "Kodi VPN Manager: immediate protection "
            "enable completed",
            xbmc.LOGINFO,
        )

        return

    if still_disabled:
        #
        # The fail-closed guard could not be armed.
        # Deliberately-disabled mode remains real.
        #
        _set_mirror(False)
        _request_service_refresh()

        DIALOG.notification(
            "VPN Protection",
            (
                "Could not enable protection. "
                "Protection remains OFF."
            ),
            xbmcgui.NOTIFICATION_ERROR,
            6000,
        )
        return

    #
    # Disabled mode was exited, but the backend did
    # not fully verify the VPN. Protected/fail-closed
    # mode remains requested and the service will
    # publish the resulting fault/connecting state.
    #
    _set_mirror(True)
    _request_service_refresh()

    DIALOG.notification(
        "VPN Protection",
        (
            "Protected mode was restored, but "
            "the VPN did not fully verify."
        ),
        xbmcgui.NOTIFICATION_ERROR,
        6000,
    )


def main():
    action_name = (
        sys.argv[1].strip().lower()
        if len(sys.argv) > 1
        else ""
    )

    if action_name == "disable":
        _disable()
        return

    if action_name == "enable":
        _enable()
        return

    xbmc.log(
        "Kodi VPN Manager: unknown protection "
        "action '{}'".format(action_name),
        xbmc.LOGERROR,
    )


if __name__ == "__main__":
    main()
