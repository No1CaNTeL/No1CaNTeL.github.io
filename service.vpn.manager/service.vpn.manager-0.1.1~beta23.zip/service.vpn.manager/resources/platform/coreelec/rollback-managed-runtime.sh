#!/bin/sh

set -u

CFG="/storage/.config"
SYSTEMD="$CFG/system.d"

LOCK_DIR="/run/vpn-manager-runtime.lock"

RUNTIME_ROOT="$CFG/vpn-manager"
BACKUP_ROOT="$CFG/vpn-manager-migration-backup"
STATE_FILE="$BACKUP_ROOT/state.env"

OLD_SELECTOR_SERVICE="vpn-selector.service"
OLD_SELECTOR_TIMER="vpn-selector.timer"

NEW_SELECTOR_SERVICE="vpn-manager-selector.service"
NEW_SELECTOR_TIMER="vpn-manager-selector.timer"

OPENVPN_SERVICE="vpn-manager-openvpn.service"

NEW_SELECTOR_UNIT="$SYSTEMD/$NEW_SELECTOR_SERVICE"
NEW_SELECTOR_TIMER_UNIT="$SYSTEMD/$NEW_SELECTOR_TIMER"
OPENVPN_UNIT="$SYSTEMD/$OPENVPN_SERVICE"

usage()
{
    printf '%s\n' \
        "Usage: $0 --check | --apply"
}

fail()
{
    printf 'ERROR: %s\n' "$1" >&2
    exit 1
}

release_lock()
{
    rm -rf "$LOCK_DIR"
}


acquire_lock()
{
    if mkdir "$LOCK_DIR" 2>/dev/null; then
        :
    else
        OWNER="$(
            cat "$LOCK_DIR/pid" 2>/dev/null ||
            true
        )"

        if [ -n "$OWNER" ] &&
           kill -0 "$OWNER" 2>/dev/null; then
            fail \
                "Another VPN Manager runtime operation is active."
        fi

        rm -rf "$LOCK_DIR"

        mkdir "$LOCK_DIR" 2>/dev/null ||
            fail \
                "Could not acquire VPN Manager runtime lock."
    fi

    printf '%s\n' "$$" > "$LOCK_DIR/pid" ||
        fail "Could not record runtime lock owner."

    trap 'release_lock' EXIT
    trap 'exit 130' INT
    trap 'exit 143' HUP TERM
}

unit_active()
{
    systemctl is-active "$1" >/dev/null 2>&1
}

main_pid()
{
    systemctl show "$1" \
        -p MainPID \
        2>/dev/null |
        awk -F= '/^MainPID=/{print $2}'
}

MODE="${1:---check}"

case "$MODE" in
    --check|--apply)
        ;;
    *)
        usage
        exit 2
        ;;
esac

[ "$(id -u)" = "0" ] ||
    fail "Managed runtime rollback must run as root."

acquire_lock

for CMD in \
    systemctl \
    awk \
    cp \
    chmod \
    rm
do
    command -v "$CMD" >/dev/null 2>&1 ||
        fail "Required command not found: $CMD"
done

[ -f "$STATE_FILE" ] ||
    fail "Migration rollback state not found."

# shellcheck disable=SC1090
. "$STATE_FILE"

OPENVPN_ACTIVE_NOW=0
unit_active "$OPENVPN_SERVICE" &&
    OPENVPN_ACTIVE_NOW=1

OPENVPN_PID_NOW="$(
    main_pid "$OPENVPN_SERVICE"
)"

printf '%s\n' \
    "VPN Manager managed-runtime rollback check"

printf 'original OpenVPN active: %s\n' \
    "$OPENVPN_ACTIVE"

printf 'current OpenVPN active: %s\n' \
    "$OPENVPN_ACTIVE_NOW"

if [ "$MODE" = "--check" ]; then
    printf '%s\n' "Rollback readiness: PASS"
    printf '%s\n' "No files or services were modified."
    exit 0
fi

systemctl stop "$NEW_SELECTOR_TIMER" \
    >/dev/null 2>&1 || true

systemctl disable "$NEW_SELECTOR_TIMER" \
    >/dev/null 2>&1 || true

systemctl disable "$NEW_SELECTOR_SERVICE" \
    >/dev/null 2>&1 || true

rm -f \
    "$NEW_SELECTOR_UNIT" \
    "$NEW_SELECTOR_TIMER_UNIT"

if [ "$OPENVPN_UNIT_PRESENT" = "1" ]; then
    [ -f "$BACKUP_ROOT/$OPENVPN_SERVICE" ] ||
        fail "Backed-up OpenVPN unit is missing."

    cp \
        "$BACKUP_ROOT/$OPENVPN_SERVICE" \
        "$OPENVPN_UNIT" ||
        fail "Could not restore OpenVPN unit."

    chmod 644 "$OPENVPN_UNIT" ||
        fail "Could not restore OpenVPN unit mode."
else
    rm -f "$OPENVPN_UNIT"
fi

rm -rf "$RUNTIME_ROOT"

systemctl daemon-reload ||
    fail "systemd daemon-reload failed."

if [ "$OLD_SELECTOR_ENABLED" = "1" ]; then
    systemctl enable "$OLD_SELECTOR_SERVICE" ||
        fail "Could not restore legacy selector enablement."
else
    systemctl disable "$OLD_SELECTOR_SERVICE" \
        >/dev/null 2>&1 || true
fi

if [ "$OLD_TIMER_ENABLED" = "1" ]; then
    systemctl enable "$OLD_SELECTOR_TIMER" ||
        fail "Could not restore legacy timer enablement."
else
    systemctl disable "$OLD_SELECTOR_TIMER" \
        >/dev/null 2>&1 || true
fi

if [ "$OLD_TIMER_ACTIVE" = "1" ]; then
    systemctl start "$OLD_SELECTOR_TIMER" ||
        fail "Could not restore legacy timer activity."
else
    systemctl stop "$OLD_SELECTOR_TIMER" \
        >/dev/null 2>&1 || true
fi

OPENVPN_ACTIVE_AFTER=0
unit_active "$OPENVPN_SERVICE" &&
    OPENVPN_ACTIVE_AFTER=1

OPENVPN_PID_AFTER="$(
    main_pid "$OPENVPN_SERVICE"
)"

if [ "$OPENVPN_ACTIVE" != "$OPENVPN_ACTIVE_AFTER" ]; then
    fail "OpenVPN active state changed during rollback."
fi

if [ "$OPENVPN_ACTIVE" = "1" ] &&
   [ "${OPENVPN_PID_NOW:-0}" != "${OPENVPN_PID_AFTER:-0}" ]; then
    fail "OpenVPN PID changed during rollback."
fi

printf '%s\n' "Managed runtime rollback: PASS"
printf '%s\n' "Existing OpenVPN process was not restarted."
printf '%s\n' "Legacy selector integration restored."
printf '%s\n' \
    "Migration backup retained for inspection."

exit 0
