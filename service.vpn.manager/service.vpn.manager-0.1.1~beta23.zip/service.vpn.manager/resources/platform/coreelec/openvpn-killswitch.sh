#!/bin/sh

IPT=/usr/sbin/iptables
IP6T=/usr/sbin/ip6tables
LAUNCHER="/storage/.config/vpn-manager/bin/vpn-manager-openvpn-launcher.py"
VPNIF="tun0"

redact_ip_stream()
{
    sed -E 's/([0-9]{1,3})\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/\1.x.x.x/g' |
    awk '
    function mask_ipv6(line, out, token, tmp, colons, first)
    {
        out = ""

        while (match(line, /[0-9A-Fa-f:]+/)) {
            out = out substr(line, 1, RSTART - 1)
            token = substr(line, RSTART, RLENGTH)
            tmp = token
            colons = gsub(/:/, ":", tmp)

            if (colons >= 2 && (colons >= 3 || token ~ /::/ || token ~ /[A-Fa-f]/)) {
                first = token
                sub(/:.*/, "", first)

                if (first == "") {
                    out = out "x"
                } else {
                    out = out first ":x"
                }
            } else {
                out = out token
            }

            line = substr(line, RSTART + RLENGTH)
        }

        return out line
    }

    {
        print mask_ipv6($0)
    }
    '
}

get_lan_context()
{
    LANIF=""
    LANIP=""
    LAN=""
    DEFAULT_IF=""

    #
    # Find a normal non-tunnel default interface when available.
    #
    DEFAULT_ROUTES="$(ip -4 route show table main default 2>/dev/null)"

    while IFS= read -r LINE
    do
        [ -n "$LINE" ] || continue

        set -- $LINE
        [ "${1:-}" = "default" ] || continue

        IFACE=""
        PREV=""

        for TOKEN in "$@"
        do
            if [ "$PREV" = "dev" ]; then
                IFACE="$TOKEN"
                break
            fi
            PREV="$TOKEN"
        done

        case "$IFACE" in
            ""|lo|tun*|tap*|wg*|ppp*|vpn*|docker*|veth*|tailscale*)
                continue
                ;;
        esac

        DEFAULT_IF="$IFACE"
        break
    done <<EOF
$DEFAULT_ROUTES
EOF

    #
    # Enumerate physical interfaces with global IPv4 addresses.
    # Try the ordinary default interface first, then any others.
    #
    ADDR_LINES="$(ip -o -4 addr show scope global 2>/dev/null)"

    for PASS in default others
    do
        while IFS= read -r LINE
        do
            [ -n "$LINE" ] || continue

            set -- $LINE
            IFACE="${2:-}"
            IFACE="${IFACE%%@*}"

            case "$IFACE" in
                ""|lo|tun*|tap*|wg*|ppp*|vpn*|docker*|veth*|tailscale*)
                    continue
                    ;;
            esac

            if [ "$PASS" = "default" ]; then
                [ -n "$DEFAULT_IF" ] || continue
                [ "$IFACE" = "$DEFAULT_IF" ] || continue
            else
                [ "$IFACE" != "$DEFAULT_IF" ] || continue
            fi

            if [ -r "/sys/class/net/$IFACE/carrier" ]; then
                CARRIER="$(cat "/sys/class/net/$IFACE/carrier" 2>/dev/null)"
                [ "$CARRIER" = "1" ] || continue
            fi

            ADDR_LINE="$(
                ip -o -4 addr show dev "$IFACE" \
                    scope global 2>/dev/null |
                    head -n 1
            )"

            [ -n "$ADDR_LINE" ] || continue

            set -- $ADDR_LINE
            CIDR="${4:-}"
            LANIP="${CIDR%/*}"

            [ -n "$LANIP" ] || continue

            LINK_ROUTES="$(
                ip -4 route show table main \
                    dev "$IFACE" scope link 2>/dev/null
            )"

            while IFS= read -r ROUTE_LINE
            do
                [ -n "$ROUTE_LINE" ] || continue

                set -- $ROUTE_LINE
                NETWORK="${1:-}"

                case "$NETWORK" in
                    ""|default)
                        continue
                        ;;
                esac

                SRCIP=""
                PREV=""

                for TOKEN in "$@"
                do
                    if [ "$PREV" = "src" ]; then
                        SRCIP="$TOKEN"
                        break
                    fi
                    PREV="$TOKEN"
                done

                [ "$SRCIP" = "$LANIP" ] || continue

                LANIF="$IFACE"
                LAN="$NETWORK"
                return 0
            done <<EOF
$LINK_ROUTES
EOF

        done <<EOF
$ADDR_LINES
EOF
    done

    return 1
}

get_network()
{
    get_lan_context || return 1

    DNSIP="$(
        awk '
            /^nameserver[[:space:]]+/ {
                print $2
                exit
            }
        ' /etc/resolv.conf
    )"

    [ -n "$LANIF" ] && [ -n "$LAN" ]
}


get_transports()
{
    "$LAUNCHER" --transport
}

case "$1" in
  transport)
    get_transports
    exit $?
    ;;

  up)
    get_network || {
        echo "ERROR: Cannot determine LAN interface/subnet"
        exit 1
    }


    TRANSPORTS="$(get_transports 2>/dev/null)" || {
        echo "ERROR: Cannot determine selected VPN transport."
        exit 1
    }

    [ -n "$TRANSPORTS" ] || {
        echo "ERROR: Selected VPN profile has no transport."
        exit 1
    }

    echo "OpenVPN kill switch:"
    echo " LAN interface: $LANIF"
    printf ' LAN subnet:    %s\n' "$LAN" | redact_ip_stream
    echo " VPN transport(s):"
    printf '%s\n' "$TRANSPORTS" |
        redact_ip_stream |
        sed 's/^/  /'

    $IPT -N CE_OVPN_KS 2>/dev/null || true
    $IPT -F CE_OVPN_KS

    while $IPT -D OUTPUT -j CE_OVPN_KS 2>/dev/null; do :; done

    # Local machine
    $IPT -A CE_OVPN_KS -o lo -j RETURN

    # Local LAN / SSH / Kodi LAN sources
    $IPT -A CE_OVPN_KS -o "$LANIF" -d "$LAN" -j RETURN

    # DHCP
    $IPT -A CE_OVPN_KS -o "$LANIF" \
        -p udp --sport 68 --dport 67 -j RETURN

    # Permit DNS through the physical interface only when routing requires it.
    # While tun0 is up, public DNS normally routes through the VPN instead.
    if [ -n "$DNSIP" ] && [ ! -f /run/x96-vpn-dns.locked ]; then
        $IPT -A CE_OVPN_KS -o "$LANIF" -d "$DNSIP" -p udp --dport 53 -j RETURN
        $IPT -A CE_OVPN_KS -o "$LANIF" -d "$DNSIP" -p tcp --dport 53 -j RETURN
    fi

    # Allow only the selected OpenVPN transport endpoint(s)
    while IFS='|' read -r VPNHOST VPNPORT VPNPROTO; do
        [ -n "$VPNHOST" ] || continue
        [ -n "$VPNPORT" ] || {
            echo "ERROR: Missing VPN port."
            exit 1
        }

        case "$VPNPROTO" in
            tcp*) VPNPROTO="tcp" ;;
            udp*) VPNPROTO="udp" ;;
            *)
                echo "ERROR: Unsupported VPN protocol: $VPNPROTO"
                exit 1
                ;;
        esac

        if echo "$VPNHOST" |
            grep -Eq '^[0-9]+(\.[0-9]+){3}$'; then
            VPNIPS="$VPNHOST"
        else
            VPNIPS="$(getent ahostsv4 "$VPNHOST" 2>/dev/null |
                awk '{print $1}' | sort -u)"
        fi

        [ -n "$VPNIPS" ] || {
            printf 'ERROR: Cannot resolve VPN endpoint: %s\n' \
                "$VPNHOST" | redact_ip_stream
            exit 1
        }

        for VPNIP in $VPNIPS; do
            $IPT -A CE_OVPN_KS -o "$LANIF" \
                -d "$VPNIP" -p "$VPNPROTO" \
                --dport "$VPNPORT" -j RETURN || exit 1
        done
    done <<EOF
$TRANSPORTS
EOF

    # Anything routed through OpenVPN is allowed
    $IPT -A CE_OVPN_KS -o "$VPNIF" -j RETURN

    # Everything else attempting to leave outside the tunnel is blocked
    $IPT -A CE_OVPN_KS -j REJECT

    $IPT -I OUTPUT 1 -j CE_OVPN_KS

    # IPv6 fail-closed protection.
    # Permit only local/link-local IPv6. Global IPv6 cannot bypass
    # the IPv4-only OpenVPN tunnel.
    $IP6T -N CE_OVPN_KS6 2>/dev/null || true
    $IP6T -F CE_OVPN_KS6

    while $IP6T -D OUTPUT -j CE_OVPN_KS6 2>/dev/null; do :; done

    $IP6T -A CE_OVPN_KS6 -o lo -j RETURN
    $IP6T -A CE_OVPN_KS6 -d fe80::/10 -j RETURN
    $IP6T -A CE_OVPN_KS6 -d ff00::/8 -j RETURN
    $IP6T -A CE_OVPN_KS6 -j REJECT

    $IP6T -I OUTPUT 1 -j CE_OVPN_KS6
    ;;

  down)
    while $IPT -D OUTPUT -j CE_OVPN_KS 2>/dev/null; do :; done
    $IPT -F CE_OVPN_KS 2>/dev/null || true
    $IPT -X CE_OVPN_KS 2>/dev/null || true

    while $IP6T -D OUTPUT -j CE_OVPN_KS6 2>/dev/null; do :; done
    $IP6T -F CE_OVPN_KS6 2>/dev/null || true
    $IP6T -X CE_OVPN_KS6 2>/dev/null || true
    ;;

  *)
    echo "Usage: $0 {up|down}"
    exit 1
    ;;
esac
