#!/bin/sh

set -u

SCRIPT_DIR="$(
    CDPATH= cd "$(dirname "$0")" 2>/dev/null &&
    pwd
)"

ADDON_ROOT="$(
    CDPATH= cd "$SCRIPT_DIR/../../.." 2>/dev/null &&
    pwd
)"

VERSION_FILE="$ADDON_ROOT/VERSION"

CFG="/storage/.config"
SYSTEMD="$CFG/system.d"

LOCK_DIR="/run/vpn-manager-runtime.lock"

RUNTIME_ROOT="$CFG/vpn-manager"
BIN_DIR="$RUNTIME_ROOT/bin"
MANIFEST="$RUNTIME_ROOT/manifest.json"

BACKUP_ROOT="$CFG/vpn-manager-migration-backup"
STATE_FILE="$BACKUP_ROOT/state.env"

OLD_SELECTOR_SERVICE="vpn-selector.service"
OLD_SELECTOR_TIMER="vpn-selector.timer"

NEW_SELECTOR_SERVICE="vpn-manager-selector.service"
NEW_SELECTOR_TIMER="vpn-manager-selector.timer"

OPENVPN_SERVICE="vpn-manager-openvpn.service"

OLD_SELECTOR_UNIT="$SYSTEMD/$OLD_SELECTOR_SERVICE"
OLD_SELECTOR_TIMER_UNIT="$SYSTEMD/$OLD_SELECTOR_TIMER"

NEW_SELECTOR_UNIT="$SYSTEMD/$NEW_SELECTOR_SERVICE"
NEW_SELECTOR_TIMER_UNIT="$SYSTEMD/$NEW_SELECTOR_TIMER"

OPENVPN_UNIT="$SYSTEMD/$OPENVPN_SERVICE"

usage()
{
    printf '%s\n' \
        "Usage: $0 --check | --apply"
}

fail()
{
    printf 'ERROR: %s\n' "$1" >&2
    exit 1
}

release_lock()
{
    rm -rf "$LOCK_DIR"
}


acquire_lock()
{
    if mkdir "$LOCK_DIR" 2>/dev/null; then
        :
    else
        OWNER="$(
            cat "$LOCK_DIR/pid" 2>/dev/null ||
            true
        )"

        if [ -n "$OWNER" ] &&
           kill -0 "$OWNER" 2>/dev/null; then
            fail \
                "Another VPN Manager runtime operation is active."
        fi

        rm -rf "$LOCK_DIR"

        mkdir "$LOCK_DIR" 2>/dev/null ||
            fail \
                "Could not acquire VPN Manager runtime lock."
    fi

    printf '%s\n' "$$" > "$LOCK_DIR/pid" ||
        fail "Could not record runtime lock owner."

    trap 'release_lock' EXIT
    trap 'exit 130' INT
    trap 'exit 143' HUP TERM
}

need_command()
{
    command -v "$1" >/dev/null 2>&1 ||
        fail "Required command not found: $1"
}

unit_enabled()
{
    systemctl is-enabled "$1" >/dev/null 2>&1
}

unit_active()
{
    systemctl is-active "$1" >/dev/null 2>&1
}

main_pid()
{
    systemctl show "$1" \
        -p MainPID \
        2>/dev/null |
        awk -F= '/^MainPID=/{print $2}'
}

atomic_install()
{
    SRC="$1"
    DEST="$2"
    MODE="$3"

    DEST_DIR="$(dirname "$DEST")"
    TMP="$DEST_DIR/.vpnmgr-install-$$-$(basename "$DEST")"

    mkdir -p "$DEST_DIR" ||
        return 1

    cp "$SRC" "$TMP" ||
        return 1

    chmod "$MODE" "$TMP" || {
        rm -f "$TMP"
        return 1
    }

    mv -f "$TMP" "$DEST" || {
        rm -f "$TMP"
        return 1
    }

    return 0
}

write_manifest()
{
    ADDON_VERSION="$(
        cat "$VERSION_FILE" 2>/dev/null ||
        printf '%s' "unknown"
    )"

    SELECTOR_HASH="$(
        sha256sum "$BIN_DIR/vpn-selector.sh" |
        awk '{print $1}'
    )"

    BOOT_HASH="$(
        sha256sum "$BIN_DIR/vpn-bootstrap-guard.sh" |
        awk '{print $1}'
    )"

    KILL_HASH="$(
        sha256sum "$BIN_DIR/openvpn-killswitch.sh" |
        awk '{print $1}'
    )"

    DNS_HASH="$(
        sha256sum "$BIN_DIR/openvpn-dns-lock.sh" |
        awk '{print $1}'
    )"

    LAUNCHER_HASH="$(
        sha256sum "$BIN_DIR/vpn-manager-openvpn-launcher.py" |
        awk '{print $1}'
    )"

    SELECTOR_UNIT_HASH="$(
        sha256sum "$NEW_SELECTOR_UNIT" |
        awk '{print $1}'
    )"

    TIMER_UNIT_HASH="$(
        sha256sum "$NEW_SELECTOR_TIMER_UNIT" |
        awk '{print $1}'
    )"

    OPENVPN_UNIT_HASH="$(
        sha256sum "$OPENVPN_UNIT" |
        awk '{print $1}'
    )"

    TMP="$RUNTIME_ROOT/.manifest-$$"

    cat > "$TMP" <<EOF
{
  "schema_version": 1,
  "addon_id": "service.vpn.manager",
  "addon_version": "$ADDON_VERSION",
  "runtime_root": "/storage/.config/vpn-manager",
  "files": {
    "bin/vpn-selector.sh": "$SELECTOR_HASH",
    "bin/vpn-bootstrap-guard.sh": "$BOOT_HASH",
    "bin/openvpn-killswitch.sh": "$KILL_HASH",
    "bin/openvpn-dns-lock.sh": "$DNS_HASH",
    "bin/vpn-manager-openvpn-launcher.py": "$LAUNCHER_HASH"
  },
  "units": {
    "vpn-manager-selector.service": "$SELECTOR_UNIT_HASH",
    "vpn-manager-selector.timer": "$TIMER_UNIT_HASH",
    "vpn-manager-openvpn.service": "$OPENVPN_UNIT_HASH"
  }
}
EOF

    chmod 600 "$TMP" ||
        return 1

    mv -f "$TMP" "$MANIFEST"
}

restore_after_failure()
{
    printf '%s\n' \
        "Migration failure detected — restoring host integration."

    systemctl stop "$NEW_SELECTOR_TIMER" \
        >/dev/null 2>&1 || true

    systemctl disable "$NEW_SELECTOR_TIMER" \
        >/dev/null 2>&1 || true

    systemctl disable "$NEW_SELECTOR_SERVICE" \
        >/dev/null 2>&1 || true

    rm -f \
        "$NEW_SELECTOR_UNIT" \
        "$NEW_SELECTOR_TIMER_UNIT"

    if [ "${OPENVPN_UNIT_PRESENT:-0}" = "1" ] &&
       [ -f "$BACKUP_ROOT/$OPENVPN_SERVICE" ]; then

        cp \
            "$BACKUP_ROOT/$OPENVPN_SERVICE" \
            "$OPENVPN_UNIT" ||
            true

        chmod 644 "$OPENVPN_UNIT" ||
            true
    else
        rm -f "$OPENVPN_UNIT"
    fi

    rm -rf "$RUNTIME_ROOT"

    systemctl daemon-reload \
        >/dev/null 2>&1 || true

    if [ "${OLD_SELECTOR_ENABLED:-0}" = "1" ]; then
        systemctl enable "$OLD_SELECTOR_SERVICE" \
            >/dev/null 2>&1 || true
    else
        systemctl disable "$OLD_SELECTOR_SERVICE" \
            >/dev/null 2>&1 || true
    fi

    if [ "${OLD_TIMER_ENABLED:-0}" = "1" ]; then
        systemctl enable "$OLD_SELECTOR_TIMER" \
            >/dev/null 2>&1 || true
    else
        systemctl disable "$OLD_SELECTOR_TIMER" \
            >/dev/null 2>&1 || true
    fi

    if [ "${OLD_TIMER_ACTIVE:-0}" = "1" ]; then
        systemctl start "$OLD_SELECTOR_TIMER" \
            >/dev/null 2>&1 || true
    fi

    printf '%s\n' "Automatic host rollback attempted."
}

MODE="${1:---check}"

case "$MODE" in
    --check|--apply)
        ;;
    *)
        usage
        exit 2
        ;;
esac

[ "$(id -u)" = "0" ] ||
    fail "Managed runtime migration must run as root."

acquire_lock

for CMD in \
    systemctl \
    sha256sum \
    python3 \
    awk \
    stat \
    dirname \
    cp \
    mv \
    chmod \
    mkdir \
    rm
do
    need_command "$CMD"
done

[ -f "$VERSION_FILE" ] ||
    fail "Addon VERSION file not found."

for FILE in \
    vpn-selector.sh \
    vpn-bootstrap-guard.sh \
    openvpn-killswitch.sh \
    openvpn-dns-lock.sh \
    vpn-manager-openvpn-launcher.py \
    vpn-manager-openvpn.service \
    vpn-manager-selector.service \
    vpn-manager-selector.timer
do
    [ -f "$SCRIPT_DIR/$FILE" ] ||
        fail "Packaged host file missing: $FILE"
done

for FILE in \
    vpn-selector.sh \
    vpn-bootstrap-guard.sh \
    openvpn-killswitch.sh \
    openvpn-dns-lock.sh
do
    sh -n "$SCRIPT_DIR/$FILE" ||
        fail "Shell validation failed: $FILE"
done

python3 - "$SCRIPT_DIR/vpn-manager-openvpn-launcher.py" <<'PY' ||
import pathlib
import sys

path = pathlib.Path(sys.argv[1])

compile(
    path.read_text(
        encoding="utf-8",
    ),
    str(path),
    "exec",
)
PY
    fail "Python launcher validation failed."

[ -f "$OLD_SELECTOR_UNIT" ] ||
    fail "Legacy selector unit is not present."

[ -f "$OLD_SELECTOR_TIMER_UNIT" ] ||
    fail "Legacy selector timer is not present."

[ ! -e "$RUNTIME_ROOT" ] ||
    fail "Managed runtime already exists."

[ ! -e "$NEW_SELECTOR_UNIT" ] ||
    fail "Managed selector unit already exists."

[ ! -e "$NEW_SELECTOR_TIMER_UNIT" ] ||
    fail "Managed selector timer already exists."

[ ! -e "$BACKUP_ROOT" ] ||
    fail "Migration backup already exists."

OLD_SELECTOR_ENABLED=0
OLD_TIMER_ENABLED=0
OLD_TIMER_ACTIVE=0
OPENVPN_ACTIVE=0
OPENVPN_UNIT_PRESENT=0

unit_enabled "$OLD_SELECTOR_SERVICE" &&
    OLD_SELECTOR_ENABLED=1

unit_enabled "$OLD_SELECTOR_TIMER" &&
    OLD_TIMER_ENABLED=1

unit_active "$OLD_SELECTOR_TIMER" &&
    OLD_TIMER_ACTIVE=1

unit_active "$OPENVPN_SERVICE" &&
    OPENVPN_ACTIVE=1

OPENVPN_PID_BEFORE="$(
    main_pid "$OPENVPN_SERVICE"
)"

[ -f "$OPENVPN_UNIT" ] &&
    OPENVPN_UNIT_PRESENT=1

printf '%s\n' \
    "VPN Manager managed-runtime migration check"

printf 'addon version: %s\n' \
    "$(cat "$VERSION_FILE")"

printf 'legacy selector enabled: %s\n' \
    "$OLD_SELECTOR_ENABLED"

printf 'legacy timer enabled: %s\n' \
    "$OLD_TIMER_ENABLED"

printf 'legacy timer active: %s\n' \
    "$OLD_TIMER_ACTIVE"

printf 'managed OpenVPN active: %s\n' \
    "$OPENVPN_ACTIVE"

if [ "$MODE" = "--check" ]; then
    printf '%s\n' "Migration readiness: PASS"
    printf '%s\n' "No files or services were modified."
    exit 0
fi

mkdir -p "$BACKUP_ROOT" ||
    fail "Could not create migration backup."

cat > "$STATE_FILE" <<EOF
OLD_SELECTOR_ENABLED=$OLD_SELECTOR_ENABLED
OLD_TIMER_ENABLED=$OLD_TIMER_ENABLED
OLD_TIMER_ACTIVE=$OLD_TIMER_ACTIVE
OPENVPN_ACTIVE=$OPENVPN_ACTIVE
OPENVPN_UNIT_PRESENT=$OPENVPN_UNIT_PRESENT
OPENVPN_PID_BEFORE=${OPENVPN_PID_BEFORE:-0}
EOF

chmod 600 "$STATE_FILE" ||
    fail "Could not protect migration state."

if [ "$OPENVPN_UNIT_PRESENT" = "1" ]; then
    cp \
        "$OPENVPN_UNIT" \
        "$BACKUP_ROOT/$OPENVPN_SERVICE" ||
        fail "Could not back up OpenVPN unit."

    chmod 600 \
        "$BACKUP_ROOT/$OPENVPN_SERVICE" ||
        fail "Could not protect OpenVPN unit backup."
fi

mkdir -p "$BIN_DIR" || {
    restore_after_failure
    fail "Could not create managed runtime."
}

for FILE in \
    vpn-selector.sh \
    vpn-bootstrap-guard.sh \
    openvpn-killswitch.sh \
    openvpn-dns-lock.sh \
    vpn-manager-openvpn-launcher.py
do
    atomic_install \
        "$SCRIPT_DIR/$FILE" \
        "$BIN_DIR/$FILE" \
        755 || {
            restore_after_failure
            fail "Could not install managed executable: $FILE"
        }
done

atomic_install \
    "$SCRIPT_DIR/vpn-manager-selector.service" \
    "$NEW_SELECTOR_UNIT" \
    644 || {
        restore_after_failure
        fail "Could not install managed selector unit."
    }

atomic_install \
    "$SCRIPT_DIR/vpn-manager-selector.timer" \
    "$NEW_SELECTOR_TIMER_UNIT" \
    644 || {
        restore_after_failure
        fail "Could not install managed selector timer."
    }

atomic_install \
    "$SCRIPT_DIR/vpn-manager-openvpn.service" \
    "$OPENVPN_UNIT" \
    644 || {
        restore_after_failure
        fail "Could not install managed OpenVPN unit."
    }

systemctl daemon-reload || {
    restore_after_failure
    fail "systemd daemon-reload failed."
}

if [ "$OLD_SELECTOR_ENABLED" = "1" ]; then
    systemctl enable "$NEW_SELECTOR_SERVICE" ||
    {
        restore_after_failure
        fail "Could not enable managed selector."
    }
else
    systemctl disable "$NEW_SELECTOR_SERVICE" \
        >/dev/null 2>&1 || true
fi

systemctl disable "$OLD_SELECTOR_SERVICE" || {
    restore_after_failure
    fail "Could not disable legacy selector."
}

if [ "$OLD_TIMER_ACTIVE" = "1" ]; then
    systemctl stop "$OLD_SELECTOR_TIMER" || {
        restore_after_failure
        fail "Could not stop legacy selector timer."
    }
fi

systemctl disable "$OLD_SELECTOR_TIMER" \
    >/dev/null 2>&1 || true

if [ "$OLD_TIMER_ENABLED" = "1" ]; then
    systemctl enable "$NEW_SELECTOR_TIMER" || {
        restore_after_failure
        fail "Could not enable managed selector timer."
    }
else
    systemctl disable "$NEW_SELECTOR_TIMER" \
        >/dev/null 2>&1 || true
fi

if [ "$OLD_TIMER_ACTIVE" = "1" ]; then
    systemctl start "$NEW_SELECTOR_TIMER" || {
        restore_after_failure
        fail "Could not start managed selector timer."
    }
fi

FAIL=0

for FILE in \
    vpn-selector.sh \
    vpn-bootstrap-guard.sh \
    openvpn-killswitch.sh \
    openvpn-dns-lock.sh \
    vpn-manager-openvpn-launcher.py
do
    SOURCE_HASH="$(
        sha256sum "$SCRIPT_DIR/$FILE" |
        awk '{print $1}'
    )"

    TARGET_HASH="$(
        sha256sum "$BIN_DIR/$FILE" |
        awk '{print $1}'
    )"

    MODE_NOW="$(
        stat -c '%a' "$BIN_DIR/$FILE" 2>/dev/null ||
        true
    )"

    if [ "$SOURCE_HASH" != "$TARGET_HASH" ] ||
       [ "$MODE_NOW" != "755" ]; then
        printf 'VERIFY FAIL: %s\n' "$FILE"
        FAIL=1
    fi
done

for SPEC in \
    "vpn-manager-selector.service:$NEW_SELECTOR_UNIT" \
    "vpn-manager-selector.timer:$NEW_SELECTOR_TIMER_UNIT" \
    "vpn-manager-openvpn.service:$OPENVPN_UNIT"
do
    NAME="${SPEC%%:*}"
    TARGET="${SPEC#*:}"

    SOURCE_HASH="$(
        sha256sum "$SCRIPT_DIR/$NAME" |
        awk '{print $1}'
    )"

    TARGET_HASH="$(
        sha256sum "$TARGET" |
        awk '{print $1}'
    )"

    MODE_NOW="$(
        stat -c '%a' "$TARGET" 2>/dev/null ||
        true
    )"

    if [ "$SOURCE_HASH" != "$TARGET_HASH" ] ||
       [ "$MODE_NOW" != "644" ]; then
        printf 'VERIFY FAIL: %s\n' "$NAME"
        FAIL=1
    fi
done

if [ "$OLD_SELECTOR_ENABLED" = "1" ]; then
    unit_enabled "$NEW_SELECTOR_SERVICE" ||
        FAIL=1
fi

if unit_enabled "$OLD_SELECTOR_SERVICE"; then
    FAIL=1
fi

if [ "$OLD_TIMER_ENABLED" = "1" ]; then
    unit_enabled "$NEW_SELECTOR_TIMER" ||
        FAIL=1
else
    if unit_enabled "$NEW_SELECTOR_TIMER"; then
        FAIL=1
    fi
fi

OPENVPN_ACTIVE_AFTER=0
unit_active "$OPENVPN_SERVICE" &&
    OPENVPN_ACTIVE_AFTER=1

OPENVPN_PID_AFTER="$(
    main_pid "$OPENVPN_SERVICE"
)"

if [ "$OPENVPN_ACTIVE" != "$OPENVPN_ACTIVE_AFTER" ]; then
    printf '%s\n' \
        "VERIFY FAIL: OpenVPN active state changed."
    FAIL=1
fi

if [ "$OPENVPN_ACTIVE" = "1" ] &&
   [ "${OPENVPN_PID_BEFORE:-0}" != "${OPENVPN_PID_AFTER:-0}" ]; then
    printf '%s\n' \
        "VERIFY FAIL: OpenVPN PID changed."
    FAIL=1
fi

if [ "$FAIL" -ne 0 ]; then
    restore_after_failure
    fail "Managed runtime verification failed."
fi

# The manifest is deliberately written LAST.
#
# Its presence means the runtime files, systemd ownership,
# service enablement and existing OpenVPN process have all
# already passed verification. Consumers may therefore use
# manifest existence as the managed-runtime completion marker.
write_manifest || {
    restore_after_failure
    fail "Could not write managed runtime manifest."
}

printf '%s\n' "Managed runtime migration: PASS"
printf '%s\n' "Existing OpenVPN process was not restarted."
printf '%s\n' "Legacy runtime files were retained for rollback."
printf 'manifest: %s\n' "$MANIFEST"
printf 'rollback state: %s\n' "$STATE_FILE"

exit 0
