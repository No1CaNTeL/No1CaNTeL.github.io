import ipaddress
import os
import re
import threading
from datetime import datetime

import xbmc


_IPV4_RE = re.compile(
    r"(?<![\w.])"
    r"((?:\d{1,3}\.){3}\d{1,3})"
    r"(?![\w.])"
)

_IPV6_RE = re.compile(
    r"(?<![0-9A-Fa-f:])"
    r"((?:[0-9A-Fa-f]{0,4}:){2,7}"
    r"[0-9A-Fa-f]{0,4})"
    r"(?![0-9A-Fa-f:])"
)


_show_full_ipv4_logs = False
_show_full_ipv6_logs = False

_dedicated_log_enabled = False
_dedicated_log_path = ""
_dedicated_log_manage_rotation = False

_dedicated_log_lock = threading.Lock()

DEDICATED_LOG_MAX_BYTES = 1024 * 1024
DEDICATED_LOG_BACKUPS = 3



def set_full_ipv4_logging_enabled(enabled):
    global _show_full_ipv4_logs

    _show_full_ipv4_logs = bool(enabled)


def set_full_ipv6_logging_enabled(enabled):
    global _show_full_ipv6_logs

    _show_full_ipv6_logs = bool(enabled)

def set_dedicated_log_enabled(
    enabled,
    path="",
    manage_rotation=False,
):
    global _dedicated_log_enabled
    global _dedicated_log_path
    global _dedicated_log_manage_rotation

    with _dedicated_log_lock:
        _dedicated_log_enabled = bool(enabled)

        if path:
            _dedicated_log_path = str(path)

        _dedicated_log_manage_rotation = bool(
            manage_rotation
        )

        active = (
            _dedicated_log_enabled
            and bool(_dedicated_log_path)
        )

        if active:
            try:
                directory = os.path.dirname(
                    _dedicated_log_path
                )

                if directory:
                    os.makedirs(
                        directory,
                        exist_ok=True,
                    )

            except Exception:
                return False

        return active


def _log_level_name(level):
    mapping = {
        getattr(
            xbmc,
            "LOGDEBUG",
            0,
        ): "DEBUG",
        getattr(
            xbmc,
            "LOGINFO",
            1,
        ): "INFO",
        getattr(
            xbmc,
            "LOGWARNING",
            2,
        ): "WARNING",
        getattr(
            xbmc,
            "LOGERROR",
            3,
        ): "ERROR",
        getattr(
            xbmc,
            "LOGFATAL",
            4,
        ): "FATAL",
    }

    return mapping.get(
        level,
        "LOG{}".format(level),
    )


def _rotate_dedicated_log(path):
    try:
        if not os.path.isfile(path):
            return

        if (
            os.path.getsize(path)
            < DEDICATED_LOG_MAX_BYTES
        ):
            return

        oldest = "{}.{}".format(
            path,
            DEDICATED_LOG_BACKUPS,
        )

        if os.path.exists(oldest):
            os.remove(oldest)

        for index in range(
            DEDICATED_LOG_BACKUPS - 1,
            0,
            -1,
        ):
            source = "{}.{}".format(
                path,
                index,
            )

            target = "{}.{}".format(
                path,
                index + 1,
            )

            if os.path.exists(source):
                os.replace(
                    source,
                    target,
                )

        os.replace(
            path,
            path + ".1",
        )

    except Exception:
        # Diagnostic logging must never interfere
        # with VPN Manager operation.
        pass


def _write_dedicated_log(
    message,
    level,
):
    if (
        not _dedicated_log_enabled
        or not _dedicated_log_path
    ):
        return

    try:
        timestamp = (
            datetime.now()
            .strftime(
                "%Y-%m-%d %H:%M:%S.%f"
            )[:-3]
        )

        line = (
            "{} [{}] {}\n".format(
                timestamp,
                _log_level_name(level),
                str(message),
            )
        )

        with _dedicated_log_lock:
            if _dedicated_log_manage_rotation:
                _rotate_dedicated_log(
                    _dedicated_log_path
                )

            directory = os.path.dirname(
                _dedicated_log_path
            )

            if directory:
                os.makedirs(
                    directory,
                    exist_ok=True,
                )

            with open(
                _dedicated_log_path,
                "a",
                encoding="utf-8",
            ) as handle:
                handle.write(line)

    except Exception:
        # File logging is optional and must be
        # completely fail-safe.
        pass


def _mask_ipv6(match):
    value = match.group(1)

    try:
        address = ipaddress.ip_address(
            value
        )
    except ValueError:
        return value

    if address.version != 6:
        return value

    first = (
        address.exploded
        .split(":", 1)[0]
        .lstrip("0")
        or "0"
    )

    return (
        first
        + ":x:x:x:x:x:x:x"
    )


def _mask_ipv4(match):
    value = match.group(1)

    try:
        address = ipaddress.ip_address(
            value
        )
    except ValueError:
        return value

    if address.version != 4:
        return value

    first = value.split(".", 1)[0]

    return "{}.x.x.x".format(
        first
    )



def redact_ips(
    message,
    redact_ipv4=True,
    redact_ipv6=True,
):
    text = str(message)

    if redact_ipv6:
        text = _IPV6_RE.sub(
            _mask_ipv6,
            text,
        )

    if redact_ipv4:
        text = _IPV4_RE.sub(
            _mask_ipv4,
            text,
        )

    return text

def install_log_filter():
    current = xbmc.log

    if getattr(
        current,
        "_vpn_manager_privacy_filter",
        False,
    ):
        return

    original = current

    def filtered_log(
        message,
        level=xbmc.LOGDEBUG,
    ):
        text = redact_ips(
            message,
            redact_ipv4=not _show_full_ipv4_logs,
            redact_ipv6=not _show_full_ipv6_logs,
        )

        original(
            text,
            level,
        )

        _write_dedicated_log(
            text,
            level,
        )

    filtered_log._vpn_manager_privacy_filter = True
    filtered_log._vpn_manager_original = original

    xbmc.log = filtered_log
