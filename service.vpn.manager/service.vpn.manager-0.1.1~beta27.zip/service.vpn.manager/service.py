import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from resources.lib.backend_loader import (
    backend_capabilities,
    get_backend,
    platform_name,
)
from resources.lib import netverify
from resources.lib import profiles

from resources.lib.log_privacy import (
    install_log_filter,
    set_dedicated_log_enabled,
    set_full_ipv4_logging_enabled,
    set_full_ipv6_logging_enabled,
)

# Install IP redaction before backend/service logging begins.
install_log_filter()

backend = get_backend()
PLATFORM = platform_name()
CAPABILITIES = backend_capabilities(backend)


def _ensure_backend_host_runtime():
    ensure = getattr(
        backend,
        "ensure_host_runtime",
        None,
    )

    if not ensure:
        return

    try:
        result = ensure()

    except Exception as exc:
        xbmc.log(
            "Kodi VPN Manager: host runtime "
            "initialization failed: {}".format(
                exc
            ),
            xbmc.LOGERROR,
        )
        return

    if not isinstance(result, dict):
        return

    action = result.get(
        "action",
        "unknown",
    )

    if result.get("ok"):
        if action not in (
            "not_applicable",
            "sync",
        ):
            xbmc.log(
                "Kodi VPN Manager: host runtime "
                "{} completed".format(action),
                xbmc.LOGINFO,
            )

        return

    xbmc.log(
        "Kodi VPN Manager: host runtime "
        "initialization failed: {}".format(
            result.get(
                "message",
                "unknown error",
            )
        ),
        xbmc.LOGERROR,
    )


_ensure_backend_host_runtime()

import time
import os
import threading
import struct


window = xbmcgui.Window(10000)


ADDON = xbmcaddon.Addon(
    "service.vpn.manager"
)

FULL_IPV4_LOG_SETTING_ID = (
    "debug_show_full_ipv4_logs"
)

FULL_IPV6_LOG_SETTING_ID = (
    "debug_show_full_ipv6_logs"
)

DEDICATED_LOG_SETTING_ID = (
    "debug_enable_dedicated_log"
)

ADDON_PROFILE_PATH = xbmcvfs.translatePath(
    ADDON.getAddonInfo("profile")
)

DEDICATED_LOG_PATH = os.path.join(
    ADDON_PROFILE_PATH,
    "vpn-manager.log",
)


def _sync_local_lan_policy():
    """Synchronize the Kodi LAN setting with the effective CoreELEC policy."""
    requested = ADDON.getSettingBool("allow_local_lan")
    apply_policy = getattr(backend, "apply_allow_local_lan_policy", None)

    if not callable(apply_policy):
        xbmc.log(
            "Kodi VPN Manager: LAN policy startup sync "
            "unavailable: transactional backend API missing",
            xbmc.LOGERROR,
        )
        return

    try:
        result = apply_policy(requested)
    except Exception as exc:
        xbmc.log(
            "Kodi VPN Manager: LAN policy startup sync "
            "failed: {}".format(exc),
            xbmc.LOGERROR,
        )
        result = {
            "ok": False,
            "action": "exception",
        }

    if result.get("ok"):
        return

    xbmc.log(
        "Kodi VPN Manager: LAN policy startup sync "
        "failed: {}".format(result),
        xbmc.LOGERROR,
    )

    effective_reader = getattr(backend, "allow_local_lan_policy", None)
    if not callable(effective_reader):
        return

    try:
        effective = bool(effective_reader())
    except Exception as exc:
        xbmc.log(
            "Kodi VPN Manager: LAN policy effective-state "
            "read failed: {}".format(exc),
            xbmc.LOGERROR,
        )
        return

    if effective == requested:
        return

    try:
        ADDON.setSettingBool("allow_local_lan", effective)
    except Exception:
        ADDON.setSetting(
            "allow_local_lan",
            "true" if effective else "false",
        )


_sync_local_lan_policy()



def _read_debug_bool_setting(setting_id):
    try:
        return ADDON.getSettingBool(
            setting_id
        )

    except Exception:
        try:
            value = ADDON.getSetting(
                setting_id
            )

        except Exception:
            return False

        return str(
            value
        ).strip().lower() in (
            "true",
            "1",
            "yes",
            "on",
        )


def _write_debug_bool_setting(
    setting_id,
    value,
):
    enabled = bool(value)

    try:
        ADDON.setSettingBool(
            setting_id,
            enabled,
        )

        return True

    except Exception:
        try:
            ADDON.setSetting(
                setting_id,
                "true" if enabled else "false",
            )

            return True

        except Exception:
            return False


def _set_full_ipv4_logging_setting(value):
    enabled = bool(value)

    set_full_ipv4_logging_enabled(
        enabled
    )

    return _write_debug_bool_setting(
        FULL_IPV4_LOG_SETTING_ID,
        enabled,
    )


def _set_full_ipv6_logging_setting(value):
    enabled = bool(value)

    set_full_ipv6_logging_enabled(
        enabled
    )

    return _write_debug_bool_setting(
        FULL_IPV6_LOG_SETTING_ID,
        enabled,
    )


def _sync_full_ipv4_logging_setting():
    enabled = _read_debug_bool_setting(
        FULL_IPV4_LOG_SETTING_ID
    )

    set_full_ipv4_logging_enabled(
        enabled
    )

    return enabled


def _sync_full_ipv6_logging_setting():
    enabled = _read_debug_bool_setting(
        FULL_IPV6_LOG_SETTING_ID
    )

    set_full_ipv6_logging_enabled(
        enabled
    )

    return enabled

def _read_dedicated_log_setting():
    try:
        return ADDON.getSettingBool(
            DEDICATED_LOG_SETTING_ID
        )

    except Exception:
        try:
            value = ADDON.getSetting(
                DEDICATED_LOG_SETTING_ID
            )

        except Exception:
            return False

        return str(
            value
        ).strip().lower() in (
            "true",
            "1",
            "yes",
            "on",
        )


def _sync_dedicated_log_setting():
    enabled = (
        _read_dedicated_log_setting()
    )

    set_dedicated_log_enabled(
        enabled,
        DEDICATED_LOG_PATH,
        manage_rotation=True,
    )

    return enabled


# Privacy failsafe: every persistent service start
# returns both address families to redacted mode.
_set_full_ipv4_logging_setting(False)
_set_full_ipv6_logging_setting(False)

# Dedicated diagnostic logging is persistent.
# Unlike full-IP mode, it remains enabled across
# service/Kodi restarts until the user turns it off.
_sync_dedicated_log_setting()


PROTECTION_SETTING_ID = (
    "protection_enabled"
)

PROTECTION_REFRESH_PROPERTY = (
    "VPNManager.ProtectionRefresh"
)

PROFILE_REGISTRY = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/"
    "profiles.json"
)


def _selected_requested_location():
    try:
        data = profiles.load(
            PROFILE_REGISTRY
        )

        selected = (
            profiles.selected_profile(
                data
            )
            or {}
        )

        options = (
            selected.get(
                "protocol_options"
            )
            or {}
        )

        city = str(
            options.get("city")
            or ""
        ).strip()

        country = str(
            selected.get(
                "country"
            )
            or ""
        ).strip()

        if (
            country.casefold()
            == "unassigned"
        ):
            country = ""

        country_code = str(
            options.get(
                "country_code"
            )
            or selected.get(
                "country_code"
            )
            or ""
        ).strip().upper()

        location_code = str(
            options.get(
                "location_code"
            )
            or ""
        ).strip()

        if (
            not country_code
            and country
            and len(
                location_code
            ) >= 2
            and location_code[
                :2
            ].isalpha()
        ):
            country_code = (
                location_code[
                    :2
                ].upper()
            )

        return (
            city,
            country,
            country_code,
        )

    except Exception:
        return "", "", ""


def set_protection_setting(value):
    try:
        ADDON.setSettingBool(
            PROTECTION_SETTING_ID,
            bool(value),
        )

    except Exception:
        ADDON.setSetting(
            PROTECTION_SETTING_ID,
            "true" if value else "false",
        )


def backend_protection_disabled():
    check = getattr(
        backend,
        "protection_disabled",
        None,
    )

    if not check:
        return False

    try:
        return bool(check())

    except Exception:
        return False


# Synchronize the UI with the authoritative backend state.
#
# A persistent deliberate-disabled marker means the toggle
# starts OFF. Otherwise protected mode is requested.
if getattr(
    backend,
    "protection_disabled",
    None,
):
    set_protection_setting(
        not backend_protection_disabled()
    )


class VFDVPNIndicator:
    """
    CoreELEC/OpenVFD VPN indicator.

    Existing defaults are preserved:

    protected:
        clock steady
        selected protected icon ON

    checking/switching:
        clock slow flash
        protected icon OFF

    fault/fail-closed:
        clock rapid flash
        protected icon OFF
    """

    LED_ON = (
        "/sys/class/leds/openvfd/led_on"
    )

    LED_OFF = (
        "/sys/class/leds/openvfd/led_off"
    )

    LED_CMD = (
        "/sys/class/leds/openvfd/led_cmd"
    )

    #
    # The setup indicator is intentionally excluded.
    # On the tested X96 Max+ it requires repeated
    # assertion, while these indicators work correctly
    # as one-shot states.
    #
    DEFAULT_ICON = "apps"

    ICONS = (
        "usb",
        "apps",
        "sd",
        "hdmi",
        "cvbs",
    )

    PATTERNS = (
        "steady",
        "slow",
        "rapid",
    )

    #
    # Same _IOW('M', 5, sizeof(int)) command used by
    # the installed CoreELEC/Kodi OpenVFD vfddev.py.
    # It must be written through led_cmd; direct ioctl
    # against /dev/openvfd is deliberately not used.
    #
    VFD_IOC_POWER = 0x40044D05


    def __init__(self):
        self.available = (
            os.path.exists(self.LED_ON)
            and os.path.exists(self.LED_OFF)
            and os.path.exists(self.LED_CMD)
        )

        self._addon = xbmcaddon.Addon(
            id="service.vpn.manager"
        )

        self._mode = "off"
        self._protected = False
        self._lit_icon = None

        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread = None


    def _setting(
        self,
        setting_id,
        default,
    ):
        try:
            value = self._addon.getSetting(
                setting_id
            )

            if value != "":
                return value

        except Exception:
            pass

        return default


    def enabled(self):
        value = self._setting(
            "front_panel_enabled",
            "true",
        )

        return str(
            value
        ).strip().lower() in (
            "1",
            "true",
            "yes",
            "on",
        )


    def _configured_icon(self):
        value = str(
            self._setting(
                "front_panel_protected_icon",
                self.DEFAULT_ICON,
            )
        ).strip().lower()

        if value not in self.ICONS:
            value = self.DEFAULT_ICON

        return value


    def _pattern(
        self,
        setting_id,
        default,
    ):
        value = str(
            self._setting(
                setting_id,
                default,
            )
        ).strip().lower()

        if value not in self.PATTERNS:
            value = default

        return value


    def _interval(
        self,
        mode,
    ):
        if mode == "slow":
            setting_id = (
                "front_panel_slow_interval"
            )

            default_ms = 750

        else:
            setting_id = (
                "front_panel_rapid_interval"
            )

            default_ms = 200

        try:
            milliseconds = int(
                self._setting(
                    setting_id,
                    str(default_ms),
                )
            )

        except (
            TypeError,
            ValueError,
        ):
            milliseconds = default_ms

        milliseconds = max(
            100,
            min(
                milliseconds,
                5000,
            ),
        )

        return (
            milliseconds
            / 1000.0
        )


    def start(self):
        if not self.available:
            return

        if (
            self._thread
            and self._thread.is_alive()
        ):
            return

        self._thread = threading.Thread(
            target=self._run,
            name="VPNManagerVFD",
            daemon=True,
        )

        self._thread.start()


    def set_state(
        self,
        state,
    ):
        if not self.available:
            return

        if not self.enabled():
            self.set_mode(
                "off",
                protected=False,
            )
            return

        if state == "protected":
            mode = self._pattern(
                "front_panel_protected_pattern",
                "steady",
            )

            protected = True

        elif state == "connecting":
            mode = self._pattern(
                "front_panel_connecting_pattern",
                "slow",
            )

            #
            # During connection attempts the selected
            # VPN icon flashes in phase with the clock.
            #
            protected = True

        elif state == "disabled":
            mode = self._pattern(
                "front_panel_disabled_pattern",
                "rapid",
            )

            protected = False

        else:
            mode = self._pattern(
                "front_panel_fault_pattern",
                "rapid",
            )

            protected = False

        self.set_mode(
            mode,
            protected=protected,
        )


    def set_mode(
        self,
        mode,
        protected=False,
    ):
        if not self.available:
            return

        if mode not in (
            "steady",
            "slow",
            "rapid",
            "off",
        ):
            mode = "rapid"

        self._mode = mode
        self._protected = bool(
            protected
        )

        self._wake.set()


    def _write_icon(
        self,
        icon,
        enabled,
    ):
        path = (
            self.LED_ON
            if enabled
            else self.LED_OFF
        )

        try:
            with open(
                path,
                "w",
                encoding="utf-8",
            ) as f:
                f.write(
                    icon + "\n"
                )

        except OSError:
            pass


    def _set_icon(
        self,
        enabled,
    ):
        icon = self._configured_icon()

        if enabled:
            if (
                self._lit_icon
                and self._lit_icon != icon
            ):
                self._write_icon(
                    self._lit_icon,
                    False,
                )

            self._write_icon(
                icon,
                True,
            )

            self._lit_icon = icon

        else:
            if self._lit_icon:
                self._write_icon(
                    self._lit_icon,
                    False,
                )

                self._lit_icon = None

            else:
                self._write_icon(
                    icon,
                    False,
                )


    def _set_display(
        self,
        enabled,
    ):
        """
        Control display power through OpenVFD's led_cmd
        interface.

        This matches the installed OpenVFD vfdDev path
        and has been verified on the target X96 Max+
        for OFF -> ON restoration.
        """
        try:
            payload = struct.pack(
                "Ii",
                self.VFD_IOC_POWER,
                1 if enabled else 0,
            )

            with open(
                self.LED_CMD,
                "wb",
                buffering=0,
            ) as f:
                f.write(
                    payload
                )

            return True

        except (
            OSError,
            struct.error,
        ):
            return False


    def _apply_visible_state(
        self,
        visible,
        show_icon,
    ):
        if not visible:
            #
            # Remove the VPN icon before blanking the
            # display so connecting flashes as one
            # synchronized panel state.
            #
            self._set_icon(
                False
            )

            self._set_display(
                False
            )

            return

        #
        # Native OpenVFDService remains alive and owns
        # the clock.
        #
        self._set_display(
            True
        )

        self._set_icon(
            show_icon
        )


    def _run(self):
        previous_mode = None
        previous_protected = None
        previous_icon = None

        visible = True

        while not self._stop.is_set():
            #
            # Clear the previous wake before taking the
            # state snapshot. Any state change after this
            # point sets the event again and cannot be
            # lost before the wait below.
            #
            self._wake.clear()

            mode = self._mode
            protected = self._protected

            configured_icon = (
                self._configured_icon()
            )

            changed = (
                mode != previous_mode
                or protected != previous_protected
                or configured_icon != previous_icon
            )

            if changed:
                previous_mode = mode
                previous_protected = protected
                previous_icon = configured_icon

                visible = True

                if mode == "off":
                    self._apply_visible_state(
                        True,
                        False,
                    )

                else:
                    self._apply_visible_state(
                        True,
                        protected,
                    )


            if mode in (
                "steady",
                "off",
            ):
                #
                # Normal operation is event driven.
                # No periodic VFD polling/reassertion.
                #
                if (
                    self._mode != mode
                    or self._protected != protected
                ):
                    continue

                self._wake.wait()
                continue


            interval = self._interval(
                mode
            )

            woke = self._wake.wait(
                interval
            )

            if self._stop.is_set():
                break

            if woke:
                continue

            #
            # Avoid emitting a stale flash transition
            # after a concurrent state change.
            #
            if (
                self._mode != mode
                or self._protected != protected
            ):
                continue

            visible = not visible

            self._apply_visible_state(
                visible,
                protected and visible,
            )


    def close(self):
        if not self.available:
            return

        self._mode = "off"
        self._protected = False

        self._stop.set()
        self._wake.set()

        if self._thread:
            self._thread.join(
                timeout=1.0
            )

        self._set_icon(
            False
        )

        #
        # Fail safe: never intentionally leave the
        # physical display powered off on shutdown.
        #
        self._set_display(
            True
        )


class VPNManagerMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        _sync_full_ipv4_logging_setting()
        _sync_full_ipv6_logging_setting()
        _sync_dedicated_log_setting()

        policy_applier = getattr(
            backend,
            "apply_allow_local_lan_policy",
            None,
        )

        if callable(policy_applier):
            try:
                allow_local = ADDON.getSettingBool(
                    "allow_local_lan"
                )
                policy_result = policy_applier(
                    allow_local
                )

                if not policy_result.get("ok"):
                    xbmc.log(
                        "Kodi VPN Manager: local LAN policy "
                        "application failed: {}".format(
                            policy_result.get(
                                "message",
                                policy_result.get(
                                    "action",
                                    "unknown error",
                                ),
                            )
                        ),
                        xbmc.LOGERROR,
                    )

                    effective_reader = getattr(
                        backend,
                        "allow_local_lan_policy",
                        None,
                    )

                    if callable(effective_reader):
                        effective = bool(
                            effective_reader()
                        )

                        if effective != allow_local:
                            try:
                                ADDON.setSettingBool(
                                    "allow_local_lan",
                                    effective,
                                )

                            except Exception:
                                ADDON.setSetting(
                                    "allow_local_lan",
                                    (
                                        "true"
                                        if effective
                                        else "false"
                                    ),
                                )

            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: local LAN policy "
                    "application failed: {}".format(exc),
                    xbmc.LOGERROR,
                )

        updater = globals().get(
            "update_vfd_vpn_indicator"
        )

        if updater:
            try:
                updater()

            except Exception:
                pass


monitor = VPNManagerMonitor()

vfd_indicator = VFDVPNIndicator()
vfd_indicator.start()


def update_vfd_vpn_indicator():
    if not vfd_indicator.available:
        return

    if not vfd_indicator.enabled():
        vfd_indicator.set_mode(
            "off",
            protected=False,
        )
        return

    #
    # A running selector means the protection path is
    # actively being checked/changed.
    #
    try:
        if backend.refresh_in_progress():
            vfd_indicator.set_state(
                "connecting"
            )
            return

    except Exception:
        pass


    #
    # Deliberately disabled protection gets its own
    # configurable front-panel state.
    #
    try:
        if backend_protection_disabled():
            vfd_indicator.set_state(
                "disabled"
            )
            return

    except Exception:
        pass


    #
    # Use the backend's existing verified VPN contract.
    #
    try:
        state = backend.vpn_state() or {}

    except Exception:
        vfd_indicator.set_state(
            "fault"
        )
        return


    if state.get(
        "backend_verified"
    ) is True:
        vfd_indicator.set_state(
            "protected"
        )
        return


    vfd_indicator.set_state(
        "fault"
    )


def setprop(name, value):
    window.setProperty(name, str(value) if value else "N/A")


def _dashboard_interface(value):
    text = str(value or "").strip()

    if "(" in text and text.endswith(")"):
        return text.rsplit("(", 1)[1][:-1].strip()

    if text in ("", "N/A", "Unknown"):
        return ""

    return text


def _dashboard_path(value):
    text = str(value or "Unknown").strip()
    lower = text.lower()

    if "router" in lower or "upstream" in lower:
        return "Router/Upstream"

    if "wireguard" in lower:
        return "Local WireGuard"

    if "local" in lower or "openvpn" in lower:
        return "Local OpenVPN"

    return text


def publish_dashboard_summary(state):
    state = state or {}

    status = str(
        state.get("status", "CHECK VPN")
    ).strip()

    path = _dashboard_path(
        state.get("path", "Unknown")
    )

    interface = _dashboard_interface(
        state.get("interface", "")
    )

    summary = "{} - {}".format(
        status,
        path
    )

    if interface:
        summary += " [{}]".format(interface)

    setprop(
        "VPNManager.StatusSummary",
        summary
    )

    path_lower = str(
        state.get("path", "")
    ).lower()

    status_lower = status.lower()

    if (
        (
            "local" in path_lower
            or "openvpn" in path_lower
            or "wireguard" in path_lower
        )
        and status_lower == "protected"
    ):
        activity = "Active"

    elif (
        ("router" in path_lower or "upstream" in path_lower)
        and status_lower == "protected"
    ):
        activity = "Standby"

    else:
        activity = "Inactive"

    setprop(
        "VPNManager.ProfileActivity",
        activity
    )


def publish_backend_state(state):
    state = state or {}

    publish_dashboard_summary(state)

    setprop("VPNManager.PublicIP", "Updating...")
    setprop("VPNManager.VPNExitLocation", "Updating...")
    setprop("VPNManager.VPNExitNetwork", "Updating...")
    setprop("VPNManager.VPNPath", state.get("path", "Unknown"))
    setprop("VPNManager.VPNStatus", state.get("status", "CHECK VPN"))
    setprop("VPNManager.VPNInterface", state.get("interface", "N/A"))
    setprop("VPNManager.VPNTunnelIP", state.get("tunnel_ip", "N/A"))
    setprop("VPNManager.VPNServer", state.get("server", "Unknown"))
    setprop("VPNManager.VPNKillSwitch", state.get("killswitch", "Unknown"))
    setprop(
        "VPNManager.VPNVerification",
        state.get("verification", "Backend state unavailable")
    )


def refresh():
    # Publish authoritative local/backend state first.
    # External IP classification is supplemental and must not delay
    # path/status/killswitch changes appearing in Kodi.
    backend_state = backend.vpn_state()
    publish_backend_state(backend_state)

    requested_city = ""
    requested_country = ""
    requested_country_code = ""

    if backend_state.get(
        "local_tunnel"
    ):
        (
            requested_city,
            requested_country,
            requested_country_code,
        ) = (
            _selected_requested_location()
        )

    external = (
        netverify.external_vpn_check(
            requested_city=
                requested_city,

            requested_country=
                requested_country,

            requested_country_code=
                requested_country_code,
        )
    )
    state = netverify.merge_state(
        backend_state,
        external
    )

    pub = external.get(
        "public_ip",
        "Unavailable"
    )

    path = state.get("path", "Unknown")
    status = state.get("status", "CHECK VPN")
    interface = state.get("interface", "N/A")
    tip = state.get("tunnel_ip", "N/A")
    server = state.get("server", "Unknown")
    killswitch = state.get("killswitch", "Unknown")
    verification = state.get(
        "verification",
        "Backend state unavailable"
    )

    setprop("VPNManager.PublicIP", pub)
    setprop(
        "VPNManager.VPNExitLocation",
        external.get("exit_location", "Unavailable")
    )
    setprop(
        "VPNManager.VPNExitNetwork",
        external.get("exit_network", "Unavailable")
    )
    setprop("VPNManager.VPNPath", path)
    setprop("VPNManager.VPNStatus", status)
    setprop("VPNManager.VPNInterface", interface)
    setprop("VPNManager.VPNTunnelIP", tip)
    setprop("VPNManager.VPNServer", server)
    setprop("VPNManager.VPNKillSwitch", killswitch)
    setprop("VPNManager.VPNVerification", verification)

    publish_dashboard_summary(state)

    xbmc.log(
        "Kodi VPN Manager: Public={} VPN={} Status={} Verify={}".format(
            pub,
            path,
            status,
            verification
        ),
        xbmc.LOGINFO
    )


AUTO_REFRESH_SECONDS = 300

FAILOVER_PROBE_SECONDS = 30
LOCAL_ROUTER_RECHECK_SECONDS = 120

# A CoreELEC firewall reload can remove VPN Manager's
# iptables chains without stopping OpenVPN/tun0.
PROTECTION_INTEGRITY_SECONDS = 10

WIREGUARD_HEALTH_SECONDS = 30
WIREGUARD_STALE_SECONDS = 180
WIREGUARD_STALE_CONFIRMATIONS = 3

# The VFD is presentation state. Do not spawn route/firewall
# verification subprocesses once per second merely to redraw it.
VFD_STATUS_SECONDS = 10
UNKNOWN_RECHECK_SECONDS = 60
PROBE_FAILURE_CONFIRMATIONS = 2

FAILED_RETRY_DELAYS = (
    30,
    60,
    120,
    300,
)

next_auto_refresh = (
    time.monotonic()
    + AUTO_REFRESH_SECONDS
)

next_failover_probe = (
    time.monotonic()
    + 10
)

next_protection_integrity_probe = (
    time.monotonic()
    + 5
)

def _wireguard_health_transition(
    stale_observations,
    health,
    confirmations=WIREGUARD_STALE_CONFIRMATIONS,
):
    """
    Pure state transition for passive WireGuard health
    observations. No runtime action is performed here.
    """
    try:
        stale_observations = max(
            0,
            int(stale_observations),
        )
    except (TypeError, ValueError):
        stale_observations = 0

    try:
        confirmations = max(
            1,
            int(confirmations),
        )
    except (TypeError, ValueError):
        confirmations = 1

    health = health or {}

    if not health.get("applicable"):
        return {
            "stale_observations": 0,
            "event": "inactive",
            "confirmed": False,
        }

    if health.get("status") == "healthy":
        return {
            "stale_observations": 0,
            "event": "healthy",
            "confirmed": False,
        }

    if health.get("stale"):
        stale_observations = min(
            confirmations,
            stale_observations + 1,
        )

        return {
            "stale_observations": stale_observations,
            "event": "stale",
            "confirmed": (
                stale_observations >= confirmations
            ),
        }

    return {
        "stale_observations": stale_observations,
        "event": "structural_failure",
        "confirmed": False,
    }



router_probe_failures = 0
detector_degraded = False
failed_retry_attempts = 0

wireguard_stale_observations = 0
wireguard_recovery_deferred = False
next_wireguard_health_probe = (
    time.monotonic()
    + WIREGUARD_HEALTH_SECONDS
)

last_state_token = backend.state_token()

#
# User-initiated protection transition latch.
#
# enable_protection() is synchronous. While that
# transaction is running, keep the front panel in
# Connecting until the action publishes final state.
#
protection_transition = None

# Initial display refresh, after backend state tracking exists.
refresh()
update_vfd_vpn_indicator()

next_vfd_status_probe = (
    time.monotonic()
    + VFD_STATUS_SECONDS
)

while not monitor.waitForAbort(1):

    vfd_now = time.monotonic()

    if vfd_now >= next_vfd_status_probe:
        if protection_transition != "connecting":
            update_vfd_vpn_indicator()

        next_vfd_status_probe = (
            vfd_now
            + VFD_STATUS_SECONDS
        )

    #
    # Protection integrity watchdog.
    #
    # Do not confuse "OpenVPN/tun0 still exists" with a fully
    # protected state. CoreELEC firewall reloads can flush the
    # CE_OVPN_KS jump while leaving the tunnel alive.
    #
    integrity_now = time.monotonic()

    watchdog_supported = all(
        callable(getattr(backend, name, None))
        for name in (
            "protection_disabled",
            "selector_state",
            "tunnel_exists",
            "kill_switch_active",
            "lightweight_router_probe",
            "failed_recovery_probe",
        )
    )

    if (
        watchdog_supported
        and integrity_now >= next_protection_integrity_probe
    ):

        try:
            integrity_disabled = bool(
                backend.protection_disabled()
            )
        except Exception:
            integrity_disabled = False

        try:
            integrity_refreshing = bool(
                backend.refresh_in_progress()
            )
        except Exception:
            integrity_refreshing = False

        if (
            not integrity_disabled
            and not integrity_refreshing
        ):
            try:
                integrity_local = (
                    backend.selector_state() == "local"
                    and backend.tunnel_exists()
                )

                integrity_killswitch = (
                    backend.kill_switch_active()
                )

            except Exception as exc:
                integrity_local = False
                integrity_killswitch = True

                xbmc.log(
                    "Kodi VPN Manager: protection integrity "
                    "check failed: {}".format(exc),
                    xbmc.LOGWARNING,
                )

            if (
                integrity_local
                and not integrity_killswitch
            ):
                xbmc.log(
                    "Kodi VPN Manager: local VPN tunnel is "
                    "active but kill switch is missing; "
                    "requesting automatic repair.",
                    xbmc.LOGWARNING,
                )

                try:
                    backend.request_refresh()

                except Exception as exc:
                    xbmc.log(
                        "Kodi VPN Manager: automatic kill-switch "
                        "repair request failed: {}".format(exc),
                        xbmc.LOGERROR,
                    )

        next_protection_integrity_probe = (
            time.monotonic()
            + PROTECTION_INTEGRITY_SECONDS
        )

    #
    # Immediate protection actions run in
    # protection_action.py. Consume its refresh request
    # here so dashboard/VFD state follows the completed
    # backend transaction without waiting for the
    # periodic VFD probe.
    #
    protection_refresh = window.getProperty(
        PROTECTION_REFRESH_PROPERTY
    )

    if protection_refresh:
        window.clearProperty(
            PROTECTION_REFRESH_PROPERTY
        )

        if protection_refresh == "connecting":
            protection_transition = (
                "connecting"
            )

            vfd_indicator.set_state(
                "connecting"
            )

        else:
            protection_transition = None

            set_protection_setting(
                not backend_protection_disabled()
            )

            refresh()
            update_vfd_vpn_indicator()

            next_vfd_status_probe = (
                time.monotonic()
                + VFD_STATUS_SECONDS
            )

    current_state_token = backend.state_token()

    state_changed = (
        bool(current_state_token)
        and current_state_token != last_state_token
    )

    if state_changed:
        xbmc.log(
            "Kodi VPN Manager: VPN state changed {} -> {}".format(
                last_state_token or "unknown",
                current_state_token
            ),
            xbmc.LOGINFO
        )

        last_state_token = current_state_token

    #
    # Lightweight automatic failover watchdog v2.
    #
    now = time.monotonic()

    #
    # Passive WireGuard peer-health observation.
    #
    # This is intentionally detection-only. A stale handshake
    # never mutates the tunnel here. Recovery will be introduced
    # only after live classification has been validated.
    #
    wg_health_now = time.monotonic()

    if wg_health_now >= next_wireguard_health_probe:
        try:
            wg_health = backend.wireguard_health_probe(
                WIREGUARD_STALE_SECONDS
            ) or {}
        except Exception as exc:
            wg_health = {
                "applicable": True,
                "status": "probe_error",
                "healthy": False,
                "stale": False,
                "reason": str(exc),
            }

        health_transition = _wireguard_health_transition(
            wireguard_stale_observations,
            wg_health,
        )

        previous_stale_observations = (
            wireguard_stale_observations
        )

        wireguard_stale_observations = (
            health_transition["stale_observations"]
        )

        health_event = health_transition["event"]
        if health_event in ("healthy", "inactive"):
            wireguard_recovery_deferred = False

        if health_event == "healthy":
            if previous_stale_observations:
                xbmc.log(
                    "Kodi VPN Manager: WireGuard peer health "
                    "returned to healthy.",
                    xbmc.LOGINFO,
                )

        elif health_event == "stale":
            xbmc.log(
                "Kodi VPN Manager: WireGuard stale handshake "
                "observation {}/{}; age={} seconds.".format(
                    wireguard_stale_observations,
                    WIREGUARD_STALE_CONFIRMATIONS,
                    wg_health.get("handshake_age"),
                ),
                (
                    xbmc.LOGWARNING
                    if not health_transition["confirmed"]
                    else xbmc.LOGERROR
                ),
            )

            if (
                health_transition["confirmed"]
                and (
                    previous_stale_observations
                    < WIREGUARD_STALE_CONFIRMATIONS
                    or wireguard_recovery_deferred
                )
            ):
                xbmc.log(
                    "Kodi VPN Manager: WireGuard peer is "
                    "confirmed stale; starting protected recovery",
                    xbmc.LOGWARNING,
                )

                try:
                    recovery = backend.recover_wireguard_health() or {}
                except Exception:
                    recovery = {
                        "ok": False,
                        "stage": "recovery_exception",
                        "fallback_restored": False,
                    }

                wireguard_recovery_deferred = (
                    recovery.get("stage") == "handoff_busy"
                )

                if recovery.get("ok"):
                    xbmc.log(
                        "Kodi VPN Manager: WireGuard peer "
                        "recovered with a fresh handshake",
                        xbmc.LOGINFO,
                    )
                elif recovery.get("fallback_restored"):
                    xbmc.log(
                        "Kodi VPN Manager: stale WireGuard "
                        "recovery failed; configured fallback "
                        "was restored",
                        xbmc.LOGWARNING,
                    )
                elif recovery.get("stage") == "handoff_busy":
                    xbmc.log(
                        "Kodi VPN Manager: stale WireGuard "
                        "recovery deferred because another VPN "
                        "transaction owns the handoff lock",
                        xbmc.LOGWARNING,
                    )
                else:
                    xbmc.log(
                        "Kodi VPN Manager: stale WireGuard "
                        "recovery failed at {}".format(
                            recovery.get("stage") or "unknown"
                        ),
                        xbmc.LOGERROR,
                    )

        elif health_event == "structural_failure":
            xbmc.log(
                "Kodi VPN Manager: WireGuard peer-health "
                "structural check failed: {}".format(
                    wg_health.get(
                        "reason",
                        "unknown",
                    )
                ),
                xbmc.LOGWARNING,
            )

        next_wireguard_health_probe = (
            wg_health_now
            + WIREGUARD_HEALTH_SECONDS
        )

    managed_protection_disabled = False

    if watchdog_supported:
        try:
            managed_protection_disabled = bool(
                backend.protection_disabled()
            )
        except Exception:
            managed_protection_disabled = False

    if (
        watchdog_supported
        and now >= next_failover_probe
        and not managed_protection_disabled
    ):

        try:
            selector_mode = backend.selector_state()
        except Exception:
            selector_mode = "unknown"

        request_selector = False
        request_reason = None
        next_delay = FAILOVER_PROBE_SECONDS

        # ----------------------------------------------------
        # Router mode
        # ----------------------------------------------------
        if selector_mode == "router":

            failed_retry_attempts = 0

            try:
                probe = (
                    backend.lightweight_router_probe()
                    or {}
                )
            except Exception as exc:
                probe = {
                    "ok": False,
                    "changed": False,
                    "physical_internet": None,
                    "reason": str(exc),
                }

            if probe.get("ok"):

                router_probe_failures = 0
                detector_degraded = False

                if probe.get("changed"):
                    request_selector = True

                    request_reason = (
                        "router upstream fingerprint changed "
                        "{} -> {}".format(
                            probe.get(
                                "previous_ip",
                                "unknown",
                            ),
                            probe.get(
                                "current_ip",
                                "unknown",
                            ),
                        )
                    )

            elif probe.get("physical_internet") is True:

                # Internet still works. Failure of the public-IP
                # detector alone is NOT evidence of VPN loss.
                router_probe_failures = 0

                if not detector_degraded:
                    xbmc.log(
                        "Kodi VPN Manager: public-IP detector "
                        "degraded while physical Internet remains "
                        "reachable; selector suppressed: {}".format(
                            probe.get(
                                "reason",
                                "unknown",
                            )
                        ),
                        xbmc.LOGWARNING
                    )

                detector_degraded = True

            else:

                detector_degraded = False
                router_probe_failures += 1

                if (
                    router_probe_failures
                    >= PROBE_FAILURE_CONFIRMATIONS
                ):
                    request_selector = True

                    request_reason = (
                        "physical upstream unavailable "
                        "{} consecutive times".format(
                            router_probe_failures
                        )
                    )

                    router_probe_failures = 0

            next_delay = FAILOVER_PROBE_SECONDS

        # ----------------------------------------------------
        # Local mode
        # ----------------------------------------------------
        elif selector_mode == "local":

            router_probe_failures = 0
            detector_degraded = False
            failed_retry_attempts = 0

            request_selector = True
            request_reason = (
                "periodic protected router recovery check"
            )

            next_delay = LOCAL_ROUTER_RECHECK_SECONDS

        # ----------------------------------------------------
        # Fail-closed mode
        # ----------------------------------------------------
        elif selector_mode == "failed":

            router_probe_failures = 0
            detector_degraded = False

            index = min(
                failed_retry_attempts,
                len(FAILED_RETRY_DELAYS) - 1,
            )

            retry_delay = FAILED_RETRY_DELAYS[index]

            try:
                recovery = (
                    backend.failed_recovery_probe()
                    or {}
                )
            except Exception as exc:
                recovery = {
                    "ready": False,
                    "reason": str(exc),
                }

            if recovery.get("ready"):

                request_selector = True
                request_reason = (
                    "failed-path recovery signal: {}".format(
                        recovery.get(
                            "reason",
                            "ready",
                        )
                    )
                )

            else:

                xbmc.log(
                    "Kodi VPN Manager: fail-closed path "
                    "still has no recovery signal; selector "
                    "suppressed; retry in {}s".format(
                        retry_delay
                    ),
                    xbmc.LOGINFO
                )

            failed_retry_attempts += 1
            next_delay = retry_delay

        # ----------------------------------------------------
        # Unknown / startup state
        # ----------------------------------------------------
        else:

            router_probe_failures = 0
            detector_degraded = False
            failed_retry_attempts = 0

            request_selector = True
            request_reason = (
                "VPN path is {}".format(
                    selector_mode or "unknown"
                )
            )

            next_delay = UNKNOWN_RECHECK_SECONDS

        if request_selector:

            xbmc.log(
                "Kodi VPN Manager: automatic selector request: "
                "{}".format(
                    request_reason
                ),
                xbmc.LOGINFO
            )

            #
            # A periodic router-recovery probe occurs while the
            # existing local VPN is still protected. Do not
            # flash the front-panel clock for that background
            # health check.
            #
            if request_reason != (
                "periodic protected router recovery check"
            ):
                vfd_indicator.set_state(
                    "connecting"
                )

            try:
                backend.request_refresh()

            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: automatic selector "
                    "request failed: {}".format(
                        exc
                    ),
                    xbmc.LOGERROR
                )

        # Re-base AFTER any blocking selector run.
        next_failover_probe = (
            time.monotonic()
            + next_delay
        )

    manual_refresh = (
        window.getProperty("VPNManager.RefreshVPN") == "1"
    )

    timed_refresh = (
        time.monotonic() >= next_auto_refresh
    )

    if manual_refresh or timed_refresh or state_changed:

        if manual_refresh:
            window.clearProperty("VPNManager.RefreshVPN")
            setprop("VPNManager.VPNStatus", "Refreshing...")
            setprop("VPNManager.VPNVerification", "Checking now...")

            xbmc.log(
                "Kodi VPN Manager: Manual VPN refresh requested",
                xbmc.LOGINFO
            )

            vfd_indicator.set_state("connecting")

            try:
                result = backend.request_refresh()

                # If a backend refresh is already running,
                # wait for it to finish before reading state.
                for _ in range(90):
                    if not backend.refresh_in_progress():
                        break

                    if monitor.waitForAbort(0.5):
                        break

                xbmc.log(
                    "Kodi VPN Manager: VPN refresh result={}".format(
                        result if result is not None else "unavailable"
                    ),
                    xbmc.LOGINFO
                )

            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: VPN refresh failed: {}".format(exc),
                    xbmc.LOGERROR
                )

        if state_changed and not manual_refresh:
            monitor.waitForAbort(2)

        refresh()

        # Prevent a manual backend refresh from causing a duplicate refresh.
        last_state_token = backend.state_token() or last_state_token

        next_auto_refresh = (
            time.monotonic() + AUTO_REFRESH_SECONDS
        )


vfd_indicator.close()

for prop in (
    "VPNManager.PublicIP",
    "VPNManager.VPNExitLocation",
    "VPNManager.VPNExitNetwork",
    "VPNManager.VPNPath",
    "VPNManager.VPNStatus",
    "VPNManager.StatusSummary",
    "VPNManager.ProfileActivity",
    "VPNManager.VPNInterface",
    "VPNManager.VPNTunnelIP",
    "VPNManager.VPNServer",
    "VPNManager.VPNKillSwitch",
    "VPNManager.VPNVerification",
):
    window.clearProperty(prop)
