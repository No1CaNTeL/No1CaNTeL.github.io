#!/bin/sh

IPT=/usr/sbin/iptables
IP6T=/usr/sbin/ip6tables
LAUNCHER="${VPN_MANAGER_LAUNCHER:-/storage/.config/vpn-manager/bin/vpn-manager-openvpn-launcher.py}"
VPNIF="${VPN_MANAGER_INTERFACE:-tun0}"

POLICY_FILE="/storage/.config/vpn-manager/policy.env"

allow_local_lan()
{
    #
    # Missing policy preserves the beta23/current behaviour.
    # Once a policy file exists, only an exact 1 permits
    # ordinary LAN access; malformed policy therefore fails closed.
    #
    [ -f "$POLICY_FILE" ] || return 0

    VALUE="$(
        awk -F= '
            /^[[:space:]]*ALLOW_LOCAL_LAN[[:space:]]*=/ {
                value=$2
                gsub(/[[:space:]]/, "", value)
                print value
                exit
            }
        ' "$POLICY_FILE" 2>/dev/null
    )"

    [ "$VALUE" = "1" ]
}

redact_ip_stream()
{
    sed -E 's/([0-9]{1,3})\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/\1.x.x.x/g' |
    awk '
    function mask_ipv6(line, out, token, tmp, colons, first)
    {
        out = ""

        while (match(line, /[0-9A-Fa-f:]+/)) {
            out = out substr(line, 1, RSTART - 1)
            token = substr(line, RSTART, RLENGTH)
            tmp = token
            colons = gsub(/:/, ":", tmp)

            if (colons >= 2 && (colons >= 3 || token ~ /::/ || token ~ /[A-Fa-f]/)) {
                first = token
                sub(/:.*/, "", first)

                if (first == "") {
                    out = out "x"
                } else {
                    out = out first ":x"
                }
            } else {
                out = out token
            }

            line = substr(line, RSTART + RLENGTH)
        }

        return out line
    }

    {
        print mask_ipv6($0)
    }
    '
}

get_lan_context()
{
    LANIF=""
    LANIP=""
    LAN=""
    DEFAULT_IF=""

    #
    # Find a normal non-tunnel default interface when available.
    #
    DEFAULT_ROUTES="$(ip -4 route show table main default 2>/dev/null)"

    while IFS= read -r LINE
    do
        [ -n "$LINE" ] || continue

        set -- $LINE
        [ "${1:-}" = "default" ] || continue

        IFACE=""
        PREV=""

        for TOKEN in "$@"
        do
            if [ "$PREV" = "dev" ]; then
                IFACE="$TOKEN"
                break
            fi
            PREV="$TOKEN"
        done

        case "$IFACE" in
            ""|lo|tun*|tap*|wg*|ppp*|vpn*|docker*|veth*|tailscale*)
                continue
                ;;
        esac

        DEFAULT_IF="$IFACE"
        break
    done <<EOF
$DEFAULT_ROUTES
EOF

    #
    # Enumerate physical interfaces with global IPv4 addresses.
    # Try the ordinary default interface first, then any others.
    #
    ADDR_LINES="$(ip -o -4 addr show scope global 2>/dev/null)"

    for PASS in default others
    do
        while IFS= read -r LINE
        do
            [ -n "$LINE" ] || continue

            set -- $LINE
            IFACE="${2:-}"
            IFACE="${IFACE%%@*}"

            case "$IFACE" in
                ""|lo|tun*|tap*|wg*|ppp*|vpn*|docker*|veth*|tailscale*)
                    continue
                    ;;
            esac

            if [ "$PASS" = "default" ]; then
                [ -n "$DEFAULT_IF" ] || continue
                [ "$IFACE" = "$DEFAULT_IF" ] || continue
            else
                [ "$IFACE" != "$DEFAULT_IF" ] || continue
            fi

            if [ -r "/sys/class/net/$IFACE/carrier" ]; then
                CARRIER="$(cat "/sys/class/net/$IFACE/carrier" 2>/dev/null)"
                [ "$CARRIER" = "1" ] || continue
            fi

            ADDR_LINE="$(
                ip -o -4 addr show dev "$IFACE" \
                    scope global 2>/dev/null |
                    head -n 1
            )"

            [ -n "$ADDR_LINE" ] || continue

            set -- $ADDR_LINE
            CIDR="${4:-}"
            LANIP="${CIDR%/*}"

            [ -n "$LANIP" ] || continue

            LINK_ROUTES="$(
                ip -4 route show table main \
                    dev "$IFACE" scope link 2>/dev/null
            )"

            while IFS= read -r ROUTE_LINE
            do
                [ -n "$ROUTE_LINE" ] || continue

                set -- $ROUTE_LINE
                NETWORK="${1:-}"

                case "$NETWORK" in
                    ""|default)
                        continue
                        ;;
                esac

                SRCIP=""
                PREV=""

                for TOKEN in "$@"
                do
                    if [ "$PREV" = "src" ]; then
                        SRCIP="$TOKEN"
                        break
                    fi
                    PREV="$TOKEN"
                done

                [ "$SRCIP" = "$LANIP" ] || continue

                LANIF="$IFACE"
                LAN="$NETWORK"
                return 0
            done <<EOF
$LINK_ROUTES
EOF

        done <<EOF
$ADDR_LINES
EOF
    done

    return 1
}

get_network()
{
    get_lan_context || return 1

    DNSIP="$(
        awk '
            /^nameserver[[:space:]]+/ {
                print $2
                exit
            }
        ' /etc/resolv.conf
    )"

    [ -n "$LANIF" ] && [ -n "$LAN" ]
}


get_transports()
{
    "$LAUNCHER" --transport
}


# VPN_KILLSWITCH_ATOMIC_HANDOVER_BEGIN

GUARD4="CE_OVPN_KS_GUARD"
GUARD6="CE_OVPN_KS6_GUARD"

EMERG4="CE_OVPN_KS_EMERG"
EMERG6="CE_OVPN_KS6_EMERG"


# VPN_KILLSWITCH_GUARD_REFRESH_BEGIN

emergency4_active()
{
    $IPT -C OUTPUT -j "$EMERG4" >/dev/null 2>&1
}

emergency6_active()
{
    $IP6T -C OUTPUT -j "$EMERG6" >/dev/null 2>&1
}

arm_emergency4()
{
    emergency4_active && return 0

    $IPT -N "$EMERG4" 2>/dev/null || true
    $IPT -F "$EMERG4" || return 1
    $IPT -A "$EMERG4" -o lo -j RETURN || return 1
    if allow_local_lan; then
        $IPT -A "$EMERG4" -o "$LANIF" -d "$LAN" -j RETURN || return 1
    fi
    $IPT -A "$EMERG4" -o "$LANIF" -p udp --sport 68 --dport 67 -j RETURN || return 1
    $IPT -A "$EMERG4" -o "$VPNIF" -j RETURN || return 1
    $IPT -A "$EMERG4" -j REJECT || return 1
    $IPT -I OUTPUT 1 -j "$EMERG4" || return 1

    emergency4_active
}

arm_emergency6()
{
    emergency6_active && return 0

    $IP6T -N "$EMERG6" 2>/dev/null || true
    $IP6T -F "$EMERG6" || return 1
    $IP6T -A "$EMERG6" -o lo -j RETURN || return 1
    $IP6T -A "$EMERG6" -d fe80::/10 -j RETURN || return 1
    $IP6T -A "$EMERG6" -d ff00::/8 -j RETURN || return 1
    $IP6T -A "$EMERG6" -j REJECT || return 1
    $IP6T -I OUTPUT 1 -j "$EMERG6" || return 1

    emergency6_active
}

release_emergency4()
{
    while $IPT -D OUTPUT -j "$EMERG4" 2>/dev/null; do :; done
    $IPT -F "$EMERG4" 2>/dev/null || true
    $IPT -X "$EMERG4" 2>/dev/null || true
}

release_emergency6()
{
    while $IP6T -D OUTPUT -j "$EMERG6" 2>/dev/null; do :; done
    $IP6T -F "$EMERG6" 2>/dev/null || true
    $IP6T -X "$EMERG6" 2>/dev/null || true
}


# VPN_KILLSWITCH_GUARD_REFRESH_END


guard4_active()
{
    $IPT -C OUTPUT -j "$GUARD4" >/dev/null 2>&1
}


guard6_active()
{
    $IP6T -C OUTPUT -j "$GUARD6" >/dev/null 2>&1
}


build_ipv4_guard()
{
    if guard4_active; then
        echo "Refreshing retained IPv4 handover guard..."

        arm_emergency4 || {
            echo "ERROR: Could not arm IPv4 emergency protection."
            echo "Existing IPv4 handover guard remains ACTIVE."
            return 1
        }

        while $IPT -D OUTPUT -j "$GUARD4" 2>/dev/null
        do
            :
        done
    fi

    $IPT -N "$GUARD4" 2>/dev/null || true
    $IPT -F "$GUARD4" || return 1

    $IPT -A "$GUARD4" -o lo -j RETURN || return 1
    if allow_local_lan; then
        $IPT -A "$GUARD4" -o "$LANIF" -d "$LAN" -j RETURN || return 1
    fi
    $IPT -A "$GUARD4" -o "$LANIF" -p udp --sport 68 --dport 67 -j RETURN || return 1

    while IFS='|' read -r VPNHOST VPNPORT VPNPROTO
    do
        [ -n "$VPNHOST" ] || continue

        [ -n "$VPNPORT" ] || {
            echo "ERROR: Missing VPN port for handover guard."
            return 1
        }

        case "$VPNPROTO" in
            tcp*) VPNPROTO="tcp" ;;
            udp*) VPNPROTO="udp" ;;
            *)
                echo "ERROR: Unsupported VPN protocol for handover guard: $VPNPROTO"
                return 1
                ;;
        esac

        if echo "$VPNHOST" |
            grep -Eq '^[0-9]+(\.[0-9]+){3}$'
        then
            VPNIPS="$VPNHOST"
        else
            VPNIPS="$(
                getent ahostsv4 "$VPNHOST" 2>/dev/null |
                    awk '{print $1}' |
                    sort -u
            )"
        fi

        [ -n "$VPNIPS" ] || {
            echo "ERROR: Cannot resolve VPN endpoint for handover guard: $VPNHOST"
            return 1
        }

        for VPNIP in $VPNIPS
        do
            $IPT -A "$GUARD4" \
                -o "$LANIF" \
                -d "$VPNIP" \
                -p "$VPNPROTO" \
                --dport "$VPNPORT" \
                -j RETURN || return 1
        done
    done <<EOF
$TRANSPORTS
EOF

    $IPT -A "$GUARD4" -o "$VPNIF" -j RETURN || return 1
    $IPT -A "$GUARD4" -j REJECT || return 1

    $IPT -I OUTPUT 1 -j "$GUARD4" || return 1

    guard4_active || return 1

    emergency4_active &&
        release_emergency4

    return 0
}

build_ipv6_guard()
{
    if guard6_active; then
        echo "Refreshing retained IPv6 handover guard..."

        arm_emergency6 || {
            echo "ERROR: Could not arm IPv6 emergency protection."
            echo "Existing IPv6 handover guard remains ACTIVE."
            return 1
        }

        while $IP6T -D OUTPUT -j "$GUARD6" 2>/dev/null
        do
            :
        done
    fi

    $IP6T -N "$GUARD6" 2>/dev/null || true
    $IP6T -F "$GUARD6" || return 1

    $IP6T -A "$GUARD6" -o lo -j RETURN || return 1
    $IP6T -A "$GUARD6" -d fe80::/10 -j RETURN || return 1
    $IP6T -A "$GUARD6" -d ff00::/8 -j RETURN || return 1
    $IP6T -A "$GUARD6" -j REJECT || return 1

    $IP6T -I OUTPUT 1 -j "$GUARD6" || return 1

    guard6_active || return 1

    emergency6_active &&
        release_emergency6

    return 0
}

arm_handover_guard()
{
    echo "Arming fail-closed handover guard..."

    build_ipv4_guard || {
        echo "ERROR: Could not arm IPv4 handover guard."
        return 1
    }

    build_ipv6_guard || {
        echo "ERROR: Could not arm IPv6 handover guard."
        echo "IPv4 handover guard remains ACTIVE."
        return 1
    }

    echo "Fail-closed handover guard ACTIVE."
    return 0
}


verify_stable_protection()
{
    $IPT -C OUTPUT \
        -j CE_OVPN_KS \
        >/dev/null 2>&1 || return 1

    $IPT -C CE_OVPN_KS \
        -o "$VPNIF" \
        -j RETURN \
        >/dev/null 2>&1 || return 1

    $IPT -C CE_OVPN_KS \
        -j REJECT \
        >/dev/null 2>&1 || return 1

    $IP6T -C OUTPUT \
        -j CE_OVPN_KS6 \
        >/dev/null 2>&1 || return 1

    $IP6T -C CE_OVPN_KS6 \
        -j REJECT \
        >/dev/null 2>&1 || return 1

    return 0
}


release_handover_guard()
{
    while $IPT -D OUTPUT -j "$GUARD4" 2>/dev/null; do :; done
    $IPT -F "$GUARD4" 2>/dev/null || true
    $IPT -X "$GUARD4" 2>/dev/null || true

    while $IP6T -D OUTPUT -j "$GUARD6" 2>/dev/null; do :; done
    $IP6T -F "$GUARD6" 2>/dev/null || true
    $IP6T -X "$GUARD6" 2>/dev/null || true

    release_emergency4
    release_emergency6

    echo "Fail-closed handover guard released."
}

# VPN_KILLSWITCH_ATOMIC_HANDOVER_END

case "$1" in
  transport)
    get_transports
    exit $?
    ;;

  up)
    get_network || {
        echo "ERROR: Cannot determine LAN interface/subnet"
        exit 1
    }


    TRANSPORTS="$(get_transports 2>/dev/null)" || {
        echo "ERROR: Cannot determine selected VPN transport."
        exit 1
    }

    [ -n "$TRANSPORTS" ] || {
        echo "ERROR: Selected VPN profile has no transport."
        exit 1
    }

    echo "OpenVPN kill switch:"
    echo " LAN interface: $LANIF"
    printf ' LAN subnet:    %s\n' "$LAN" | redact_ip_stream
    echo " VPN transport(s):"
    printf '%s\n' "$TRANSPORTS" |
        redact_ip_stream |
        sed 's/^/  /'

    #
    # Build and install a complete temporary fail-closed policy
    # before modifying the stable chains.
    #
    arm_handover_guard || exit 1

    $IPT -N CE_OVPN_KS 2>/dev/null || true
    $IPT -F CE_OVPN_KS || exit 1

    while $IPT -D OUTPUT -j CE_OVPN_KS 2>/dev/null; do :; done

    # Local machine
    $IPT -A CE_OVPN_KS -o lo -j RETURN

    # Local LAN / SSH / Kodi LAN sources
    if allow_local_lan; then
        $IPT -A CE_OVPN_KS -o "$LANIF" -d "$LAN" -j RETURN
    fi

    # DHCP
    $IPT -A CE_OVPN_KS -o "$LANIF" \
        -p udp --sport 68 --dport 67 -j RETURN

    # Permit DNS through the physical interface only when routing requires it.
    # While tun0 is up, public DNS normally routes through the VPN instead.
    if [ -n "$DNSIP" ] && [ ! -f /run/x96-vpn-dns.locked ]; then
        $IPT -A CE_OVPN_KS -o "$LANIF" -d "$DNSIP" -p udp --dport 53 -j RETURN
        $IPT -A CE_OVPN_KS -o "$LANIF" -d "$DNSIP" -p tcp --dport 53 -j RETURN
    fi

    # Allow only the selected OpenVPN transport endpoint(s)
    while IFS='|' read -r VPNHOST VPNPORT VPNPROTO; do
        [ -n "$VPNHOST" ] || continue
        [ -n "$VPNPORT" ] || {
            echo "ERROR: Missing VPN port."
            exit 1
        }

        case "$VPNPROTO" in
            tcp*) VPNPROTO="tcp" ;;
            udp*) VPNPROTO="udp" ;;
            *)
                echo "ERROR: Unsupported VPN protocol: $VPNPROTO"
                exit 1
                ;;
        esac

        if echo "$VPNHOST" |
            grep -Eq '^[0-9]+(\.[0-9]+){3}$'; then
            VPNIPS="$VPNHOST"
        else
            VPNIPS="$(getent ahostsv4 "$VPNHOST" 2>/dev/null |
                awk '{print $1}' | sort -u)"
        fi

        [ -n "$VPNIPS" ] || {
            printf 'ERROR: Cannot resolve VPN endpoint: %s\n' \
                "$VPNHOST" | redact_ip_stream
            exit 1
        }

        for VPNIP in $VPNIPS; do
            $IPT -A CE_OVPN_KS -o "$LANIF" \
                -d "$VPNIP" -p "$VPNPROTO" \
                --dport "$VPNPORT" -j RETURN || exit 1
        done
    done <<EOF
$TRANSPORTS
EOF

    # Anything routed through OpenVPN is allowed
    $IPT -A CE_OVPN_KS -o "$VPNIF" -j RETURN

    # Everything else attempting to leave outside the tunnel is blocked
    $IPT -A CE_OVPN_KS -j REJECT

    $IPT -I OUTPUT 1 -j CE_OVPN_KS

    # IPv6 fail-closed protection.
    # Permit only local/link-local IPv6. Global IPv6 cannot bypass
    # the IPv4-only OpenVPN tunnel.
    $IP6T -N CE_OVPN_KS6 2>/dev/null || true
    $IP6T -F CE_OVPN_KS6 || exit 1

    while $IP6T -D OUTPUT -j CE_OVPN_KS6 2>/dev/null; do :; done

    $IP6T -A CE_OVPN_KS6 -o lo -j RETURN
    $IP6T -A CE_OVPN_KS6 -d fe80::/10 -j RETURN
    $IP6T -A CE_OVPN_KS6 -d ff00::/8 -j RETURN
    $IP6T -A CE_OVPN_KS6 -j REJECT

    $IP6T -I OUTPUT 1 -j CE_OVPN_KS6 || exit 1

    #
    # Never remove the temporary protection layer until BOTH
    # stable families have verified as fail-closed.
    #
    verify_stable_protection || {
        echo "ERROR: Stable kill-switch verification failed."
        echo "Fail-closed handover guard remains ACTIVE."
        exit 1
    }

    release_handover_guard
    ;;

  down)
    release_emergency4
    release_emergency6

    while $IPT -D OUTPUT -j "$GUARD4" 2>/dev/null; do :; done
    $IPT -F "$GUARD4" 2>/dev/null || true
    $IPT -X "$GUARD4" 2>/dev/null || true

    while $IP6T -D OUTPUT -j "$GUARD6" 2>/dev/null; do :; done
    $IP6T -F "$GUARD6" 2>/dev/null || true
    $IP6T -X "$GUARD6" 2>/dev/null || true

    while $IPT -D OUTPUT -j CE_OVPN_KS 2>/dev/null; do :; done
    $IPT -F CE_OVPN_KS 2>/dev/null || true
    $IPT -X CE_OVPN_KS 2>/dev/null || true

    while $IP6T -D OUTPUT -j CE_OVPN_KS6 2>/dev/null; do :; done
    $IP6T -F CE_OVPN_KS6 2>/dev/null || true
    $IP6T -X CE_OVPN_KS6 2>/dev/null || true
    ;;

  *)
    echo "Usage: $0 {up|down}"
    exit 1
    ;;
esac
