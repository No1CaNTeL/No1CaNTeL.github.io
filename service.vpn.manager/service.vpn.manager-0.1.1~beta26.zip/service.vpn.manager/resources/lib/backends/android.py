import os
import re
import shutil
import subprocess


BACKEND_ID = "android"
BACKEND_NAME = "Android"
MODE = "monitor"

CAN_MONITOR = True
CAN_MANAGE = False


IP = shutil.which("ip")

TUNNEL_PATTERNS = (
    r"^tun\d*$",
    r"^tap\d*$",
    r"^wg\d*$",
    r"^ppp\d*$",
    r"^ipsec\d*$",
)


def run(args, timeout=5):
    if not args or not args[0]:
        return ""

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def interfaces():
    path = "/sys/class/net"

    try:
        return sorted(os.listdir(path))
    except Exception:
        return []


def tunnel_interfaces():
    found = []

    for iface in interfaces():
        for pattern in TUNNEL_PATTERNS:
            if re.match(pattern, iface, re.IGNORECASE):
                found.append(iface)
                break

    return found


def internet_route():
    if not IP:
        return ""

    return run([
        IP,
        "-4",
        "route",
        "get",
        "1.1.1.1"
    ])


def routed_tunnel():
    route = internet_route()

    for iface in tunnel_interfaces():
        if "dev {}".format(iface) in route:
            return iface

    return ""


def interface_ip(iface):
    if not IP or not iface:
        return ""

    data = run([
        IP,
        "-4",
        "-o",
        "addr",
        "show",
        "dev",
        iface
    ])

    match = re.search(
        r"\binet\s+([0-9.]+)/",
        data
    )

    return match.group(1) if match else ""


def state_token():
    tunnels = tunnel_interfaces()
    routed = routed_tunnel()

    return "{}|{}".format(
        ",".join(tunnels),
        routed
    )


def request_refresh():
    # Android VPN ownership remains with Android/VpnService.
    return "monitor-only"


def refresh_in_progress():
    return False


def vpn_state():
    tunnels = tunnel_interfaces()
    routed = routed_tunnel()

    if routed:
        return {
            "path": "Android VPN",
            "status": "Protected",
            "interface": routed,
            "tunnel_ip": interface_ip(routed) or "N/A",
            "server": "App / Android-managed",
            "killswitch": "Android-managed",
            "verification": "VPN tunnel route detected",
            "local_tunnel": True,
            "backend_verified": False,
        }

    if tunnels:
        return {
            "path": "Android VPN",
            "status": "VPN DETECTED - VERIFYING",
            "interface": ", ".join(tunnels),
            "tunnel_ip": interface_ip(tunnels[0]) or "N/A",
            "server": "App / Android-managed",
            "killswitch": "Android-managed",
            "verification": (
                "Tunnel interface detected; route unconfirmed"
            ),
            "local_tunnel": True,
            "backend_verified": False,
        }

    return {
        "path": "No local Android VPN detected",
        "status": "MONITOR ONLY",
        "interface": "N/A",
        "tunnel_ip": "N/A",
        "server": "N/A",
        "killswitch": "Android-managed",
        "verification": "No local VPN tunnel visible",
        "local_tunnel": False,
        "backend_verified": False,
    }


def runtime_capabilities(interactive=False):
    return {
        "name": "Android",
        "mode": "monitor",
        "can_monitor": True,
        "can_manage": False,
    }


def supported_profile_types():
    return []


def can_manage_profile(profile):
    return False


def connect(profile):
    return {
        "ok": False,
        "code": None,
        "message": (
            "Android VPN connections are managed by "
            "Android/VpnService"
        ),
    }


def disconnect(profile):
    return {
        "ok": False,
        "code": None,
        "message": (
            "Android VPN connections are managed by "
            "Android/VpnService"
        ),
    }
