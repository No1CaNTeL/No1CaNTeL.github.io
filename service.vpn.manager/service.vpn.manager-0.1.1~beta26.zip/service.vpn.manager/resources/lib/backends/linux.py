import fcntl
import time
import socket
import os
import json
import re
import shutil
import subprocess

from resources.lib import profiles as profile_registry


BACKEND_ID = "linux"
BACKEND_NAME = "CoreELEC / Linux"
MODE = "manager"

CAN_MONITOR = True
CAN_MANAGE = True



IP = shutil.which("ip")
IPTABLES = shutil.which("iptables")
IP6TABLES = shutil.which("ip6tables")

STATE_FILE = "/run/vpn-selector.state"

PROTECTION_DISABLED_FILE = (
    "/storage/.kodi/userdata/"
    "addon_data/service.vpn.manager/"
    "protection.disabled"
)

RUNTIME_TARGET_FILE = (
    "/run/vpn-manager-openvpn.target.json"
)

EFFECTIVE_OPENVPN_CONFIG = (
    "/run/vpn-manager-openvpn.effective.ovpn"
)

HANDOFF_LOCK_FILE = (
    "/run/vpn-manager-handoff.lock"
)
_HANDOFF_LOCK_HANDLE = None


HOST_RUNTIME_ROOT = "/storage/.config/vpn-manager"
HOST_BIN_DIR = HOST_RUNTIME_ROOT + "/bin"
HOST_POLICY_FILE = HOST_RUNTIME_ROOT + "/policy.env"
HOST_RUNTIME_MANIFEST = (
    HOST_RUNTIME_ROOT + "/manifest.json"
)

MANAGED_KILLSWITCH_SCRIPT = (
    HOST_BIN_DIR + "/openvpn-killswitch.sh"
)
MANAGED_BOOTSTRAP_GUARD_SCRIPT = (
    HOST_BIN_DIR + "/vpn-bootstrap-guard.sh"
)
MANAGED_DNS_LOCK_SCRIPT = (
    HOST_BIN_DIR + "/openvpn-dns-lock.sh"
)

LEGACY_KILLSWITCH_SCRIPT = (
    "/storage/.config/openvpn-killswitch.sh"
)
LEGACY_BOOTSTRAP_GUARD_SCRIPT = (
    "/storage/.config/vpn-bootstrap-guard.sh"
)
LEGACY_DNS_LOCK_SCRIPT = (
    "/storage/.config/openvpn-dns-lock.sh"
)

# Runtime bindings are refreshed after host-runtime detection.
KILLSWITCH_SCRIPT = LEGACY_KILLSWITCH_SCRIPT
BOOTSTRAP_GUARD_SCRIPT = LEGACY_BOOTSTRAP_GUARD_SCRIPT
DNS_LOCK_SCRIPT = LEGACY_DNS_LOCK_SCRIPT

OPENVPN_PROFILE = "/storage/.config/openvpn/purevpn.ovpn"
PROFILE_REGISTRY = (
    "/storage/.kodi/userdata/addon_data/"
    "service.vpn.manager/profiles.json"
)


def run(args, timeout=8):
    if not args or not args[0]:
        return ""

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def lan_interface():
    if not IP:
        return ""

    data = run([
        IP, "-4", "route", "show",
        "table", "main", "default"
    ])

    for line in data.splitlines():
        parts = line.split()

        if "dev" in parts:
            try:
                return parts[parts.index("dev") + 1]
            except Exception:
                pass

    return ""


def internet_route():
    if not IP:
        return ""

    return run([IP, "-4", "route", "get", "1.1.1.1"])


def tunnel_ip(profile_type="openvpn"):
    if not IP:
        return ""

    contract = _vpn_contract(profile_type)

    if not contract:
        return ""

    data = run([
        IP,
        "-4",
        "-o",
        "addr",
        "show",
        "dev",
        contract["interface"],
    ])

    match = re.search(
        r"\binet\s+([0-9.]+)/",
        data,
    )

    return match.group(1) if match else ""


def tunnel_exists(profile_type="openvpn"):
    contract = _vpn_contract(profile_type)

    if not contract:
        return False

    return os.path.exists(
        "/sys/class/net/{}".format(
            contract["interface"]
        )
    )


def kill_switch_active(
    profile_type="openvpn",
):
    if not IPTABLES or not IP6TABLES:
        return False

    contract = _vpn_contract(
        profile_type
    )

    if not contract:
        return False

    output_rules = run(
        [
            IPTABLES,
            "-S",
            "OUTPUT",
        ]
    )

    if "-A OUTPUT -j CE_OVPN_KS" not in output_rules.splitlines():
        return False

    chain_rules = run(
        [
            IPTABLES,
            "-S",
            "CE_OVPN_KS",
        ]
    )

    expected = (
        "-A CE_OVPN_KS -o {} -j RETURN"
        .format(
            contract["interface"]
        )
    )

    if expected not in chain_rules:
        return False

    output6_rules = run(
        [
            IP6TABLES,
            "-S",
            "OUTPUT",
        ]
    )

    if "-A OUTPUT -j CE_OVPN_KS6" not in output6_rules.splitlines():
        return False

    chain6_rules = run(
        [
            IP6TABLES,
            "-S",
            "CE_OVPN_KS6",
        ]
    )

    return "-A CE_OVPN_KS6 -j REJECT" in chain6_rules



def selected_openvpn_path():
    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        profile = profile_registry.selected_profile(
            data
        )

        if (
            profile
            and profile.get("enabled", True)
            and str(
                profile.get("type", "")
            ).lower() == "openvpn"
        ):
            profile_path = str(
                profile.get("path", "")
            ).strip()

            if profile_path:
                return profile_path

    except Exception:
        pass

    # Temporary compatibility fallback for the current installation.
    return OPENVPN_PROFILE


def configured_server():
    profile_path = selected_openvpn_path()

    try:
        with open(
            profile_path,
            "r",
            encoding="utf-8"
        ) as f:
            for line in f:
                parts = line.strip().split()

                if len(parts) >= 2 and parts[0] == "remote":
                    host = parts[1]

                    if len(parts) >= 3:
                        return "{}:{}".format(
                            host,
                            parts[2]
                        )

                    return host

    except Exception:
        pass

    return "N/A"


def protection_disabled():
    return os.path.exists(
        PROTECTION_DISABLED_FILE
    )


def _set_protection_disabled(
    disabled,
):
    directory = os.path.dirname(
        PROTECTION_DISABLED_FILE
    )

    os.makedirs(
        directory,
        exist_ok=True,
    )

    if disabled:
        temporary = (
            PROTECTION_DISABLED_FILE
            + ".tmp"
        )

        with open(
            temporary,
            "w",
            encoding="utf-8",
        ) as f:
            f.write("disabled\n")
            f.flush()
            os.fsync(f.fileno())

        os.chmod(
            temporary,
            0o600,
        )

        os.replace(
            temporary,
            PROTECTION_DISABLED_FILE,
        )

    else:
        try:
            os.remove(
                PROTECTION_DISABLED_FILE
            )
        except FileNotFoundError:
            pass


def selector_state():
    if protection_disabled():
        return "disabled"

    try:
        with open(
            STATE_FILE,
            "r",
            encoding="utf-8",
        ) as f:
            return f.read().strip()

    except Exception:
        return ""


SYSTEMCTL = shutil.which("systemctl")

MANAGED_SELECTOR_SERVICE = (
    "vpn-manager-selector.service"
)
LEGACY_SELECTOR_SERVICE = "vpn-selector.service"

SELECTOR_SERVICE = LEGACY_SELECTOR_SERVICE


def _coreelec_host():
    """
    Return True only for the CoreELEC host environment.

    Generic Linux backends must never attempt to install the
    CoreELEC /storage runtime.
    """
    if not (
        os.path.isdir("/storage/.config")
        and os.path.isdir("/storage/.kodi")
    ):
        return False

    try:
        with open(
            "/etc/os-release",
            "r",
            encoding="utf-8",
            errors="replace",
        ) as handle:
            release = handle.read().lower()

    except Exception:
        return False

    return (
        "id=coreelec" in release
        or 'id="coreelec"' in release
        or 'name="coreelec"' in release
        or "name=coreelec" in release
    )


def _coreelec_package_dir():
    resources_dir = os.path.dirname(
        os.path.dirname(
            os.path.dirname(
                os.path.abspath(__file__)
            )
        )
    )

    return os.path.join(
        resources_dir,
        "platform",
        "coreelec",
    )


def _managed_runtime_ready():
    required_files = (
        HOST_RUNTIME_MANIFEST,
        MANAGED_KILLSWITCH_SCRIPT,
        MANAGED_BOOTSTRAP_GUARD_SCRIPT,
        MANAGED_DNS_LOCK_SCRIPT,
        os.path.join(
            HOST_BIN_DIR,
            "vpn-selector.sh",
        ),
        os.path.join(
            HOST_BIN_DIR,
            "vpn-manager-openvpn-launcher.py",
        ),
        os.path.join(
            HOST_BIN_DIR,
            "vpn-manager-wireguard-launcher.py",
        ),
        "/storage/.config/system.d/"
        "vpn-manager-selector.service",
        "/storage/.config/system.d/"
        "vpn-manager-selector.timer",
        "/storage/.config/system.d/"
        "vpn-manager-openvpn.service",
        "/storage/.config/system.d/"
        "vpn-manager-wireguard.service",
    )

    return all(
        os.path.isfile(path)
        for path in required_files
    )


def _refresh_host_runtime_bindings():
    global KILLSWITCH_SCRIPT
    global BOOTSTRAP_GUARD_SCRIPT
    global DNS_LOCK_SCRIPT
    global SELECTOR_SERVICE

    if _managed_runtime_ready():
        KILLSWITCH_SCRIPT = (
            MANAGED_KILLSWITCH_SCRIPT
        )
        BOOTSTRAP_GUARD_SCRIPT = (
            MANAGED_BOOTSTRAP_GUARD_SCRIPT
        )
        DNS_LOCK_SCRIPT = (
            MANAGED_DNS_LOCK_SCRIPT
        )
        SELECTOR_SERVICE = (
            MANAGED_SELECTOR_SERVICE
        )

        return "managed"

    KILLSWITCH_SCRIPT = LEGACY_KILLSWITCH_SCRIPT
    BOOTSTRAP_GUARD_SCRIPT = (
        LEGACY_BOOTSTRAP_GUARD_SCRIPT
    )
    DNS_LOCK_SCRIPT = LEGACY_DNS_LOCK_SCRIPT
    SELECTOR_SERVICE = LEGACY_SELECTOR_SERVICE

    return "legacy"


def ensure_host_runtime():
    """
    Ensure the CoreELEC host integration matches this addon.

    On ordinary Linux this is intentionally a no-op.

    The shell lifecycle scripts own locking, transactional
    installation, verification and rollback.
    """
    current = _refresh_host_runtime_bindings()

    if not _coreelec_host():
        return {
            "ok": True,
            "action": "not_applicable",
            "runtime": current,
            "message": (
                "CoreELEC host runtime not applicable"
            ),
        }

    if not SYSTEMCTL:
        return {
            "ok": False,
            "action": "failed",
            "runtime": current,
            "message": "systemctl unavailable",
        }

    try:
        is_root = os.geteuid() == 0
    except Exception:
        is_root = False

    if not is_root:
        return {
            "ok": False,
            "action": "failed",
            "runtime": current,
            "message": (
                "CoreELEC host runtime requires root"
            ),
        }

    package_dir = _coreelec_package_dir()

    if os.path.isdir(HOST_RUNTIME_ROOT):
        if not os.path.isfile(
            HOST_RUNTIME_MANIFEST
        ):
            return {
                "ok": False,
                "action": "failed",
                "runtime": current,
                "message": (
                    "Managed runtime exists without "
                    "a manifest; refusing overwrite"
                ),
            }

        script_name = "sync-managed-runtime.sh"
        action = "sync"

    else:
        script_name = "migrate-managed-runtime.sh"
        action = "migrate"

    script = os.path.join(
        package_dir,
        script_name,
    )

    if not os.path.isfile(script):
        return {
            "ok": False,
            "action": "failed",
            "runtime": current,
            "message": (
                "Host runtime lifecycle script missing"
            ),
        }

    try:
        result = subprocess.run(
            [
                "/bin/sh",
                script,
                "--apply",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=150,
        )

    except Exception as exc:
        _refresh_host_runtime_bindings()

        return {
            "ok": False,
            "action": "failed",
            "runtime": (
                _refresh_host_runtime_bindings()
            ),
            "message": (
                "Host runtime {} failed: {}"
            ).format(
                action,
                exc,
            ),
        }

    runtime = _refresh_host_runtime_bindings()
    ready = _managed_runtime_ready()

    if result.returncode != 0 or not ready:
        return {
            "ok": False,
            "action": "failed",
            "runtime": runtime,
            "code": result.returncode,
            "message": (
                "Host runtime {} did not complete"
            ).format(action),
        }

    return {
        "ok": True,
        "action": action,
        "runtime": runtime,
        "code": result.returncode,
        "message": (
            "CoreELEC host runtime ready"
        ),
    }


_refresh_host_runtime_bindings()


def start_selector():
    if protection_disabled():
        # Deliberate user-disabled mode.
        # Never auto-reconnect from here.
        return 3

    if not SYSTEMCTL:
        return None

    try:
        result = subprocess.run(
            [
                SYSTEMCTL,
                "start",
                SELECTOR_SERVICE
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=45
        )

        return result.returncode

    except Exception:
        return None


def selector_service_state():
    if not SYSTEMCTL:
        return ""

    return run(
        [
            SYSTEMCTL,
            "is-active",
            SELECTOR_SERVICE
        ],
        timeout=2
    )


def vpn_state():
    route = internet_route()
    state = selector_state()
    iface = lan_interface() or "LAN"

    if state == "disabled":
        ks = kill_switch_active()

        return {
            "path": "Protection disabled",
            "status": "PROTECTION DISABLED",
            "interface": iface,
            "tunnel_ip": "N/A",
            "server": "None",
            "killswitch": (
                "Active"
                if ks
                else "INACTIVE"
            ),
            "verification":
                "Disabled by user",
            "selector_state": state,
            "local_tunnel":
                tunnel_exists(),
            "backend_verified": False,
        }

    active_type = _active_local_profile_type()

    if active_type:
        contract = _vpn_contract(active_type)
        ks = kill_switch_active(active_type)

        if active_type == "wireguard":
            path = "Local WireGuard"
            verification = "wg0 route confirmed"
            server = "WireGuard endpoint"

            target = _read_runtime_target() or {}
            address = str(
                target.get("remote_address") or ""
            ).strip()
            port = str(
                target.get("remote_port") or ""
            ).strip()

            if address and port:
                server = "{}:{}".format(
                    address,
                    port,
                )
            elif address:
                server = address

        else:
            path = "Local OpenVPN"
            verification = "tun0 route confirmed"
            server = configured_server()

        return {
            "path": path,
            "status": (
                "Protected"
                if ks
                else "VPN ACTIVE - KILL SWITCH OFF"
            ),
            "interface": contract["interface"],
            "tunnel_ip":
                tunnel_ip(active_type) or "N/A",
            "server": server,
            "killswitch":
                "Active" if ks else "INACTIVE",
            "verification": verification,
            "selector_state": state,
            "local_tunnel": True,
            "backend_verified": bool(ks),
        }

    # Router/upstream VPN selected and verified.
    if state == "router":
        return {
            "path": "Router / upstream VPN",
            "status": "Protected",
            "interface": "Upstream ({})".format(iface),
            "tunnel_ip": "N/A",
            "server": "Router-managed",
            "killswitch": "Router-managed",
            "verification": "Selector verified",
            "selector_state": state,
            "local_tunnel": False,
            "backend_verified": True,
        }

    # Selector expected a local VPN but no managed tunnel is
    # currently carrying the Internet route.
    if state == "local":
        return {
            "path": "Local VPN",
            "status": "ROUTE FAULT",
            "interface": iface,
            "tunnel_ip": "N/A",
            "server": "N/A",
            "killswitch": (
                "Active"
                if (
                    kill_switch_active("openvpn")
                    or kill_switch_active("wireguard")
                )
                else "INACTIVE"
            ),
            "verification":
                "Managed VPN Internet route missing",
            "selector_state": state,
            "local_tunnel": (
                tunnel_exists("openvpn")
                or tunnel_exists("wireguard")
            ),
            "backend_verified": False,
        }

    # Selector deliberately failed closed.
    if state == "failed":
        ks = (
            kill_switch_active("openvpn")
            or kill_switch_active("wireguard")
        )

        return {
            "path": "Local VPN failed",
            "status": "FAIL-CLOSED",
            "interface": iface,
            "tunnel_ip": "N/A",
            "server": "N/A",
            "killswitch":
                "Active" if ks else "UNKNOWN",
            "verification": "Selector failure",
            "selector_state": state,
            "local_tunnel": (
                tunnel_exists("openvpn")
                or tunnel_exists("wireguard")
            ),
            "backend_verified": False,
        }

    # No trustworthy selector state available yet.
    ks = (
        kill_switch_active("openvpn")
        or kill_switch_active("wireguard")
    )

    return {
        "path": "Unknown",
        "status": "CHECK VPN",
        "interface": iface,
        "tunnel_ip": "N/A",
        "server": "Unknown",
        "killswitch":
            "Active" if ks else "Unknown",
        "verification": "Selector state unavailable",
        "selector_state": state,
        "local_tunnel": (
            tunnel_exists("openvpn")
            or tunnel_exists("wireguard")
        ),
        "backend_verified": False,
    }


def state_token():
    return selector_state()


def lightweight_router_probe():
    """
    Lightweight router-mode fingerprint check.

    A successful public-IP lookup is compared with the upstream
    IP last verified by the selector.

    If that lookup fails, a raw IPv4 connectivity test separates
    detector/DNS trouble from loss of the physical Internet path.
    """
    state = selector_state()

    if state != "router":
        return {
            "ok": True,
            "changed": False,
            "state": state,
            "reason": "not_router",
        }

    upstream_file = "/run/vpn-selector.upstream-ip"

    try:
        with open(
            upstream_file,
            "r",
            encoding="utf-8",
        ) as f:
            previous_ip = f.read().strip()
    except OSError:
        previous_ip = ""

    route = subprocess.run(
        [
            "ip",
            "-4",
            "route",
            "show",
            "table",
            "main",
            "default",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=5,
    )

    if route.returncode != 0:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "physical_internet": False,
            "reason": "default_route_unavailable",
        }

    interface = None

    for line in route.stdout.splitlines():
        parts = line.split()

        if not parts or parts[0] != "default":
            continue

        try:
            index = parts.index("dev")
            interface = parts[index + 1]
        except (ValueError, IndexError):
            pass

        if interface:
            break

    if not interface:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "physical_internet": False,
            "reason": "physical_interface_unavailable",
        }

    try:
        probe = subprocess.run(
            [
                "curl",
                "--interface",
                interface,
                "-4fsS",
                "--connect-timeout",
                "3",
                "--max-time",
                "5",
                "https://api.ipify.org",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=7,
        )

    except Exception as exc:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "interface": interface,
            "physical_internet": _raw_ipv4_connectivity(),
            "reason": "public_ip_probe_exception: {}".format(exc),
        }

    if probe.returncode != 0:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "interface": interface,
            "physical_internet": _raw_ipv4_connectivity(),
            "reason": (
                probe.stderr.strip()
                or "public_ip_probe_failed"
            ),
        }

    current_ip = probe.stdout.strip()

    try:
        socket.inet_aton(current_ip)
    except OSError:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "interface": interface,
            "physical_internet": _raw_ipv4_connectivity(),
            "reason": "invalid_public_ip",
        }

    if not previous_ip:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "interface": interface,
            "physical_internet": True,
            "current_ip": current_ip,
            "reason": "verified_upstream_ip_missing",
        }

    changed = current_ip != previous_ip

    return {
        "ok": True,
        "changed": changed,
        "state": state,
        "interface": interface,
        "physical_internet": True,
        "previous_ip": previous_ip,
        "current_ip": current_ip,
        "reason": (
            "upstream_ip_changed"
            if changed
            else "unchanged"
        ),
    }


def failed_recovery_probe():
    """
    Cheap recovery gate while the bootstrap guard is fail-closed.

    DNS resolution is deliberately used here because unrestricted
    raw WAN traffic is blocked in failed mode.
    """
    for host in (
        "api.ipify.org",
        "proxycheck.io",
    ):
        try:
            result = socket.getaddrinfo(
                host,
                443,
                socket.AF_INET,
                socket.SOCK_STREAM,
            )

            if result:
                return {
                    "ready": True,
                    "reason": "detector_dns_recovered",
                    "host": host,
                }

        except OSError:
            pass

    return {
        "ready": False,
        "reason": "detector_dns_unavailable",
    }


def _acquire_handoff_lock():
    global _HANDOFF_LOCK_HANDLE

    if _HANDOFF_LOCK_HANDLE is not None:
        return False

    try:
        handle = open(
            HANDOFF_LOCK_FILE,
            "a+",
            encoding="utf-8",
        )
    except OSError:
        return False

    try:
        fcntl.flock(
            handle.fileno(),
            fcntl.LOCK_EX | fcntl.LOCK_NB,
        )
    except (BlockingIOError, OSError):
        handle.close()
        return False

    _HANDOFF_LOCK_HANDLE = handle
    return True


def _release_handoff_lock():
    global _HANDOFF_LOCK_HANDLE

    handle = _HANDOFF_LOCK_HANDLE
    _HANDOFF_LOCK_HANDLE = None

    if handle is None:
        return

    try:
        fcntl.flock(
            handle.fileno(),
            fcntl.LOCK_UN,
        )
    except OSError:
        pass

    try:
        handle.close()
    except OSError:
        pass


def request_refresh():
    # Selector and protected handoff share one cross-process
    # transaction lock.  Whichever operation begins first owns
    # tunnel/runtime mutation until it completes.
    if not _acquire_handoff_lock():
        # A protected handoff or another selector request already
        # owns mutation.  The next periodic recovery check may
        # retry normally.
        return 0

    try:
        return start_selector()
    finally:
        _release_handoff_lock()


def refresh_in_progress():
    return selector_service_state() in (
        "active",
        "activating",
    )


MANAGED_OPENVPN_SERVICE = "vpn-manager-openvpn.service"
MANAGED_WIREGUARD_SERVICE = "vpn-manager-wireguard.service"

MANAGED_OPENVPN_LAUNCHER = (
    HOST_BIN_DIR + "/vpn-manager-openvpn-launcher.py"
)
MANAGED_WIREGUARD_LAUNCHER = (
    HOST_BIN_DIR + "/vpn-manager-wireguard-launcher.py"
)

MANAGEMENT_POLICY = "protected-selector"


def allow_local_lan_policy():
    """
    Return the persistent CoreELEC LAN-access policy.

    Missing policy preserves the beta23/current behaviour: directly
    connected IPv4 LAN access is allowed while protection is active.
    """
    try:
        with open(
            HOST_POLICY_FILE,
            "r",
            encoding="utf-8",
        ) as handle:
            for raw in handle:
                line = raw.strip()

                if not line or line.startswith("#"):
                    continue

                if line == "ALLOW_LOCAL_LAN=1":
                    return True

                if line == "ALLOW_LOCAL_LAN=0":
                    return False

    except FileNotFoundError:
        return True

    except Exception:
        return False

    # A present policy with no valid value fails closed for
    # ordinary LAN access.
    return False


def set_allow_local_lan_policy(enabled):
    """
    Atomically persist the CoreELEC LAN-access policy.

    The policy file is mutable runtime state and is deliberately not
    part of the managed-runtime executable manifest.
    """
    if not _coreelec_host():
        return {
            "ok": True,
            "changed": False,
            "action": "not_applicable",
        }

    value = "1" if bool(enabled) else "0"
    desired = "ALLOW_LOCAL_LAN={}\n".format(value)

    try:
        current = None

        try:
            with open(
                HOST_POLICY_FILE,
                "r",
                encoding="utf-8",
            ) as handle:
                current = handle.read()

        except FileNotFoundError:
            pass

        if current == desired:
            return {
                "ok": True,
                "changed": False,
                "action": "unchanged",
            }

        os.makedirs(
            HOST_RUNTIME_ROOT,
            exist_ok=True,
        )

        tmp = "{}.tmp-{}".format(
            HOST_POLICY_FILE,
            os.getpid(),
        )

        try:
            with open(
                tmp,
                "w",
                encoding="utf-8",
            ) as handle:
                handle.write(desired)
                handle.flush()
                os.fsync(handle.fileno())

            os.chmod(tmp, 0o600)
            os.replace(
                tmp,
                HOST_POLICY_FILE,
            )

        except Exception:
            try:
                os.unlink(tmp)
            except Exception:
                pass
            raise

        return {
            "ok": True,
            "changed": True,
            "action": "updated",
        }

    except Exception as exc:
        return {
            "ok": False,
            "changed": False,
            "action": "failed",
            "message": str(exc),
        }


def _active_local_profile_type():
    """
    Return the managed VPN type currently carrying the IPv4
    Internet route, or None when no verified local managed route
    is active.
    """
    route = internet_route()

    for profile_type in (
        "openvpn",
        "wireguard",
    ):
        contract = _vpn_contract(profile_type)

        if (
            contract
            and _service_is_active(profile_type)
            and tunnel_exists(profile_type)
            and _route_uses_interface(
                route,
                contract["interface"],
            )
        ):
            return profile_type

    return None


def _restore_local_lan_policy_snapshot(
    existed,
    content,
):
    """
    Restore the exact policy-file state that existed before a
    policy transaction.
    """
    if not existed:
        try:
            os.unlink(HOST_POLICY_FILE)
        except FileNotFoundError:
            pass

        return

    os.makedirs(
        HOST_RUNTIME_ROOT,
        exist_ok=True,
    )

    tmp = "{}.tmp-{}".format(
        HOST_POLICY_FILE,
        os.getpid(),
    )

    try:
        with open(
            tmp,
            "w",
            encoding="utf-8",
        ) as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())

        os.chmod(tmp, 0o600)
        os.replace(
            tmp,
            HOST_POLICY_FILE,
        )

    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass

        raise


def apply_allow_local_lan_policy(enabled):
    """
    Apply the CoreELEC LAN-access policy as one protected
    transaction.

    Policy persistence and stable firewall replacement share the
    same handoff lock used by protected VPN transitions.  When a
    managed local VPN is active, the existing atomic kill-switch
    updater supplies temporary dual-stack protection while stable
    rules are rebuilt.
    """
    if not _coreelec_host():
        return {
            "ok": True,
            "changed": False,
            "action": "not_applicable",
        }

    if not _acquire_handoff_lock():
        return {
            "ok": False,
            "changed": False,
            "action": "busy",
            "message": (
                "A protected VPN transaction is already active"
            ),
        }

    try:
        policy_existed = os.path.isfile(
            HOST_POLICY_FILE
        )
        policy_content = ""

        if policy_existed:
            try:
                with open(
                    HOST_POLICY_FILE,
                    "r",
                    encoding="utf-8",
                ) as handle:
                    policy_content = handle.read()

            except Exception as exc:
                return {
                    "ok": False,
                    "changed": False,
                    "action": "read_failed",
                    "message": str(exc),
                }

        active_type = _active_local_profile_type()

        result = set_allow_local_lan_policy(
            enabled
        )

        if not result.get("ok"):
            return result

        if not result.get("changed"):
            return result

        if not active_type:
            return {
                "ok": True,
                "changed": True,
                "action": "updated_no_local_tunnel",
            }

        apply_result = _run_killswitch_up(
            active_type
        )

        if (
            apply_result.get("code") == 0
            and kill_switch_active(active_type)
        ):
            return {
                "ok": True,
                "changed": True,
                "action": "updated_and_applied",
                "profile_type": active_type,
            }

        failure = (
            apply_result.get("stderr")
            or apply_result.get("stdout")
            or "Stable kill-switch rebuild failed"
        )

        try:
            _restore_local_lan_policy_snapshot(
                policy_existed,
                policy_content,
            )

        except Exception as exc:
            return {
                "ok": False,
                "changed": True,
                "action": "rollback_policy_failed",
                "message": "{}; policy rollback failed: {}".format(
                    failure,
                    exc,
                ),
            }

        rollback_result = _run_killswitch_up(
            active_type
        )

        rollback_ok = (
            rollback_result.get("code") == 0
            and kill_switch_active(active_type)
        )

        return {
            "ok": False,
            "changed": False,
            "action": (
                "apply_failed_rolled_back"
                if rollback_ok
                else "apply_failed_fail_closed"
            ),
            "message": failure,
        }

    finally:
        _release_handoff_lock()


def _vpn_contract(profile_type="openvpn"):
    """
    Return the managed Linux runtime identity for one VPN type.

    This helper is descriptive only. It does not mutate the
    active VPN runtime.
    """
    profile_type = str(
        profile_type or "openvpn"
    ).strip().lower()

    contracts = {
        "openvpn": {
            "profile_type": "openvpn",
            "service": MANAGED_OPENVPN_SERVICE,
            "interface": "tun0",
            "launcher": MANAGED_OPENVPN_LAUNCHER,
        },
        "wireguard": {
            "profile_type": "wireguard",
            "service": MANAGED_WIREGUARD_SERVICE,
            "interface": "wg0",
            "launcher": MANAGED_WIREGUARD_LAUNCHER,
        },
    }

    return contracts.get(profile_type)


def _route_uses_interface(route, interface):
    """
    Match an ip-route interface exactly.
    """
    if not route or not interface:
        return False

    parts = str(route).split()

    for index, token in enumerate(
        parts[:-1]
    ):
        if (
            token == "dev"
            and parts[index + 1] == interface
        ):
            return True

    return False


def _service_is_active(profile_type="openvpn"):
    contract = _vpn_contract(profile_type)

    if not contract or not SYSTEMCTL:
        return False

    result = _command_result(
        [
            SYSTEMCTL,
            "is-active",
            "--quiet",
            contract["service"],
        ],
        timeout=8,
    )

    return result.get("code") == 0


def _wireguard_active_identity(data=None):
    """
    Identify a managed WireGuard profile without relying on a
    long-running userspace VPN process.

    Identity is trusted only when the managed WireGuard service
    is active, wg0 exists, the validated runtime target says
    WireGuard, and that target still maps to an enabled readable
    WireGuard registry profile.
    """
    if not _service_is_active("wireguard"):
        return None

    if not tunnel_exists("wireguard"):
        return None

    target = _read_runtime_target()

    if (
        not target
        or target.get("profile_type")
        != "wireguard"
    ):
        return None

    profile_id = str(
        target.get("profile_id") or ""
    ).strip()

    if not profile_id:
        return None

    if data is None:
        try:
            data = profile_registry.load(
                PROFILE_REGISTRY
            )
        except Exception:
            return None

    for profile in profile_registry.profiles(
        data
    ):
        if not isinstance(profile, dict):
            continue

        if str(
            profile.get("id") or ""
        ) != profile_id:
            continue

        if str(
            profile.get("type") or ""
        ).strip().lower() != "wireguard":
            return None

        if not profile.get("enabled", True):
            return None

        profile_path = str(
            profile.get("path") or ""
        ).strip()

        if (
            not profile_path
            or not os.path.isfile(profile_path)
        ):
            return None

        return {
            "profile_id": profile_id,
            "profile_type": "wireguard",
            "path": profile_path,
        }

    return None


def _profile_error(message):
    return {
        "ok": False,
        "code": None,
        "message": message,
    }


def can_manage_profile(profile):
    if not isinstance(profile, dict):
        return False

    if not profile.get("enabled", True):
        return False

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    profile_path = str(
        profile.get("path", "")
    ).strip()

    return bool(
        SYSTEMCTL
        and profile_type in (
            "openvpn",
            "wireguard",
        )
        and profile_path
        and os.path.isfile(profile_path)
    )



def _resolve_ipv4(host, attempts=8):
    """
    Resolve a VPN hostname repeatedly and return the unique IPv4
    endpoint pool observed.

    Some providers use DNS round-robin, so a single lookup is not
    sufficient protection for a later OpenVPN connection.
    """
    import socket
    import time

    host = str(host or "").strip()

    if re.match(
        r"^[0-9]+(?:\.[0-9]+){3}$",
        host
    ):
        return [host]

    found = []

    getent = shutil.which("getent")

    for attempt in range(attempts):
        addresses = []

        if getent:
            try:
                result = subprocess.run(
                    [
                        getent,
                        "ahostsv4",
                        host,
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    timeout=5,
                )

                if result.returncode == 0:
                    for line in result.stdout.splitlines():
                        parts = line.split()

                        if parts:
                            addresses.append(parts[0])

            except Exception:
                pass

        if not addresses:
            try:
                results = socket.getaddrinfo(
                    host,
                    None,
                    socket.AF_INET,
                    0,
                    0,
                )

                addresses = [
                    result[4][0]
                    for result in results
                ]

            except Exception:
                pass

        for address in addresses:
            if (
                re.match(
                    r"^[0-9]+(?:\.[0-9]+){3}$",
                    address
                )
                and address not in found
            ):
                found.append(address)

        if attempt + 1 < attempts:
            time.sleep(1)

    return found


def _config_reference_path(
    config_dir,
    value,
):
    value = str(value or "").strip()

    if not value:
        return None

    # Inline OpenVPN data such as <ca>...</ca>
    # has no external path to verify.
    if value.startswith("<"):
        return None

    if os.path.isabs(value):
        return value

    return os.path.normpath(
        os.path.join(
            config_dir,
            value,
        )
    )


def _preflight_openvpn_profile(profile):
    """
    Read-only validation for a proposed local OpenVPN profile.

    This function MUST NOT:
      - alter the profile registry
      - start/stop OpenVPN
      - invoke vpn-selector
      - alter routing, DNS, or firewall state
    """
    result = {
        "ok": False,
        "profile_id": None,
        "name": None,
        "type": None,
        "path": None,
        "active_path": active_profile_path(),
        "transports": [],
        "references": [],
        "warnings": [],
        "errors": [],
    }

    if not isinstance(profile, dict):
        result["errors"].append(
            "Invalid VPN profile"
        )
        return result

    result["profile_id"] = profile.get("id")
    result["name"] = profile.get("name")
    result["type"] = str(
        profile.get("type", "")
    ).strip().lower()

    path = str(
        profile.get("path", "")
    ).strip()

    result["path"] = path

    if not profile.get("enabled", True):
        result["errors"].append(
            "VPN profile is disabled"
        )

    if result["type"] != "openvpn":
        result["errors"].append(
            "CoreELEC preflight currently supports OpenVPN profiles"
        )

    if not path:
        result["errors"].append(
            "OpenVPN profile path is missing"
        )
        return result

    if not os.path.isfile(path):
        result["errors"].append(
            "OpenVPN profile does not exist: {}".format(
                path
            )
        )
        return result

    if not os.access(path, os.R_OK):
        result["errors"].append(
            "OpenVPN profile is not readable: {}".format(
                path
            )
        )
        return result

    if not shutil.which("openvpn"):
        result["errors"].append(
            "OpenVPN executable not found"
        )

    config_dir = os.path.dirname(path)

    try:
        with open(
            path,
            "r",
            encoding="utf-8",
            errors="replace",
        ) as f:
            lines = [
                line.strip()
                for line in f
                if line.strip()
                and not line.lstrip().startswith(
                    ("#", ";")
                )
            ]

    except Exception as exc:
        result["errors"].append(
            "Could not read OpenVPN profile: {}".format(
                exc
            )
        )
        return result

    proto = "udp"
    default_port = "1194"

    protocol_options = profile.get(
        "protocol_options"
    )

    if not isinstance(protocol_options, dict):
        protocol_options = {}

    metadata_host = str(
        protocol_options.get("remote_host") or ""
    ).strip()

    metadata_port = str(
        protocol_options.get("remote_port") or ""
    ).strip()

    metadata_proto = str(
        protocol_options.get("protocol") or ""
    ).strip().lower()

    if metadata_proto.startswith("tcp"):
        metadata_proto = "tcp"
    elif metadata_proto.startswith("udp"):
        metadata_proto = "udp"
    else:
        metadata_proto = ""

    for line in lines:
        parts = line.split()

        if not parts:
            continue

        key = parts[0].lower()

        if key == "proto" and len(parts) >= 2:
            proto = (
                "tcp"
                if parts[1].lower().startswith("tcp")
                else "udp"
            )

        elif key == "port" and len(parts) >= 2:
            default_port = parts[1]

    for line in lines:
        parts = line.split()

        if not parts:
            continue

        key = parts[0].lower()

        if key == "remote" and len(parts) >= 2:
            host = parts[1]
            port = default_port
            remote_proto = proto

            if len(parts) >= 3:
                if parts[2].isdigit():
                    port = parts[2]

                    if len(parts) >= 4:
                        remote_proto = parts[3]
                else:
                    remote_proto = parts[2]

            remote_proto = (
                "tcp"
                if remote_proto.lower().startswith("tcp")
                else "udp"
            )

            resolution_host = host

            if (
                metadata_host
                and metadata_port == str(port)
                and metadata_proto == remote_proto
            ):
                resolution_host = metadata_host

            addresses = _resolve_ipv4(
                resolution_host
            )

            transport = {
                "host": resolution_host,
                "port": port,
                "proto": remote_proto,
                "addresses": addresses,
            }

            result["transports"].append(
                transport
            )

            if not addresses:
                result["errors"].append(
                    "Cannot resolve VPN endpoint: {}".format(
                        resolution_host
                    )
                )

    if not result["transports"]:
        result["errors"].append(
            "OpenVPN profile has no remote directive"
        )

    # External files that may be required by the profile.
    reference_directives = {
        "ca",
        "cert",
        "key",
        "pkcs12",
        "tls-auth",
        "tls-crypt",
        "auth-user-pass",
    }

    for line in lines:
        parts = line.split()

        if not parts:
            continue

        key = parts[0].lower()

        if key not in reference_directives:
            continue

        # Bare "auth-user-pass" is valid; credentials may be
        # supplied by the launcher/runtime.
        if (
            key == "auth-user-pass"
            and len(parts) == 1
        ):
            result["references"].append({
                "directive": key,
                "path": None,
                "status": "runtime",
            })
            continue

        if len(parts) < 2:
            continue

        ref = _config_reference_path(
            config_dir,
            parts[1],
        )

        if not ref:
            continue

        exists = os.path.isfile(ref)
        readable = (
            exists
            and os.access(ref, os.R_OK)
        )

        result["references"].append({
            "directive": key,
            "path": ref,
            "status": (
                "ok"
                if readable
                else "missing"
            ),
        })

        if not readable:
            result["errors"].append(
                "Required {} file unavailable: {}".format(
                    key,
                    ref,
                )
            )

    result["ok"] = not result["errors"]

    return result



def _wireguard_endpoint_parts(value):
    """
    Parse a WireGuard Endpoint value without resolving it.

    Supported forms:
      hostname:port
      IPv4:port
      [IPv6]:port

    Protected CoreELEC handoff currently stages IPv4 endpoint
    addresses only, but bracketed IPv6 is parsed so the caller
    can return a precise validation error instead of misreading it.
    """
    value = str(value or "").strip()

    if not value:
        return None, None

    host = ""
    port = ""

    if value.startswith("["):
        end = value.find("]")

        if end <= 1:
            return None, None

        host = value[1:end].strip()
        remainder = value[end + 1:].strip()

        if not remainder.startswith(":"):
            return None, None

        port = remainder[1:].strip()

    else:
        if ":" not in value:
            return None, None

        host, port = value.rsplit(":", 1)
        host = host.strip()
        port = port.strip()

    if not host or not port:
        return None, None

    try:
        port_int = int(port)
    except (TypeError, ValueError):
        return None, None

    if not 1 <= port_int <= 65535:
        return None, None

    return host, str(port_int)


def _preflight_wireguard_profile(profile):
    """
    Read-only validation for a proposed local WireGuard profile.

    This function MUST NOT:
      - alter the profile registry
      - start/stop WireGuard
      - invoke vpn-selector
      - alter routing, DNS, or firewall state

    Stage 1 deliberately validates only. Linux/CoreELEC does not
    advertise WireGuard as a manageable profile type yet.
    """
    result = {
        "ok": False,
        "profile_id": None,
        "name": None,
        "type": "wireguard",
        "path": None,
        "active_path": active_profile_path(),
        "transports": [],
        "references": [],
        "warnings": [],
        "errors": [],
    }

    if not isinstance(profile, dict):
        result["errors"].append(
            "Invalid VPN profile"
        )
        return result

    result["profile_id"] = profile.get("id")
    result["name"] = profile.get("name")
    result["type"] = str(
        profile.get("type", "")
    ).strip().lower()

    path = str(
        profile.get("path", "")
    ).strip()

    result["path"] = path

    if not profile.get("enabled", True):
        result["errors"].append(
            "VPN profile is disabled"
        )

    if result["type"] != "wireguard":
        result["errors"].append(
            "WireGuard preflight received a non-WireGuard profile"
        )

    if not path:
        result["errors"].append(
            "WireGuard profile path is missing"
        )
        return result

    if not path.lower().endswith(".conf"):
        result["errors"].append(
            "WireGuard profile must use a .conf file"
        )

    if not os.path.isfile(path):
        result["errors"].append(
            "WireGuard profile does not exist: {}".format(
                path
            )
        )
        return result

    if not os.access(path, os.R_OK):
        result["errors"].append(
            "WireGuard profile is not readable: {}".format(
                path
            )
        )
        return result

    if not shutil.which("wg"):
        result["errors"].append(
            "WireGuard wg executable not found"
        )

    if not shutil.which("wg-quick"):
        result["errors"].append(
            "WireGuard wg-quick executable not found"
        )

    try:
        with open(
            path,
            "r",
            encoding="utf-8",
            errors="replace",
        ) as f:
            raw_lines = f.readlines()

    except Exception as exc:
        result["errors"].append(
            "Could not read WireGuard profile: {}".format(
                exc
            )
        )
        return result

    interface_count = 0
    peer_count = 0
    interface_private_key = False
    interface_address = False

    peers = []
    current_section = None
    current_peer = None

    for raw_line in raw_lines:
        line = raw_line.strip()

        if (
            not line
            or line.startswith("#")
            or line.startswith(";")
        ):
            continue

        if (
            line.startswith("[")
            and line.endswith("]")
        ):
            section = line[1:-1].strip().lower()
            current_section = section

            if section == "interface":
                interface_count += 1
                current_peer = None

            elif section == "peer":
                peer_count += 1

                current_peer = {
                    "public_key": False,
                    "allowed_ips": [],
                    "endpoint": None,
                }

                peers.append(current_peer)

            else:
                current_peer = None

            continue

        if "=" not in line:
            continue

        key, value = line.split("=", 1)

        key = key.strip().lower()
        value = value.strip()

        if current_section == "interface":
            if key in {
                "preup",
                "postup",
                "predown",
                "postdown",
            }:
                result["errors"].append(
                    "WireGuard wg-quick hook '{}' is not "
                    "permitted in managed profiles".format(
                        key
                    )
                )

            elif (
                key == "saveconfig"
                and value.lower() in {
                    "1",
                    "true",
                    "yes",
                    "on",
                }
            ):
                result["errors"].append(
                    "WireGuard SaveConfig=true is not "
                    "permitted in managed profiles"
                )

            elif (
                key == "table"
                and value.lower() not in {
                    "",
                    "auto",
                }
            ):
                result["errors"].append(
                    "WireGuard custom Table routing is not "
                    "supported by the managed protection path"
                )

            if key == "privatekey" and value:
                interface_private_key = True

            elif key == "address" and value:
                interface_address = True

        elif (
            current_section == "peer"
            and current_peer is not None
        ):
            if key == "publickey" and value:
                current_peer["public_key"] = True

            elif key == "allowedips":
                current_peer["allowed_ips"] = [
                    item.strip()
                    for item in value.split(",")
                    if item.strip()
                ]

            elif key == "endpoint" and value:
                current_peer["endpoint"] = value

    if interface_count != 1:
        result["errors"].append(
            "WireGuard profile must contain exactly one "
            "[Interface] section"
        )

    if not interface_private_key:
        result["errors"].append(
            "WireGuard [Interface] has no PrivateKey"
        )

    if not interface_address:
        result["errors"].append(
            "WireGuard [Interface] has no Address"
        )

    if not peer_count:
        result["errors"].append(
            "WireGuard profile has no [Peer] section"
        )

    full_ipv4_route = False
    endpoint_count = 0

    for index, peer in enumerate(peers, 1):
        if not peer.get("public_key"):
            result["errors"].append(
                "WireGuard peer {} has no PublicKey".format(
                    index
                )
            )

        allowed_ips = peer.get("allowed_ips") or []

        if not allowed_ips:
            result["errors"].append(
                "WireGuard peer {} has no AllowedIPs".format(
                    index
                )
            )

        if "0.0.0.0/0" in allowed_ips:
            full_ipv4_route = True

        endpoint = peer.get("endpoint")

        if not endpoint:
            continue

        endpoint_count += 1

        host, port = _wireguard_endpoint_parts(
            endpoint
        )

        if not host or not port:
            result["errors"].append(
                "WireGuard peer {} has an invalid Endpoint".format(
                    index
                )
            )
            continue

        # The present CoreELEC kill-switch/bootstrap design is
        # IPv4-only. Resolve hostnames to their IPv4 endpoint pool.
        addresses = _resolve_ipv4(host)

        transport = {
            "host": host,
            "port": port,
            "proto": "udp",
            "addresses": addresses,
        }

        result["transports"].append(
            transport
        )

        if not addresses:
            result["errors"].append(
                "Cannot resolve WireGuard IPv4 endpoint: {}".format(
                    host
                )
            )

    if endpoint_count != 1:
        result["errors"].append(
            "Managed WireGuard currently requires exactly "
            "one peer Endpoint"
        )

    if not full_ipv4_route:
        result["errors"].append(
            "Managed WireGuard requires 0.0.0.0/0 "
            "in AllowedIPs"
        )

    result["ok"] = not result["errors"]

    return result


def preflight_profile(profile):
    """
    Read-only protocol-aware local VPN profile preflight.

    WireGuard validation is available for development/testing,
    but WireGuard remains deliberately non-advertised and cannot
    yet be activated by the Linux/CoreELEC manager.
    """
    if isinstance(profile, dict):
        profile_type = str(
            profile.get("type", "")
        ).strip().lower()

        if profile_type == "wireguard":
            return _preflight_wireguard_profile(
                profile
            )

    return _preflight_openvpn_profile(
        profile
    )


def build_handoff_plan(profile):
    """
    Build a read-only protected handoff plan.

    This performs validation and endpoint staging only.
    It MUST NOT change registry state, routing, DNS, firewall,
    OpenVPN services, or selector state.
    """
    check = preflight_profile(profile)

    plan = {
        "ok": False,
        "action": "blocked",
        "profile_id": check.get("profile_id"),
        "name": check.get("name"),
        "type": check.get("type"),
        "active_path": check.get("active_path"),
        "target_path": check.get("path"),
        "transports": check.get("transports", []),
        "staged_endpoints": [],
        "errors": list(check.get("errors", [])),
        "warnings": list(check.get("warnings", [])),
    }

    if not check.get("ok"):
        return plan

    profile_type = str(
        check.get("type") or ""
    ).strip().lower()

    if profile_type not in (
        "openvpn",
        "wireguard",
    ):
        plan["errors"].append(
            "Unsupported VPN profile type"
        )
        return plan

    active_path = check.get("active_path")
    target_path = check.get("path")

    try:
        same_profile = (
            active_path
            and target_path
            and os.path.realpath(active_path)
            == os.path.realpath(target_path)
        )
    except Exception:
        same_profile = (
            active_path == target_path
        )

    if same_profile:
        plan["ok"] = True
        plan["action"] = "already_active"
        return plan

    for transport in check.get(
        "transports",
        []
    ):
        for address in transport.get(
            "addresses",
            []
        ):
            plan["staged_endpoints"].append({
                "host": transport.get("host"),
                "address": address,
                "port": transport.get("port"),
                "proto": transport.get("proto"),
            })

    if not plan["staged_endpoints"]:
        plan["errors"].append(
            "No usable VPN transport endpoints were staged"
        )
        return plan

    plan["ok"] = True
    plan["action"] = "protected_switch"

    return plan




def _profile_id_for_path(
    data,
    path,
):
    if not path:
        return None

    try:
        wanted = os.path.realpath(path)
    except Exception:
        wanted = str(path)

    for item in profile_registry.profiles(
        data
    ):
        candidate = item.get("path")

        if not candidate:
            continue

        try:
            candidate = os.path.realpath(
                candidate
            )
        except Exception:
            candidate = str(candidate)

        if candidate == wanted:
            return item.get("id")

    return None


def _current_protected_mode(data=None):
    """
    Identify the actual protected starting mode.

    local:
        A verified managed local VPN interface is carrying
        Internet traffic.

    router:
        The selector has already verified the upstream/router VPN.

    No network state is changed here.
    """
    route = internet_route()
    observed_path = None

    # Preserve existing OpenVPN precedence if an invalid state
    # ever leaves more than one managed tunnel present.
    for profile_type in (
        "openvpn",
        "wireguard",
    ):
        contract = _vpn_contract(
            profile_type
        )

        if not contract:
            continue

        active_path = active_profile_path(
            profile_type=profile_type,
            data=data,
        )

        if active_path and not observed_path:
            observed_path = active_path

        if not (
            active_path
            and tunnel_exists(profile_type)
            and _route_uses_interface(
                route,
                contract["interface"],
            )
        ):
            continue

        active_id = active_profile_id(
            data=data,
            profile_type=profile_type,
        )

        if not active_id:
            return {
                "ok": False,
                "mode": "local",
                "profile_type": profile_type,
                "interface": contract["interface"],
                "service": contract["service"],
                "active_profile_id": None,
                "active_path": active_path,
                "errors": [
                    "Local VPN is routing traffic but "
                    "its profile cannot be identified"
                ],
            }

        return {
            "ok": True,
            "mode": "local",
            "profile_type": profile_type,
            "interface": contract["interface"],
            "service": contract["service"],
            "active_profile_id": active_id,
            "active_path": active_path,
            "errors": [],
        }

    state = selector_state()

    if state == "router":
        return {
            "ok": True,
            "mode": "router",
            "profile_type": None,
            "interface": None,
            "service": None,
            "active_profile_id": None,
            "active_path": None,
            "errors": [],
        }

    return {
        "ok": False,
        "mode": state or "unknown",
        "profile_type": None,
        "interface": None,
        "service": None,
        "active_profile_id": None,
        "active_path": observed_path,
        "errors": [
            "No verified protected VPN starting mode"
        ],
    }


def _set_registry_selected(profile_id):
    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        data = profile_registry.set_selected(
            data,
            profile_id,
        )

        profile_registry.save(
            PROFILE_REGISTRY,
            data,
        )

        return {
            "ok": True,
            "profile_id": profile_id,
        }

    except Exception as exc:
        return {
            "ok": False,
            "profile_id": profile_id,
            "error": str(exc),
        }


def _set_registry_fallback(profile_id):
    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        data = profile_registry.set_fallback(
            data,
            profile_id,
        )

        profile_registry.save(
            PROFILE_REGISTRY,
            data,
        )

        return {
            "ok": True,
            "profile_id": profile_id,
        }

    except Exception as exc:
        return {
            "ok": False,
            "profile_id": profile_id,
            "error": str(exc),
        }


def build_handoff_transaction(profile):
    """
    Build a complete READ-ONLY VPN transaction.

    Router mode:
        Selecting a profile changes only the preferred local
        fallback. The verified router VPN remains authoritative.

    Local mode:
        Builds a protected local-to-local switch transaction.
    """
    plan = build_handoff_plan(profile)

    transaction = {
        "ok": False,
        "action": plan.get("action"),
        "previous_mode": None,
        "previous_profile_type": None,
        "previous_profile_id": None,
        "previous_path": plan.get("active_path"),
        "previous_endpoint": None,
        "target_profile_id": plan.get("profile_id"),
        "profile_type": plan.get("type"),
        "target_path": plan.get("target_path"),
        "endpoint": None,
        "staged_endpoints": [],
        "errors": list(
            plan.get("errors", [])
        ),
        "warnings": list(
            plan.get("warnings", [])
        ),
    }

    if not plan.get("ok"):
        return transaction

    transaction["staged_endpoints"] = [
        dict(endpoint)
        for endpoint in plan.get(
            "staged_endpoints",
            []
        )
        if isinstance(endpoint, dict)
    ]

    target_type = str(
        transaction.get("profile_type")
        or ""
    ).strip().lower()

    if not _vpn_contract(target_type):
        transaction["errors"].append(
            "Unsupported target VPN profile type"
        )
        return transaction

    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

    except Exception as exc:
        transaction["errors"].append(
            "Could not read profile registry: {}".format(
                exc
            )
        )
        return transaction

    protected = _current_protected_mode(
        data=data,
    )

    transaction["previous_mode"] = (
        protected.get("mode")
    )
    transaction["previous_profile_type"] = (
        protected.get("profile_type")
    )

    if not protected.get("ok"):
        transaction["errors"].extend(
            protected.get("errors", [])
        )
        return transaction

    registry_selected = data.get(
        "selected"
    )
    registry_fallback = data.get(
        "fallback"
    )

    # -----------------------------------------------------
    # ROUTER MODE
    #
    # The router VPN is already the verified protected path.
    # A local profile selection therefore changes only which
    # profile will be used if local fallback is later needed.
    # -----------------------------------------------------
    if protected.get("mode") == "router":
        transaction[
            "previous_profile_id"
        ] = registry_fallback

        if (
            plan.get("profile_id")
            == registry_fallback
        ):
            transaction["ok"] = True
            transaction["action"] = (
                "router_selection_unchanged"
            )
            return transaction

        endpoints = plan.get(
            "staged_endpoints",
            []
        )

        if not endpoints:
            transaction["errors"].append(
                "No preflighted fallback endpoint available"
            )
            return transaction

        chosen = endpoints[0]

        transaction["endpoint"] = {
            "address": chosen.get("address"),
            "port": chosen.get("port"),
            "proto": chosen.get("proto"),
            "host": chosen.get("host"),
        }

        transaction["ok"] = True
        transaction["action"] = (
            "select_fallback"
        )

        return transaction

    # -----------------------------------------------------
    # LOCAL MODE
    # -----------------------------------------------------

    previous_type = str(
        protected.get("profile_type")
        or ""
    ).strip().lower()

    if not _vpn_contract(previous_type):
        transaction["errors"].append(
            "Protected local VPN type is unsupported"
        )
        return transaction

    active_id = protected.get(
        "active_profile_id"
    )

    active_path = protected.get(
        "active_path"
    )

    transaction[
        "previous_profile_id"
    ] = active_id

    transaction[
        "previous_path"
    ] = active_path

    previous_endpoint = (
        _runtime_endpoint_for_profile(
            active_id
        )
    )

    if not previous_endpoint:
        transaction["errors"].append(
            "Protected local handoff refused: "
            "the active VPN has no verified pinned "
            "runtime endpoint for deterministic rollback"
        )
        return transaction

    endpoint_type = str(
        previous_endpoint.get(
            "profile_type"
        )
        or "openvpn"
    ).strip().lower()

    if endpoint_type != previous_type:
        transaction["errors"].append(
            "Protected local handoff refused: "
            "runtime endpoint type does not match "
            "the verified active VPN"
        )
        return transaction

    transaction[
        "previous_endpoint"
    ] = previous_endpoint

    if plan.get("action") == "already_active":
        transaction["ok"] = True
        transaction["action"] = (
            "already_active"
        )
        return transaction

    if registry_selected != active_id:
        transaction["errors"].append(
            "Registry selection does not match "
            "the verified active VPN profile"
        )
        return transaction

    endpoints = plan.get(
        "staged_endpoints",
        []
    )

    if not endpoints:
        transaction["errors"].append(
            "No preflighted target endpoint available"
        )
        return transaction

    chosen = endpoints[0]

    transaction["endpoint"] = {
        "address": chosen.get("address"),
        "port": chosen.get("port"),
        "proto": chosen.get("proto"),
        "host": chosen.get("host"),
    }

    transaction["ok"] = True
    transaction["action"] = (
        "protected_switch"
    )

    return transaction




def _command_result(
    args,
    timeout=30,
    env=None,
):
    if not args or not args[0]:
        return None

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            env=env,
        )

        return {
            "code": result.returncode,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
        }

    except Exception as exc:
        return {
            "code": None,
            "stdout": "",
            "stderr": str(exc),
        }



def _read_runtime_target():
    """
    Return a validated pinned runtime target, or None.

    This is deliberately strict because the value may become
    the only deterministic rollback route after the active
    tunnel has been stopped.
    """
    try:
        with open(
            RUNTIME_TARGET_FILE,
            "r",
            encoding="utf-8",
        ) as f:
            payload = json.load(f)

    except (FileNotFoundError, OSError, ValueError, TypeError):
        return None

    if not isinstance(payload, dict):
        return None

    profile_id = payload.get("profile_id")

    # Existing beta23 runtime-target files did not carry a type.
    # Treat those as OpenVPN for backward compatibility.
    profile_type = str(
        payload.get("profile_type")
        or "openvpn"
    ).strip().lower()

    if profile_type not in (
        "openvpn",
        "wireguard",
    ):
        return None

    address = payload.get("remote_address")
    port = payload.get("remote_port")
    proto = str(
        payload.get("remote_proto") or ""
    ).lower()

    if not profile_id or not address or not port:
        return None

    if proto.startswith("tcp"):
        proto = "tcp"
    elif proto.startswith("udp"):
        proto = "udp"
    else:
        return None

    try:
        socket.inet_aton(str(address))
    except OSError:
        return None

    try:
        port_int = int(port)
    except (TypeError, ValueError):
        return None

    if not 1 <= port_int <= 65535:
        return None

    return {
        "profile_id": str(profile_id),
        "profile_type": profile_type,
        "remote_address": str(address),
        "remote_port": str(port_int),
        "remote_proto": proto,
    }


def _runtime_endpoint_for_profile(profile_id):
    target = _read_runtime_target()

    if not target:
        return None

    if target.get("profile_id") != profile_id:
        return None

    return {
        "profile_type": target.get(
            "profile_type",
            "openvpn",
        ),
        "address": target.get(
            "remote_address"
        ),
        "port": target.get(
            "remote_port"
        ),
        "proto": target.get(
            "remote_proto"
        ),
        "host": None,
    }


def _write_runtime_target(transaction):
    endpoint = transaction.get("endpoint") or {}

    profile_type = str(
        transaction.get("profile_type")
        or transaction.get("type")
        or "openvpn"
    ).strip().lower()

    if profile_type not in (
        "openvpn",
        "wireguard",
    ):
        raise ValueError(
            "Unsupported runtime target profile type"
        )

    payload = {
        "profile_type": profile_type,
        "profile_id": transaction.get(
            "target_profile_id"
        ),
        "remote_address": endpoint.get(
            "address"
        ),
        "remote_port": endpoint.get(
            "port"
        ),
        "remote_proto": endpoint.get(
            "proto"
        ),
    }

    required = (
        "profile_id",
        "remote_address",
        "remote_port",
        "remote_proto",
    )

    for key in required:
        if not payload.get(key):
            raise ValueError(
                "Runtime target missing {}".format(
                    key
                )
            )

    tmp = RUNTIME_TARGET_FILE + ".tmp"

    try:
        with open(
            tmp,
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(
                payload,
                f,
                indent=2,
            )
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())

        os.chmod(tmp, 0o600)
        os.replace(
            tmp,
            RUNTIME_TARGET_FILE,
        )
        os.chmod(
            RUNTIME_TARGET_FILE,
            0o600,
        )

    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        raise



# VPN_STAGE4C_PROTOCOL_AWARE_RUNTIME_BEGIN

def _protection_env(
    profile_type="openvpn",
):
    contract = _vpn_contract(
        profile_type
    )

    if not contract:
        return None

    env = os.environ.copy()

    env[
        "VPN_MANAGER_LAUNCHER"
    ] = contract["launcher"]

    env[
        "VPN_MANAGER_INTERFACE"
    ] = contract["interface"]

    return env


def _run_dns_lock(
    action,
    profile_type="openvpn",
):
    if action not in (
        "lock",
        "unlock",
    ):
        return {
            "code": None,
            "stdout": "",
            "stderr": "Unsupported DNS lock action",
        }

    if not os.path.isfile(
        DNS_LOCK_SCRIPT
    ):
        return {
            "code": None,
            "stdout": "",
            "stderr": "DNS lock script not found",
        }

    env = _protection_env(
        profile_type
    )

    if env is None:
        return {
            "code": None,
            "stdout": "",
            "stderr": (
                "Unsupported managed VPN profile type"
            ),
        }

    return _command_result(
        [
            DNS_LOCK_SCRIPT,
            action,
        ],
        timeout=30,
        env=env,
    )


def _run_killswitch_up(
    profile_type="openvpn",
):
    if not os.path.isfile(
        KILLSWITCH_SCRIPT
    ):
        return {
            "code": None,
            "stdout": "",
            "stderr": "Kill-switch script not found",
        }

    env = _protection_env(
        profile_type
    )

    if env is None:
        return {
            "code": None,
            "stdout": "",
            "stderr": (
                "Unsupported managed VPN profile type"
            ),
        }

    return _command_result(
        [
            KILLSWITCH_SCRIPT,
            "up",
        ],
        timeout=30,
        env=env,
    )


# VPN_STAGE4C_PROTOCOL_AWARE_RUNTIME_END



def _service_action(
    action,
    profile_type="openvpn",
):
    if not SYSTEMCTL:
        return {
            "code": None,
            "stdout": "",
            "stderr": "systemctl unavailable",
        }

    contract = _vpn_contract(
        profile_type
    )

    if not contract:
        return {
            "code": None,
            "stdout": "",
            "stderr": (
                "Unsupported managed VPN profile type"
            ),
        }

    return _command_result(
        [
            SYSTEMCTL,
            action,
            contract["service"],
        ],
        timeout=40,
    )


def _wait_tunnel_absent(
    timeout=15,
    profile_type="openvpn",
):
    deadline = time.time() + timeout

    while time.time() < deadline:
        if (
            not tunnel_exists(profile_type)
            and not active_profile_path(
                profile_type=profile_type
            )
        ):
            return True

        time.sleep(0.25)

    return False


def _raw_ipv4_connectivity():
    """
    DNS-independent Internet reachability check.

    This verifies that a TCP connection can leave through the
    newly-established tunnel without relying on hostname
    resolution.
    """
    try:
        sock = socket.create_connection(
            ("1.1.1.1", 443),
            timeout=5,
        )
        sock.close()
        return True
    except Exception:
        return False


def _wait_profile_active(
    profile_id,
    timeout=45,
    profile_type="openvpn",
):
    contract = _vpn_contract(
        profile_type
    )

    if not contract:
        return False

    deadline = time.time() + timeout

    while time.time() < deadline:
        route = internet_route()

        if (
            tunnel_exists(profile_type)
            and _route_uses_interface(
                route,
                contract["interface"],
            )
            and active_profile_id(
                profile_type=profile_type
            ) == profile_id
        ):
            if _raw_ipv4_connectivity():
                return True

        time.sleep(1)

    return False


def _rollback_handoff(
    previous_profile_id,
    previous_endpoint,
    failed_profile_type="openvpn",
):
    """
    Restore the previously verified local profile using its
    exact pre-switch pinned endpoint.

    No DNS resolution is required after the target tunnel has
    failed or been stopped.
    """
    if not previous_profile_id:
        return {
            "ok": False,
            "stage": "rollback_identity",
            "detail": (
                "Previous profile identity is unavailable"
            ),
        }

    if not previous_endpoint:
        return {
            "ok": False,
            "stage": "rollback_endpoint",
            "detail": (
                "Previous pinned endpoint is unavailable"
            ),
        }

    previous_type = str(
        previous_endpoint.get(
            "profile_type"
        )
        or "openvpn"
    ).strip().lower()

    failed_type = str(
        failed_profile_type
        or "openvpn"
    ).strip().lower()

    if not _vpn_contract(previous_type):
        return {
            "ok": False,
            "stage": "rollback_previous_type",
            "detail": (
                "Previous VPN profile type is unsupported"
            ),
        }

    if not _vpn_contract(failed_type):
        return {
            "ok": False,
            "stage": "rollback_failed_type",
            "detail": (
                "Failed VPN profile type is unsupported"
            ),
        }

    stop = _service_action(
        "stop",
        profile_type=failed_type,
    )

    if (
        stop.get("code") != 0
        and (
            _service_is_active(failed_type)
            or tunnel_exists(failed_type)
        )
    ):
        return {
            "ok": False,
            "stage": "rollback_stop",
            "detail": stop,
        }

    if not _wait_tunnel_absent(
        profile_type=failed_type,
    ):
        return {
            "ok": False,
            "stage": "rollback_tunnel_stop",
            "detail": (
                "Target tunnel did not disappear"
            ),
        }

    registry = _set_registry_selected(
        previous_profile_id
    )

    if not registry.get("ok"):
        return {
            "ok": False,
            "stage": "rollback_registry",
            "detail": registry,
        }

    #
    # Restore the PREVIOUS exact runtime target before touching
    # the firewall. This is the key deterministic rollback step.
    #
    previous_transaction = {
        "target_profile_id": previous_profile_id,
        "profile_type": previous_type,
        "endpoint": previous_endpoint,
    }

    try:
        _write_runtime_target(
            previous_transaction
        )
    except Exception as exc:
        return {
            "ok": False,
            "stage": "rollback_target",
            "detail": str(exc),
        }

    protection = _run_killswitch_up(
        previous_type
    )

    if protection.get("code") != 0:
        return {
            "ok": False,
            "stage": "rollback_protection",
            "detail": protection,
        }

    #
    # Stable protection for the previous endpoint is now active.
    # Remove any stale bootstrap guard before attempting to restart
    # the previous tunnel. CE_VPN_BOOT deliberately blocks ordinary
    # WAN traffic and would otherwise reject the VPN transport that
    # the stable kill-switch has explicitly allowed.
    #
    if os.path.exists(BOOTSTRAP_GUARD_SCRIPT):
        bootstrap_ok, bootstrap_code = (
            _run_protection_command(
                [
                    BOOTSTRAP_GUARD_SCRIPT,
                    "down",
                ],
                timeout=30,
            )
        )

        if not bootstrap_ok:
            return {
                "ok": False,
                "stage": "rollback_bootstrap",
                "detail": {
                    "code": bootstrap_code,
                    "message": (
                        "Could not clear stale bootstrap "
                        "protection"
                    ),
                },
            }

        #
        # Reassert stable protection after bootstrap cleanup.
        # This also verifies that the previous endpoint remains
        # represented by the managed kill-switch state.
        #
        protection = _run_killswitch_up(
            previous_type
        )

        if protection.get("code") != 0:
            return {
                "ok": False,
                "stage": "rollback_protection_reassert",
                "detail": protection,
            }

    #
    # If a cross-protocol target failed before the previous tunnel
    # was stopped, accept that still-verified previous path without
    # unnecessarily bouncing it.
    #
    if not _wait_profile_active(
        previous_profile_id,
        timeout=3,
        profile_type=previous_type,
    ):
        start_result = _service_action(
            "start",
            profile_type=previous_type,
        )

        if start_result.get("code") != 0:
            return {
                "ok": False,
                "stage": "rollback_start",
                "detail": start_result,
            }

        if not _wait_profile_active(
            previous_profile_id,
            timeout=45,
            profile_type=previous_type,
        ):
            return {
                "ok": False,
                "stage": "rollback_verify",
                "detail": (
                    "Previous VPN profile did not "
                    "re-establish a verified tunnel"
                ),
            }

    dns = _run_dns_lock(
        "lock",
        previous_type,
    )

    if dns.get("code") != 0:
        return {
            "ok": False,
            "stage": "rollback_dns",
            "detail": dns,
        }

    finalize = _run_killswitch_up(
        previous_type
    )

    if finalize.get("code") != 0:
        return {
            "ok": False,
            "stage": "rollback_finalize",
            "detail": finalize,
        }

    return {
        "ok": True,
        "stage": "rolled_back",
    }



def _configured_fallback_profile(
    requested_profile_id=None,
):
    """Return the configured usable emergency recovery profile."""
    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        return profile_registry.usable_fallback_profile(
            data,
            exclude_profile_id=requested_profile_id,
        )

    except Exception:
        return None


def _attempt_fallback_recovery(
    requested_profile_id,
    failed_profile_type,
    previous_profile_type,
):
    """
    Attempt exactly one configured fallback recovery while the
    caller still owns the handoff lock.

    This path never reacquires the public handoff lock and never
    recursively invokes rollback/fallback recovery. Existing atomic
    kill-switch protection is retained throughout the attempt.
    """
    outcome = {
        "ok": False,
        "attempted": False,
        "profile_id": None,
        "profile_type": None,
        "stage": "fallback_unavailable",
        "detail": None,
    }

    profile = _configured_fallback_profile(
        requested_profile_id=requested_profile_id,
    )

    if not profile:
        return outcome

    fallback_id = str(
        profile.get("id") or ""
    ).strip()
    fallback_type = str(
        profile.get("type") or ""
    ).strip().lower()

    outcome["attempted"] = True
    outcome["profile_id"] = fallback_id or None
    outcome["profile_type"] = fallback_type or None

    if (
        not fallback_id
        or not _vpn_contract(fallback_type)
    ):
        outcome["stage"] = "fallback_invalid"
        return outcome

    plan = build_handoff_plan(profile)

    if not plan.get("ok"):
        outcome["stage"] = "fallback_preflight"
        outcome["detail"] = list(
            plan.get("errors", [])
        )
        return outcome

    if plan.get("action") == "already_active":
        if not _wait_profile_active(
            fallback_id,
            timeout=3,
            profile_type=fallback_type,
        ):
            outcome["stage"] = "fallback_active_verify"
            return outcome

        dns = _run_dns_lock(
            "lock",
            fallback_type,
        )

        if dns.get("code") != 0:
            outcome["stage"] = "fallback_dns"
            outcome["detail"] = dns
            return outcome

        protection = _run_killswitch_up(
            fallback_type
        )

        if protection.get("code") != 0:
            outcome["stage"] = "fallback_finalize"
            outcome["detail"] = protection
            return outcome

        commit = _set_registry_selected(
            fallback_id
        )

        if not commit.get("ok"):
            outcome["stage"] = "fallback_commit"
            outcome["detail"] = commit
            return outcome

        outcome["ok"] = True
        outcome["stage"] = "fallback_restored"
        return outcome

    if plan.get("action") != "protected_switch":
        outcome["stage"] = "fallback_plan"
        outcome["detail"] = plan.get("action")
        return outcome

    endpoint_candidates = []
    endpoint_keys = set()

    for candidate in plan.get(
        "staged_endpoints",
        [],
    ):
        if not isinstance(candidate, dict):
            continue

        key = (
            str(candidate.get("address") or ""),
            str(candidate.get("port") or ""),
            str(candidate.get("proto") or "").lower(),
        )

        if not all(key) or key in endpoint_keys:
            continue

        endpoint_keys.add(key)
        endpoint_candidates.append(
            dict(candidate)
        )

    if not endpoint_candidates:
        outcome["stage"] = "fallback_endpoints"
        return outcome

    stop_types = []

    for candidate_type in (
        failed_profile_type,
        previous_profile_type,
    ):
        candidate_type = str(
            candidate_type or ""
        ).strip().lower()

        if (
            _vpn_contract(candidate_type)
            and candidate_type not in stop_types
        ):
            stop_types.append(candidate_type)

    for stop_type in stop_types:
        stop = _service_action(
            "stop",
            profile_type=stop_type,
        )

        if (
            stop.get("code") != 0
            and (
                _service_is_active(stop_type)
                or tunnel_exists(stop_type)
            )
        ):
            outcome["stage"] = "fallback_stop"
            outcome["detail"] = stop
            return outcome

        if not _wait_tunnel_absent(
            profile_type=stop_type,
        ):
            outcome["stage"] = "fallback_tunnel_stop"
            outcome["detail"] = stop_type
            return outcome

    for attempt_index, endpoint in enumerate(
        endpoint_candidates
    ):
        if attempt_index:
            stop = _service_action(
                "stop",
                profile_type=fallback_type,
            )

            if (
                stop.get("code") != 0
                and (
                    _service_is_active(fallback_type)
                    or tunnel_exists(fallback_type)
                )
            ):
                outcome["stage"] = "fallback_retry_stop"
                outcome["detail"] = stop
                return outcome

            if not _wait_tunnel_absent(
                profile_type=fallback_type,
            ):
                outcome["stage"] = (
                    "fallback_retry_tunnel_stop"
                )
                return outcome

        transaction = {
            "target_profile_id": fallback_id,
            "profile_type": fallback_type,
            "endpoint": dict(endpoint),
        }

        try:
            _write_runtime_target(
                transaction
            )

        except Exception as exc:
            outcome["stage"] = "fallback_target"
            outcome["detail"] = str(exc)
            return outcome

        protection = _run_killswitch_up(
            fallback_type
        )

        if protection.get("code") != 0:
            outcome["stage"] = "fallback_protection"
            outcome["detail"] = protection
            return outcome

        start = _service_action(
            "start",
            profile_type=fallback_type,
        )

        if start.get("code") != 0:
            outcome["detail"] = start
            continue

        if _wait_profile_active(
            fallback_id,
            timeout=45,
            profile_type=fallback_type,
        ):
            dns = _run_dns_lock(
                "lock",
                fallback_type,
            )

            if dns.get("code") != 0:
                outcome["stage"] = "fallback_dns"
                outcome["detail"] = dns
                return outcome

            finalize = _run_killswitch_up(
                fallback_type
            )

            if finalize.get("code") != 0:
                outcome["stage"] = "fallback_finalize"
                outcome["detail"] = finalize
                return outcome

            commit = _set_registry_selected(
                fallback_id
            )

            if not commit.get("ok"):
                outcome["stage"] = "fallback_commit"
                outcome["detail"] = commit
                return outcome

            outcome["ok"] = True
            outcome["stage"] = "fallback_restored"
            outcome["detail"] = None
            return outcome

        outcome["stage"] = "fallback_verify"
        outcome["detail"] = (
            "Fallback VPN endpoint failed verification "
            "(attempt {}/{})".format(
                attempt_index + 1,
                len(endpoint_candidates),
            )
        )

    # Deliberately do not tear protection down here.
    return outcome


def _rollback_or_fallback(
    previous_profile_id,
    previous_endpoint,
    failed_profile_type,
    requested_profile_id,
    previous_profile_type,
):
    """Rollback first; use configured fallback only if rollback fails."""
    rollback = _rollback_handoff(
        previous_profile_id,
        previous_endpoint,
        failed_profile_type=failed_profile_type,
    )

    recovery = {
        "rollback": rollback,
        "fallback": None,
    }

    if rollback.get("ok"):
        return recovery

    recovery["fallback"] = _attempt_fallback_recovery(
        requested_profile_id=requested_profile_id,
        failed_profile_type=failed_profile_type,
        previous_profile_type=previous_profile_type,
    )

    return recovery


def _apply_recovery_result(
    result,
    recovery,
):
    """Map rollback/fallback recovery into the public handoff result."""
    rollback = recovery.get("rollback") or {}
    fallback = recovery.get("fallback")

    result["rolled_back"] = bool(
        rollback.get("ok")
    )
    result["rollback_stage"] = rollback.get(
        "stage"
    )
    result["fallback_attempted"] = bool(
        fallback and fallback.get("attempted")
    )
    result["fallback_profile_id"] = (
        fallback.get("profile_id")
        if fallback
        else None
    )
    result["fallback_restored"] = bool(
        fallback and fallback.get("ok")
    )

    if rollback.get("ok"):
        result["stage"] = rollback.get(
            "stage",
            "rolled_back",
        )
        return

    rollback_stage = rollback.get(
        "stage",
        "rollback_failed",
    )

    result["errors"].append(
        "Rollback failed at {}".format(
            rollback_stage
        )
    )

    if not fallback:
        result["stage"] = "recovery_failed"
        return

    if fallback.get("ok"):
        result["stage"] = "fallback_restored"
        return

    if not fallback.get("attempted"):
        result["stage"] = "fallback_unavailable"
        return

    fallback_stage = fallback.get(
        "stage",
        "fallback_failed",
    )

    result["errors"].append(
        "Fallback recovery failed at {}".format(
            fallback_stage
        )
    )
    result["stage"] = fallback_stage



def _execute_handoff_locked(
    profile,
    dry_run=True,
):
    """
    Execute a VPN profile transaction.

    dry_run=True is deliberately mandatory by default.
    """
    transaction = build_handoff_transaction(
        profile
    )

    result = {
        "ok": False,
        "dry_run": bool(dry_run),
        "action": transaction.get("action"),
        "previous_mode": transaction.get(
            "previous_mode"
        ),
        "previous_profile_type": (
            transaction.get(
                "previous_profile_type"
            )
        ),
        "previous_profile_id": (
            transaction.get(
                "previous_profile_id"
            )
        ),
        "previous_endpoint": (
            transaction.get(
                "previous_endpoint"
            )
        ),
        "profile_type": transaction.get(
            "profile_type"
        ),
        "target_profile_id": (
            transaction.get(
                "target_profile_id"
            )
        ),
        "endpoint": transaction.get(
            "endpoint"
        ),
        "staged_endpoints": [
            dict(endpoint)
            for endpoint in transaction.get(
                "staged_endpoints",
                []
            )
            if isinstance(endpoint, dict)
        ],
        "stage": "preflight",
        "rolled_back": False,
        "rollback_stage": None,
        "fallback_attempted": False,
        "fallback_profile_id": None,
        "fallback_restored": False,
        "errors": list(
            transaction.get(
                "errors",
                []
            )
        ),
    }

    if not transaction.get("ok"):
        return result

    if transaction.get("action") in (
        "already_active",
        "router_selection_unchanged",
    ):
        result["ok"] = True
        result["stage"] = transaction.get(
            "action"
        )
        return result

    if dry_run:
        result["ok"] = True
        result["stage"] = "dry_run_ready"
        return result

    target_id = transaction.get(
        "target_profile_id"
    )

    target_type = str(
        transaction.get("profile_type")
        or ""
    ).strip().lower()

    if not _vpn_contract(target_type):
        result["errors"].append(
            "Unsupported target VPN profile type"
        )
        return result

    # -----------------------------------------------------
    # ROUTER MODE
    #
    # Do not disturb the router VPN. Merely commit the
    # validated preferred local fallback profile.
    # -----------------------------------------------------
    if (
        transaction.get("previous_mode")
        == "router"
    ):
        if (
            transaction.get("action")
            != "select_fallback"
        ):
            result["errors"].append(
                "Unexpected router-mode transaction"
            )
            return result

        commit = _set_registry_fallback(
            target_id
        )

        if not commit.get("ok"):
            result["errors"].append(
                "Could not save fallback profile: {}".format(
                    commit.get("error")
                )
            )
            result["stage"] = (
                "fallback_commit_failed"
            )
            return result

        result["ok"] = True
        result["stage"] = (
            "fallback_selected"
        )

        return result

    # -----------------------------------------------------
    # LOCAL MODE
    # -----------------------------------------------------

    if (
        transaction.get("previous_mode")
        != "local"
    ):
        result["errors"].append(
            "Unsupported protected starting mode"
        )
        return result

    if not SYSTEMCTL:
        result["errors"].append(
            "systemctl unavailable"
        )
        return result

    previous_type = str(
        transaction.get(
            "previous_profile_type"
        )
        or ""
    ).strip().lower()

    if not _vpn_contract(previous_type):
        result["errors"].append(
            "Protected handoff refused: "
            "previous VPN type is unsupported"
        )
        return result

    if not kill_switch_active(
        previous_type
    ):
        result["errors"].append(
            "Protected handoff refused: "
            "current kill switch is not active"
        )
        return result

    previous_id = transaction.get(
        "previous_profile_id"
    )

    previous_endpoint = transaction.get(
        "previous_endpoint"
    )

    if not previous_endpoint:
        result["errors"].append(
            "Protected handoff refused: "
            "deterministic rollback endpoint unavailable"
        )
        return result

    try:
        _write_runtime_target(
            transaction
        )

    except Exception as exc:
        result["errors"].append(
            "Could not stage runtime target: {}".format(
                exc
            )
        )
        return result

    result["stage"] = "target_staged"

    protection = _run_killswitch_up(
        target_type
    )

    if protection.get("code") != 0:
        try:
            _write_runtime_target(
                {
                    "target_profile_id": previous_id,
                    "profile_type": previous_type,
                    "endpoint": previous_endpoint,
                }
            )
            restore = _run_killswitch_up(
                previous_type
            )

        except Exception as exc:
            restore = {
                "code": None,
                "stderr": str(exc),
            }

        result["stage"] = (
            "target_protection_failed"
        )

        result["errors"].append(
            protection.get("stderr")
            or "Could not stage target kill-switch rules"
        )

        if restore.get("code") != 0:
            result["errors"].append(
                "Could not restore previous kill-switch rules"
            )

        return result

    result["stage"] = "target_protected"

    stop = _service_action(
        "stop",
        profile_type=previous_type,
    )

    if stop.get("code") != 0:
        result["errors"].append(
            stop.get("stderr")
            or "Could not stop current OpenVPN service"
        )

        recovery = _rollback_or_fallback(
            previous_id,
            previous_endpoint,
            failed_profile_type=target_type,
            requested_profile_id=target_id,
            previous_profile_type=previous_type,
        )
        _apply_recovery_result(
            result,
            recovery,
        )

        return result

    if not _wait_tunnel_absent(
        profile_type=previous_type,
    ):
        result["errors"].append(
            "Current tunnel did not fully stop"
        )

        recovery = _rollback_or_fallback(
            previous_id,
            previous_endpoint,
            failed_profile_type=target_type,
            requested_profile_id=target_id,
            previous_profile_type=previous_type,
        )
        _apply_recovery_result(
            result,
            recovery,
        )

        return result

    result["stage"] = "old_tunnel_stopped"

    endpoint_candidates = []
    endpoint_keys = set()

    for candidate in transaction.get(
        "staged_endpoints",
        [],
    ):
        if not isinstance(candidate, dict):
            continue

        key = (
            str(candidate.get("address") or ""),
            str(candidate.get("port") or ""),
            str(candidate.get("proto") or "").lower(),
        )

        if (
            not all(key)
            or key in endpoint_keys
        ):
            continue

        endpoint_keys.add(key)
        endpoint_candidates.append(
            dict(candidate)
        )

    initial_endpoint = transaction.get(
        "endpoint"
    ) or {}

    initial_key = (
        str(initial_endpoint.get("address") or ""),
        str(initial_endpoint.get("port") or ""),
        str(initial_endpoint.get("proto") or "").lower(),
    )

    if (
        all(initial_key)
        and initial_key not in endpoint_keys
    ):
        endpoint_candidates.insert(
            0,
            dict(initial_endpoint),
        )

    if not endpoint_candidates:
        result["errors"].append(
            "No protected target endpoint candidates available"
        )

        recovery = _rollback_or_fallback(
            previous_id,
            previous_endpoint,
            failed_profile_type=target_type,
            requested_profile_id=target_id,
            previous_profile_type=previous_type,
        )
        _apply_recovery_result(
            result,
            recovery,
        )

        return result

    target_verified = False

    for attempt_index, candidate in enumerate(
        endpoint_candidates
    ):
        if attempt_index:
            stop_failed = _service_action(
                "stop",
                profile_type=target_type,
            )

            if stop_failed.get("code") != 0:
                result["errors"].append(
                    stop_failed.get("stderr")
                    or "Could not stop failed target VPN attempt"
                )
                break

            if not _wait_tunnel_absent(
                profile_type=target_type,
            ):
                result["errors"].append(
                    "Failed target tunnel did not fully stop"
                )
                break

            transaction["endpoint"] = dict(
                candidate
            )
            result["endpoint"] = dict(
                candidate
            )

            try:
                _write_runtime_target(
                    transaction
                )
            except Exception as exc:
                result["errors"].append(
                    "Could not stage retry target: {}".format(
                        exc
                    )
                )
                break

            retry_protection = _run_killswitch_up(
                target_type
            )

            if retry_protection.get("code") != 0:
                result["errors"].append(
                    retry_protection.get("stderr")
                    or "Could not refresh protected retry transport"
                )
                break

            result["stage"] = (
                "target_retry_protected"
            )

        start_result = _service_action(
            "start",
            profile_type=target_type,
        )

        if start_result.get("code") != 0:
            result["errors"].append(
                start_result.get("stderr")
                or "Could not start target OpenVPN service"
            )
            continue

        result["stage"] = "target_started"

        if _wait_profile_active(
            target_id,
            timeout=45,
            profile_type=target_type,
        ):
            target_verified = True
            result["stage"] = "target_verified"
            break

        result["errors"].append(
            "Target VPN endpoint failed verification "
            "(attempt {}/{})".format(
                attempt_index + 1,
                len(endpoint_candidates),
            )
        )

    if not target_verified:
        recovery = _rollback_or_fallback(
            previous_id,
            previous_endpoint,
            failed_profile_type=target_type,
            requested_profile_id=target_id,
            previous_profile_type=previous_type,
        )
        _apply_recovery_result(
            result,
            recovery,
        )

        return result

    dns = _run_dns_lock(
        "lock",
        target_type,
    )

    if dns.get("code") != 0:
        result["errors"].append(
            dns.get("stderr")
            or "Could not lock DNS to target VPN interface"
        )

        recovery = _rollback_or_fallback(
            previous_id,
            previous_endpoint,
            failed_profile_type=target_type,
            requested_profile_id=target_id,
            previous_profile_type=previous_type,
        )
        _apply_recovery_result(
            result,
            recovery,
        )

        return result

    result["stage"] = "target_dns_locked"

    finalize = _run_killswitch_up(
        target_type
    )

    if finalize.get("code") != 0:
        result["errors"].append(
            finalize.get("stderr")
            or "Could not finalize target kill-switch rules"
        )

        recovery = _rollback_or_fallback(
            previous_id,
            previous_endpoint,
            failed_profile_type=target_type,
            requested_profile_id=target_id,
            previous_profile_type=previous_type,
        )
        _apply_recovery_result(
            result,
            recovery,
        )

        return result

    result["stage"] = "target_protection_finalized"

    commit = _set_registry_selected(
        target_id
    )

    if not commit.get("ok"):
        result["errors"].append(
            "Could not commit selected profile: {}".format(
                commit.get("error")
            )
        )

        recovery = _rollback_or_fallback(
            previous_id,
            previous_endpoint,
            failed_profile_type=target_type,
            requested_profile_id=target_id,
            previous_profile_type=previous_type,
        )
        _apply_recovery_result(
            result,
            recovery,
        )

        return result

    result["ok"] = True
    result["stage"] = "committed"

    return result




def connect(profile):
    if not isinstance(profile, dict):
        return _profile_error(
            "Invalid VPN profile"
        )

    if not profile.get("enabled", True):
        return _profile_error(
            "VPN profile is disabled"
        )

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    if profile_type not in (
        "openvpn",
        "wireguard",
    ):
        return _profile_error(
            "Unsupported CoreELEC VPN profile type"
        )

    if not can_manage_profile(profile):
        return _profile_error(
            "VPN profile or manager backend unavailable"
        )

    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        protected = _current_protected_mode(
            data=data
        )

        if (
            protected.get("ok")
            and protected.get("mode") == "local"
        ):
            return execute_handoff(
                profile,
                dry_run=False,
            )

        data = profile_registry.upsert(
            data,
            profile
        )

        data = profile_registry.set_selected(
            data,
            profile["id"]
        )

        selected = profile_registry.selected_profile(
            data
        )

        if not selected:
            return _profile_error(
                "Could not select VPN profile"
            )

        profile_registry.save(
            PROFILE_REGISTRY,
            data
        )

    except Exception as exc:
        return _profile_error(
            "Could not update VPN profile registry: {}".format(
                exc
            )
        )

    #
    # Do NOT start OpenVPN directly.
    # The selector first verifies the upstream/router path,
    # then starts the managed local fallback only if required.
    #
    clock_ok, clock_detail = (
        _sync_bootstrap_clock()
    )

    if not clock_ok:

        try:
            with open(
                STATE_FILE,
                "w",
                encoding="utf-8",
            ) as f:
                f.write("failed\n")

        except Exception:
            pass

        return {
            "ok": False,
            "code": None,
            "message": (
                "Time synchronization failed. "
                "Fail-closed protection remains active."
            ),
            "state": "failed",
        }

    code = request_refresh()

    if code == 0:
        return {
            "ok": True,
            "code": code,
            "message": "Protected VPN selection completed",
            "state": selector_state(),
        }

    return {
        "ok": False,
        "code": code,
        "message": "Protected VPN selection failed",
        "state": selector_state(),
    }


def _run_protection_command(
    command,
    timeout=30,
):
    try:
        result = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
        )

        return (
            result.returncode == 0,
            result.returncode,
        )

    except Exception:
        return False, None


def _sync_bootstrap_clock():
    """
    Synchronize system time through the narrow NTP exception
    already established by vpn-bootstrap-guard.sh.
    """

    import socket
    import time

    ntpd = shutil.which(
        "ntpd"
    )

    if not ntpd:
        return (
            False,
            "ntpd unavailable",
        )

    peer_file = (
        "/run/vpn-bootstrap-ntp.peers"
    )

    try:
        with open(
            peer_file,
            "r",
            encoding="utf-8",
        ) as f:
            peers = [
                line.strip()
                for line in f
                if line.strip()
            ]

    except Exception:
        peers = []

    if not peers:
        return (
            False,
            "no bootstrap NTP peers",
        )

    for peer in peers:

        try:
            socket.inet_aton(
                peer
            )
        except OSError:
            continue

        try:
            result = subprocess.run(
                [
                    ntpd,
                    "-q",
                    "-p",
                    peer,
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=25,
            )

        except Exception:
            continue

        if result.returncode != 0:
            continue

        # Jan 1 2025 UTC.
        #
        # This catches the known stale-RTC condition while
        # avoiding dependence on an external date source.
        if time.time() >= 1735689600:
            return (
                True,
                "clock synchronized",
            )

    return (
        False,
        "NTP synchronization failed",
    )


def disable_protection():
    """
    Deliberately enter an unprotected state.

    This is an explicit user action. The persistent marker
    suppresses automatic selector/fallback reconnection until
    enable_protection() is called.
    """

    if protection_disabled():
        return {
            "ok": True,
            "code": 0,
            "message":
                "VPN protection is already disabled",
            "state": "disabled",
        }

    if not SYSTEMCTL:
        return {
            "ok": False,
            "code": None,
            "message":
                "systemctl unavailable",
            "state": selector_state(),
        }

    try:
        _set_protection_disabled(
            True
        )

    except Exception as exc:
        return {
            "ok": False,
            "code": None,
            "message":
                "Could not enter disabled mode: "
                "{}".format(exc),
            "state": selector_state(),
        }

    errors = []

    # Stop the selector first so it cannot race the
    # deliberately disabled state.
    ok, code = _run_protection_command(
        [
            SYSTEMCTL,
            "stop",
            SELECTOR_SERVICE,
        ],
        timeout=30,
    )

    if not ok:
        errors.append(
            "selector stop failed ({})"
            .format(code)
        )

    # Keep fail-closed protection in place while OpenVPN
    # is being stopped.
    ok, code = _run_protection_command(
        [
            SYSTEMCTL,
            "stop",
            MANAGED_OPENVPN_SERVICE,
        ],
        timeout=30,
    )

    if not ok:
        errors.append(
            "OpenVPN stop failed ({})"
            .format(code)
        )

    bootstrap_guard = BOOTSTRAP_GUARD_SCRIPT

    if os.path.exists(
        bootstrap_guard
    ):
        ok, code = _run_protection_command(
            [
                bootstrap_guard,
                "down",
            ],
            timeout=30,
        )

        if not ok:
            errors.append(
                "bootstrap guard disable failed ({})"
                .format(code)
            )

    dns_script = DNS_LOCK_SCRIPT

    if os.path.exists(dns_script):
        ok, code = _run_protection_command(
            [
                dns_script,
                "unlock",
            ]
        )

        if not ok:
            errors.append(
                "DNS unlock failed ({})"
                .format(code)
            )

    else:
        errors.append(
            "DNS lock script missing"
        )

    if os.path.exists(
        KILLSWITCH_SCRIPT
    ):
        ok, code = _run_protection_command(
            [
                KILLSWITCH_SCRIPT,
                "down",
            ]
        )

        if not ok:
            errors.append(
                "kill switch disable failed ({})"
                .format(code)
            )

    else:
        errors.append(
            "kill switch script missing"
        )

    try:
        with open(
            STATE_FILE,
            "w",
            encoding="utf-8",
        ) as f:
            f.write("disabled\n")

    except Exception as exc:
        errors.append(
            "state write failed: {}"
            .format(exc)
        )

    if tunnel_exists():
        errors.append(
            "local VPN tunnel still present"
        )

    if kill_switch_active():
        errors.append(
            "kill switch still active"
        )

    if errors:
        return {
            "ok": False,
            "code": None,
            "message": (
                "Protection disable incomplete. "
                "Automatic reconnect remains "
                "suppressed.\n\n{}"
            ).format(
                "; ".join(errors)
            ),
            "state": "disabled",
        }

    return {
        "ok": True,
        "code": 0,
        "message": (
            "VPN protection disabled. "
            "Automatic reconnect is suppressed "
            "until protection is enabled again."
        ),
        "state": "disabled",
    }


def enable_protection():
    """
    Safely leave deliberate disabled mode.

    The existing fail-closed bootstrap guard is armed before
    the disabled marker is removed. Therefore a subsequent
    selector/VPN failure cannot expose ordinary ISP traffic.
    """

    #
    # Re-resolve managed/legacy ownership at the point of use.
    #
    _refresh_host_runtime_bindings()

    bootstrap_guard = BOOTSTRAP_GUARD_SCRIPT

    #
    # Protection ON is idempotent. If deliberate-disabled mode
    # has already been cleared, do not disturb an existing path.
    #
    if not protection_disabled():
        return {
            "ok": True,
            "code": 0,
            "message": "VPN protection is already enabled.",
            "state": selector_state(),
        }

    #
    # Existing protected local path:
    #
    # A selector run may already have established tun0 and the
    # fail-closed kill switch while the user-disabled marker is
    # still present. Do not stack the bootstrap guard in front
    # of that working kill switch. Doing so can block OpenVPN's
    # own transport.
    #
    protected = _current_protected_mode()

    if (
        protected.get("ok")
        and protected.get("mode") == "local"
        and tunnel_exists()
        and kill_switch_active()
    ):
        #
        # Remove any stale/partial bootstrap chain first. The
        # established OpenVPN kill switch remains fail-closed.
        #
        if os.path.exists(bootstrap_guard):
            ok, code = _run_protection_command(
                [
                    bootstrap_guard,
                    "down",
                ],
                timeout=30,
            )

            if not ok:
                return {
                    "ok": False,
                    "code": code,
                    "message": (
                        "Existing VPN protection is active, "
                        "but stale bootstrap protection could "
                        "not be cleared."
                    ),
                    "state": "disabled",
                }

        #
        # Never clear deliberate-disabled mode unless the
        # protected local path survived bootstrap cleanup.
        #
        if not (
            tunnel_exists()
            and kill_switch_active()
        ):
            return {
                "ok": False,
                "code": None,
                "message": (
                    "Existing protected VPN state changed "
                    "during reconciliation. Protection "
                    "remains disabled."
                ),
                "state": "disabled",
            }

        try:
            _set_protection_disabled(False)

        except Exception as exc:
            return {
                "ok": False,
                "code": None,
                "message": (
                    "Could not leave disabled mode: "
                    "{}".format(exc)
                ),
                "state": "disabled",
            }

        #
        # Re-run normal selection after clearing the marker so
        # profile/router state can reconcile without ever
        # dropping the existing fail-closed local protection.
        #
        code = request_refresh()

        if code == 0:
            return {
                "ok": True,
                "code": 0,
                "message": (
                    "VPN protection enabled from the "
                    "existing protected tunnel."
                ),
                "state": selector_state(),
            }

        return {
            "ok": False,
            "code": code,
            "message": (
                "Protected selection refresh failed. "
                "Existing fail-closed VPN protection "
                "remains active."
            ),
            "state": selector_state(),
        }


    if not os.path.exists(bootstrap_guard):
        return {
            "ok": False,
            "code": None,
            "message": (
                "Bootstrap guard is missing. "
                "Protection remains disabled."
            ),
            "state": selector_state(),
        }

    # Still deliberately disabled here.
    # First remove unrestricted WAN access by arming
    # the existing fail-closed bootstrap guard.
    ok, guard_code = _run_protection_command(
        [
            bootstrap_guard,
            "up",
        ],
        timeout=60,
    )

    if not ok:
        return {
            "ok": False,
            "code": guard_code,
            "message": (
                "Could not arm fail-closed protection. "
                "Protection remains disabled."
            ),
            "state": selector_state(),
        }

    # Fail-closed protection is now active, so it is safe
    # to leave deliberate disabled mode.
    try:
        _set_protection_disabled(False)

    except Exception as exc:
        # Return to the original deliberately-unprotected
        # state if the marker cannot be cleared.
        _run_protection_command(
            [
                bootstrap_guard,
                "down",
            ],
            timeout=30,
        )

        return {
            "ok": False,
            "code": None,
            "message": (
                "Could not leave disabled mode: "
                "{}".format(exc)
            ),
            "state": selector_state(),
        }

    try:
        os.remove(STATE_FILE)
    except FileNotFoundError:
        pass
    except Exception:
        pass

    code = request_refresh()

    if code == 0:
        return {
            "ok": True,
            "code": code,
            "message": (
                "VPN protection enabled."
            ),
            "state": selector_state(),
        }

    # Deliberately DO NOT recreate the disabled marker.
    # The bootstrap guard is already active, so selector
    # failure must remain fail-closed.
    return {
        "ok": False,
        "code": code,
        "message": (
            "Protected selection failed. "
            "Fail-closed protection remains active."
        ),
        "state": selector_state(),
    }



def disconnect(profile):
    if not isinstance(profile, dict):
        return _profile_error(
            "Invalid VPN profile"
        )

    #
    # Never deliberately remove the local protected path unless
    # the selector has already established that the router VPN
    # is the authoritative protected path.
    #
    state = selector_state()

    if state != "router":
        return {
            "ok": False,
            "code": None,
            "message": (
                "Local VPN disconnect refused: "
                "no verified upstream VPN path"
            ),
            "state": state,
        }

    if not SYSTEMCTL:
        return _profile_error(
            "systemctl unavailable"
        )

    profile_type = str(
        profile.get("type") or ""
    ).strip().lower()

    contract = _vpn_contract(profile_type)

    if not contract:
        return _profile_error(
            "Unsupported VPN profile type"
        )

    try:
        result = subprocess.run(
            [
                SYSTEMCTL,
                "stop",
                contract["service"],
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=30,
        )

        return {
            "ok": result.returncode == 0,
            "code": result.returncode,
            "message": (
                "Managed local VPN stopped; "
                "verified router VPN retained"
            ),
            "state": state,
        }

    except Exception as exc:
        return {
            "ok": False,
            "code": None,
            "message": str(exc),
            "state": state,
        }


def supported_profile_types():
    return [
        "openvpn",
        "wireguard",
    ]


def active_profile_path(
    profile_type="openvpn",
    data=None,
):
    """
    Return the source config path represented by the active
    managed VPN runtime.

    OpenVPN retains process/cmdline identification.
    WireGuard uses managed-service + runtime-target identity.
    """
    profile_type = str(
        profile_type or "openvpn"
    ).strip().lower()

    if profile_type == "wireguard":
        identity = _wireguard_active_identity(
            data=data
        )

        if not identity:
            return None

        return identity.get("path")

    if profile_type != "openvpn":
        return None

    try:
        pids = os.listdir("/proc")
    except OSError:
        return None

    for pid in pids:
        if not pid.isdigit():
            continue

        try:
            with open(
                "/proc/{}/cmdline".format(pid),
                "rb",
            ) as f:
                raw = f.read()
        except (OSError, IOError):
            continue

        if not raw:
            continue

        args = [
            part.decode(
                "utf-8",
                errors="replace",
            )
            for part in raw.split(b"\0")
            if part
        ]

        if not args:
            continue

        if os.path.basename(
            args[0]
        ) != "openvpn":
            continue

        for index, arg in enumerate(args):
            if (
                arg == "--config"
                and index + 1 < len(args)
            ):
                return args[index + 1]

    return None
def active_profile_id(
    data=None,
    profile_type="openvpn",
):
    """
    Return the registry profile ID represented by the active
    managed VPN runtime.

    OpenVPN retains process/config identification.
    WireGuard uses the validated managed runtime target because
    the kernel interface has no OpenVPN-style process command
    line.
    """
    profile_type = str(
        profile_type or "openvpn"
    ).strip().lower()

    if profile_type == "wireguard":
        identity = _wireguard_active_identity(
            data=data
        )

        if not identity:
            return None

        return identity.get(
            "profile_id"
        )

    if profile_type != "openvpn":
        return None

    active_path = active_profile_path(
        profile_type="openvpn",
        data=data,
    )

    if not active_path:
        return None

    if data is None:
        try:
            data = profile_registry.load(
                PROFILE_REGISTRY
            )
        except Exception:
            return None

    direct = _profile_id_for_path(
        data,
        active_path,
    )

    if direct:
        return direct

    try:
        effective = (
            os.path.realpath(active_path)
            == os.path.realpath(
                EFFECTIVE_OPENVPN_CONFIG
            )
        )
    except Exception:
        effective = (
            active_path
            == EFFECTIVE_OPENVPN_CONFIG
        )

    if not effective:
        return None

    target = _read_runtime_target()

    if (
        not target
        or target.get("profile_type")
        != "openvpn"
    ):
        return None

    profile_id = str(
        target.get("profile_id") or ""
    ).strip()

    if not profile_id:
        return None

    for profile in profile_registry.profiles(
        data
    ):
        if profile.get("id") == profile_id:
            return profile_id

    return None

def execute_handoff(
    profile,
    dry_run=True,
):
    """
    Execute a VPN profile transaction with cross-process exclusion.

    The lock prevents the periodic selector from starting while a
    protected handoff owns OpenVPN/runtime/firewall mutation.
    """
    if dry_run:
        return _execute_handoff_locked(
            profile,
            dry_run=True,
        )

    if not _acquire_handoff_lock():
        return {
            "ok": False,
            "dry_run": False,
            "action": None,
            "stage": "handoff_busy",
            "rolled_back": False,
            "errors": [
                "Another VPN handoff is already in progress"
            ],
        }

    try:
        return _execute_handoff_locked(
            profile,
            dry_run=False,
        )
    finally:
        _release_handoff_lock()
