# Kodi VPN Manager Changelog

## Unreleased - Stage 4C

### Added
- Added configurable K-RAM dashboard metrics showing Kodi process RSS in MB and as a percentage of physical RAM.
- Atomic dual-stack CoreELEC OpenVPN kill-switch handoffs with temporary guard protection during protected profile transitions.
- Production protected handoffs between supported OpenVPN and WireGuard profiles.
- Cross-process transaction locking between protected VPN handoffs and periodic selector recovery.
- OpenVPN endpoint-pool preservation and guarded retry of alternate resolved endpoints.
- Configurable emergency fallback VPN profile used only when a failed protected handoff cannot restore the previous verified protected connection.
- Fallback-profile browser with provider grouping, a None option, MRU recent profiles, and a configurable recent-profile limit.
- Dedicated diagnostic logging for protected handoff validation, commit, rollback, recovery, and failure results.

### Changed
- OpenVPN preflight preserves the provider hostname when resolving managed profiles whose effective runtime configuration contains a pinned endpoint address.
- Protected handoffs are protocol-aware for OpenVPN and WireGuard while retaining fail-closed protection during transitions.
- Protected OpenVPN handoffs retry staged endpoint candidates while retaining fail-closed protection.
- Failed protected handoffs restore the previous verified protected state first and attempt the configured fallback profile only if that rollback cannot restore verified protection.
- Emergency fallback recovery is limited to one attempt, suppresses the originally requested target, and remains fail-closed if recovery also fails.
- Automatic rollback clears stale bootstrap protection before restarting the previous VPN and then reasserts stable kill-switch protection.
- Protected handoff diagnostics flow through the existing privacy-filtered logging path and, when enabled, `vpn-manager.log`.

### Fixed
- Periodic selector recovery could race a protected profile handoff and interfere with OpenVPN/runtime state.
- A failed OpenVPN endpoint could unnecessarily fail a profile switch when another resolved endpoint was available.
- Stale bootstrap protection could reject the previous VPN transport during automatic rollback.
- Protected handoff failures shown in the UI were not consistently written to the dedicated diagnostic log.
- Protected-state recognition now requires both IPv4 and IPv6 stable kill-switch protection.
- Stable kill-switch recognition now matches complete firewall rules so temporary guard or emergency chains cannot be mistaken for stable protection.

### Validation
- Exhaustive production OpenVPN regression covered all 254 production profiles.
- IPv4 and IPv6 fail-closed monitoring observed zero protection gaps during the Stage 4C regression.
- Endpoint failures exercised automatic rollback while stable protection remained active.
- Final targeted retests of Zurich UDP, Tbilisi TCP, and Astana TCP committed successfully with zero dual-stack protection gaps.
- Private WireGuard handoff regression validated OpenVPN-to-WireGuard and WireGuard-to-OpenVPN transitions with zero observed IPv4 or IPv6 protection gaps.
- Public WireGuard regression reached the WireGuard runtime but the available PureVPN peer configuration did not establish a verified handshake; rollback restored the previous OpenVPN connection with zero observed dual-stack protection gaps.
- Emergency recovery regression validated rollback-first behavior, fallback restoration after forced rollback failure, and fail-closed behavior when both rollback and fallback were forced to fail.
- Dual-stack recognition regression verified that missing stable IPv6 protection is rejected while emergency IPv6 protection remains fail-closed, followed by successful atomic restoration.

## 0.1.1~beta22 - 2026-09-24

### Changed
- Validation release for the Kodi repository update lifecycle fix introduced in beta21.
- No runtime behavior changes from beta21.

## 0.1.1~beta21 - 2026-09-24

### Fixed
- Normal Kodi repository updates no longer raise a Kodi VPN Manager error while the previous service instance is shutting down.
- Full-IP logging reset now safely tolerates Kodi temporarily deregistering the add-on during install, update, or removal lifecycle transitions.

## 0.1.1~beta20 - 2026-09-24

### Added
- VPN exit-location verification against the selected profile, with Match, Mismatch, and Unverified dashboard states.
- Delayed GeoIP diagnostic resynchronization after profile changes to avoid accepting stale location data.

### Changed
- GeoIP verification now normalizes provider location data and prefers coherent city/country records instead of combining fields from different sources.
- Dashboard publishing and country-flag handling were consolidated to remove historical wrapper layers and redundant flag updates.
- Release builds now exclude Git metadata and common backup, temporary, and rejected-patch artifacts.
- VPN diagnostics now consistently redact IPv4 and IPv6 addresses without a full-IP logging bypass.

### Fixed
- CoreELEC fail-closed recovery could block its own DNS, NTP, and selected OpenVPN endpoint traffic while bootstrap protection was active.
- Profile changes could temporarily verify against stale GeoIP data from the previously connected VPN location.
- Exit-country and selected-profile flags could be recalculated repeatedly through layered dashboard publishers.

### Maintenance
- Removed unused legacy functions and the obsolete settings_action.py dispatcher.
- Removed duplicate backend/helper implementations and stale development scaffolding.

## 0.1.1~beta19 - 2026-09-13

### Added
- Provider-level OpenVPN credential inheritance with optional per-profile overrides.
- Country-grouped profile browsing with remembered country selection and back navigation.
- Optional CPU, GPU, DDR-temperature, and RAM dashboard metrics.
- CoreELEC/OpenVFD VPN-state indication using the SETUP icon and clock flashing.
- Deliberate VPN-protection disabled mode with automatic reconnect suppression.
- Single VPN protection on/off control with fail-closed re-entry.
- Debug setting for temporary full-IP logging.
- Default IP-address redaction in Kodi VPN Manager logs.
- Restricted NTP bootstrap support for stale-clock recovery before OpenVPN TLS validation.

### Changed
- PureVPN profiles now inherit service-level credentials by default.
- Protection-state transitions distinguish deliberate unprotected mode from fail-closed recovery.
- Profile browser now separates country navigation from individual VPN profiles.
- VPN logging now preserves only the first IPv4 octet by default and redacts IPv6 addresses.
- Full-IP diagnostic logging automatically resets off on service and dashboard lifecycle boundaries.

### Fixed
- OpenVPN launcher handling of empty authentication IDs.
- Duplicate profile activation caused by overlapping Kodi click/action events.
- VPN reconnect failure when a deliberately disabled session was re-enabled without first restoring fail-closed protection.
- Stale system clocks preventing OpenVPN certificate validation while fail-closed rules blocked time synchronization.
- CoreELEC bootstrap protection now permits only narrowly scoped NTP traffic required to establish a sane clock.

## 0.1.1~beta18 - 2026-09-11

### Added
- Manual OpenVPN profile creation with server, port, and UDP/TCP selection.
- OpenVPN profile import into VPN Manager-managed storage.
- Server syntax and DNS-resolution validation for manually added profiles.
- Profile editing and managed profile deletion.
- Username/password credential management for OpenVPN profiles.
- Password confirmation when setting or changing credentials.
- Protected runtime credential injection into the effective OpenVPN configuration.
- Automatic cleanup of runtime credential files and effective OpenVPN configuration when the managed tunnel stops.
- Packaged CoreELEC DNS-lock component with transactional migration support.

### Changed
- Profile selection now responds correctly to Kodi Select/Enter actions.
- Managed profile deletion now removes unreferenced authentication records and secrets.
- Credential secrets are stored separately from profile metadata with restrictive file permissions.
- CoreELEC migration now validates, backs up, installs, and rolls back the DNS-lock component.

### Security
- OpenVPN passwords are not stored in profiles.json or embedded in generated .ovpn files.
- Runtime authentication files are created with mode 0600 in a mode 0700 runtime directory and removed after tunnel shutdown.
- Credential-aware deletion avoids leaving orphaned VPN secrets.


## 0.1.1~beta17 - 2026-09-10

### Added
- Automatic VPN watchdog for protected router/local VPN recovery.
- Lightweight router exit-IP monitoring.
- Physical-WAN recovery probing to distinguish detector failure from upstream failure.
- Backoff/recovery handling for temporary WAN and DNS outages.
- Protected router-to-local OpenVPN fallback.
- Automatic local OpenVPN-to-router VPN recovery.
- Exact preflighted OpenVPN endpoint pinning.
- Runtime target handoff for managed OpenVPN.
- Profile Manager three-column layout and protected profile activation workflow.

### Changed
- Replaced frequent full selector polling with lightweight Kodi-service monitoring.
- Local OpenVPN fallback now uses the same exact preflighted endpoint for the launcher and kill switch.
- Improved router/local handoff transaction and verification logic.
- Improved profile preflight and rollback behavior.
- Old vpn-selector systemd timer remains disabled.

### Fixed
- Prevented repeated full selector runs during temporary WAN/DNS outages.
- Fixed missing backend time/socket dependencies encountered during transaction testing.
- Improved fail-closed handling when physical Internet is unavailable.
- Improved deterministic rollback to the previous protected VPN path.
- Improved DNS-lock and kill-switch coordination during local fallback.

### Verified
- Real router VPN -> local OpenVPN automatic failover.
- Real local OpenVPN -> verified router VPN automatic failback.
- Fail-closed behavior during physical upstream outage.
- Pinned OpenVPN endpoint, kill switch, DNS lock, routing, and tun0 state.
- Profile switching and router-managed fallback selection.

## 0.1.1~beta16

- Previous published beta.
- Repository packaging and distribution baseline used for beta17 development.
