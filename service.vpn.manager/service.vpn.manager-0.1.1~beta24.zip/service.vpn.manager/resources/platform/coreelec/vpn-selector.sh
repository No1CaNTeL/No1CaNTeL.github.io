#!/bin/sh

OVPN_SERVICE="vpn-manager-openvpn.service"
KILLSWITCH="/storage/.config/vpn-manager/bin/openvpn-killswitch.sh"
BOOTGUARD="/storage/.config/vpn-manager/bin/vpn-bootstrap-guard.sh"
DNSLOCK="/storage/.config/vpn-manager/bin/openvpn-dns-lock.sh"
ADDON_ROOT="/storage/.kodi/addons/service.vpn.manager"
RUNTIME_TARGET="/run/vpn-manager-openvpn.target.json"
EFFECTIVE_CONFIG="/run/vpn-manager-openvpn.effective.ovpn"
IPT="/usr/sbin/iptables"

# VPN_STAGE4C_PROTOCOL_AWARE_SELECTOR_BEGIN

WG_SERVICE="vpn-manager-wireguard.service"

OVPN_LAUNCHER="/storage/.config/vpn-manager/bin/vpn-manager-openvpn-launcher.py"
WG_LAUNCHER="/storage/.config/vpn-manager/bin/vpn-manager-wireguard-launcher.py"

LOCAL_PROFILE_TYPE=""
LOCAL_SERVICE=""
LOCAL_INTERFACE=""
LOCAL_LAUNCHER=""


set_local_contract()
{
    case "$1" in
        openvpn)
            LOCAL_PROFILE_TYPE="openvpn"
            LOCAL_SERVICE="$OVPN_SERVICE"
            LOCAL_INTERFACE="tun0"
            LOCAL_LAUNCHER="$OVPN_LAUNCHER"
            ;;

        wireguard)
            LOCAL_PROFILE_TYPE="wireguard"
            LOCAL_SERVICE="$WG_SERVICE"
            LOCAL_INTERFACE="wg0"
            LOCAL_LAUNCHER="$WG_LAUNCHER"
            ;;

        *)
            return 1
            ;;
    esac

    return 0
}


run_killswitch()
{
    [ -n "$LOCAL_LAUNCHER" ] || return 1
    [ -n "$LOCAL_INTERFACE" ] || return 1

    VPN_MANAGER_LAUNCHER="$LOCAL_LAUNCHER" \
    VPN_MANAGER_INTERFACE="$LOCAL_INTERFACE" \
        "$KILLSWITCH" "$1"
}


run_dnslock()
{
    [ -n "$LOCAL_INTERFACE" ] || return 1

    VPN_MANAGER_INTERFACE="$LOCAL_INTERFACE" \
        "$DNSLOCK" "$1"
}


get_current_local_type()
{
    if systemctl is-active --quiet "$OVPN_SERVICE" &&
       ip route get 1.1.1.1 2>/dev/null |
           grep -Eq '(^|[[:space:]])dev[[:space:]]+tun0([[:space:]]|$)'; then
        echo openvpn
        return 0
    fi

    if systemctl is-active --quiet "$WG_SERVICE" &&
       ip route get 1.1.1.1 2>/dev/null |
           grep -Eq '(^|[[:space:]])dev[[:space:]]+wg0([[:space:]]|$)'; then
        echo wireguard
        return 0
    fi

    return 1
}


# VPN_STAGE4C_PROTOCOL_AWARE_SELECTOR_END


STATE_FILE="/run/vpn-selector.state"
UPSTREAM_IP_FILE="/run/vpn-selector.upstream-ip"

redact_ip_stream()
{
    sed -E 's/([0-9]{1,3})\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/\1.x.x.x/g' |
    awk '
    function mask_ipv6(line, out, token, tmp, colons, first)
    {
        out = ""

        while (match(line, /[0-9A-Fa-f:]+/)) {
            out = out substr(line, 1, RSTART - 1)
            token = substr(line, RSTART, RLENGTH)
            tmp = token
            colons = gsub(/:/, ":", tmp)

            if (colons >= 2 && (colons >= 3 || token ~ /::/ || token ~ /[A-Fa-f]/)) {
                first = token
                sub(/:.*/, "", first)

                if (first == "") {
                    out = out "x"
                } else {
                    out = out first ":x"
                }
            } else {
                out = out token
            }

            line = substr(line, RSTART + RLENGTH)
        }

        return out line
    }

    {
        print mask_ipv6($0)
    }
    '
}

get_lan_context()
{
    LANIF=""
    LANIP=""
    LAN=""
    DEFAULT_IF=""

    #
    # Find a normal non-tunnel default interface when available.
    #
    DEFAULT_ROUTES="$(ip -4 route show table main default 2>/dev/null)"

    while IFS= read -r LINE
    do
        [ -n "$LINE" ] || continue

        set -- $LINE
        [ "${1:-}" = "default" ] || continue

        IFACE=""
        PREV=""

        for TOKEN in "$@"
        do
            if [ "$PREV" = "dev" ]; then
                IFACE="$TOKEN"
                break
            fi
            PREV="$TOKEN"
        done

        case "$IFACE" in
            ""|lo|tun*|tap*|wg*|ppp*|vpn*|docker*|veth*|tailscale*)
                continue
                ;;
        esac

        DEFAULT_IF="$IFACE"
        break
    done <<EOF
$DEFAULT_ROUTES
EOF

    #
    # Enumerate physical interfaces with global IPv4 addresses.
    # Try the ordinary default interface first, then any others.
    #
    ADDR_LINES="$(ip -o -4 addr show scope global 2>/dev/null)"

    for PASS in default others
    do
        while IFS= read -r LINE
        do
            [ -n "$LINE" ] || continue

            set -- $LINE
            IFACE="${2:-}"
            IFACE="${IFACE%%@*}"

            case "$IFACE" in
                ""|lo|tun*|tap*|wg*|ppp*|vpn*|docker*|veth*|tailscale*)
                    continue
                    ;;
            esac

            if [ "$PASS" = "default" ]; then
                [ -n "$DEFAULT_IF" ] || continue
                [ "$IFACE" = "$DEFAULT_IF" ] || continue
            else
                [ "$IFACE" != "$DEFAULT_IF" ] || continue
            fi

            if [ -r "/sys/class/net/$IFACE/carrier" ]; then
                CARRIER="$(cat "/sys/class/net/$IFACE/carrier" 2>/dev/null)"
                [ "$CARRIER" = "1" ] || continue
            fi

            ADDR_LINE="$(
                ip -o -4 addr show dev "$IFACE" \
                    scope global 2>/dev/null |
                    head -n 1
            )"

            [ -n "$ADDR_LINE" ] || continue

            set -- $ADDR_LINE
            CIDR="${4:-}"
            LANIP="${CIDR%/*}"

            [ -n "$LANIP" ] || continue

            LINK_ROUTES="$(
                ip -4 route show table main \
                    dev "$IFACE" scope link 2>/dev/null
            )"

            while IFS= read -r ROUTE_LINE
            do
                [ -n "$ROUTE_LINE" ] || continue

                set -- $ROUTE_LINE
                NETWORK="${1:-}"

                case "$NETWORK" in
                    ""|default)
                        continue
                        ;;
                esac

                SRCIP=""
                PREV=""

                for TOKEN in "$@"
                do
                    if [ "$PREV" = "src" ]; then
                        SRCIP="$TOKEN"
                        break
                    fi
                    PREV="$TOKEN"
                done

                [ "$SRCIP" = "$LANIP" ] || continue

                LANIF="$IFACE"
                LAN="$NETWORK"
                return 0
            done <<EOF
$LINK_ROUTES
EOF

        done <<EOF
$ADDR_LINES
EOF
    done

    return 1
}

get_lan_interface()
{
    #
    # CoreELEC can reach network-online.target before Wi-Fi
    # has received its usable IPv4 address/routes.
    #
    # Wait briefly rather than failing the boot selector
    # immediately. Kodi remains blocked only for this bounded
    # startup window because the selector unit is Before=kodi.
    #
    for WAIT in \
        1 2 3 4 5 6 7 8 9 10 \
        11 12 13 14 15 16 17 18 19 20 \
        21 22 23 24 25 26 27 28 29 30
    do
        if get_lan_context; then
            return 0
        fi

        sleep 1
    done

    return 1
}


get_current_path()
{
    if get_current_local_type >/dev/null 2>&1; then
        echo local
        return
    fi

    SAVED="$(cat "$STATE_FILE" 2>/dev/null)"

    if [ "$SAVED" = "router" ]; then
        echo router
    else
        echo unknown
    fi
}

get_upstream_ip()
{
    curl --interface "$LANIF" -4fsS \
        --connect-timeout 5 --max-time 10 \
        https://api.ipify.org 2>/dev/null
}

check_iplogs()
{
    DATA="$(curl --interface "$LANIF" -4fsS \
        --connect-timeout 5 --max-time 10 \
        -X POST https://iplogs.com/v1/check \
        -H 'Content-Type: application/json' \
        -d '{}' 2>/dev/null |
        tr -d '[:space:]')" || {
            echo X
            return
        }

    printf '%s' "$DATA" | grep -Fq "\"ip\":\"$UPIP\"" || {
        echo X
        return
    }

    if printf '%s' "$DATA" | grep -Fq '"is_vpn":true' &&
       printf '%s' "$DATA" | grep -Fq '"verdict":"vpn_detected"'; then
        echo 1
    elif printf '%s' "$DATA" | grep -Fq '"is_vpn":false'; then
        echo 0
    else
        echo X
    fi
}

check_proxycheck()
{
    DATA="$(curl --interface "$LANIF" -4fsS \
        --connect-timeout 5 --max-time 10 \
        "https://proxycheck.io/v2/$UPIP?vpn=2" 2>/dev/null |
        tr -d '[:space:]')" || {
            echo X
            return
        }

    printf '%s' "$DATA" | grep -Fq '"status":"ok"' || {
        echo X
        return
    }

    if printf '%s' "$DATA" | grep -Fq '"proxy":"yes"' &&
       printf '%s' "$DATA" | grep -Fq '"type":"VPN"'; then
        echo 1
    elif printf '%s' "$DATA" | grep -Fq '"proxy":"no"'; then
        echo 0
    else
        echo X
    fi
}

# SELECTOR_REDESIGN_V1

start_local_probe()
{
    DETECTOR_IPS="$(
        {
            getent ahostsv4 api.ipify.org 2>/dev/null
            getent ahostsv4 iplogs.com 2>/dev/null
            getent ahostsv4 proxycheck.io 2>/dev/null
        } | awk '/^[0-9]+\./ && !seen[$1]++ {print $1}'
    )"

    [ -n "$DETECTOR_IPS" ] || return 1

    $IPT -N CE_VPN_PROBE 2>/dev/null || true
    $IPT -F CE_VPN_PROBE

    while $IPT -D OUTPUT -j CE_VPN_PROBE 2>/dev/null; do :; done

    for IP in $DETECTOR_IPS; do
        $IPT -A CE_VPN_PROBE -o "$LANIF" \
            -d "$IP" -p tcp --dport 443 -j ACCEPT
    done

    $IPT -A CE_VPN_PROBE -j RETURN
    $IPT -I OUTPUT 1 -j CE_VPN_PROBE
}

stop_local_probe()
{
    while $IPT -D OUTPUT -j CE_VPN_PROBE 2>/dev/null; do :; done
    $IPT -F CE_VPN_PROBE 2>/dev/null || true
    $IPT -X CE_VPN_PROBE 2>/dev/null || true
}

verify_upstream()
{
    echo "Running full VPN verification..."

    IPLOGS="$(check_iplogs)"
    PROXYCHECK="$(check_proxycheck)"

    echo "IPLogs VPN:     $IPLOGS"
    echo "Proxycheck VPN: $PROXYCHECK"

    [ "$IPLOGS" = "1" ] && [ "$PROXYCHECK" = "1" ]
}

bootstrap_guard_active()
{
    $IPT -C OUTPUT -j CE_VPN_BOOT >/dev/null 2>&1
}


clear_runtime_target()
{
    rm -f "$RUNTIME_TARGET" "$EFFECTIVE_CONFIG"
}


stage_local_target()
{
    [ -d "$ADDON_ROOT" ] || {
        echo "ERROR: VPN Manager add-on root is unavailable."
        return 1
    }

    STAGED="$(
        cd "$ADDON_ROOT" || exit 1

        python3 - <<'PY_STAGE'
import sys

from resources.lib import profiles
from resources.lib.backends import linux


REG = (
    "/storage/.kodi/userdata/addon_data/"
    "service.vpn.manager/profiles.json"
)


try:
    data = profiles.load(REG)

    profile_id = data.get("selected")

    if not profile_id:
        raise RuntimeError(
            "No preferred local VPN profile is selected"
        )

    profile = next(
        (
            item
            for item in profiles.profiles(data)
            if item.get("id") == profile_id
        ),
        None,
    )

    if profile is None:
        raise RuntimeError(
            "Selected VPN profile is missing from registry"
        )

    #
    # Use the normal/public protocol-aware preflight plan.
    #
    plan = linux.build_handoff_plan(
        profile
    )

    if not plan.get("ok"):
        errors = plan.get("errors") or [
            "Selected profile failed preflight"
        ]

        raise RuntimeError(
            "; ".join(errors)
        )

    profile_type = str(
        plan.get("type")
        or profile.get("type")
        or "openvpn"
    ).strip().lower()

    if profile_type not in (
        "openvpn",
        "wireguard",
    ):
        raise RuntimeError(
            "Unsupported local VPN profile type"
        )

    endpoints = plan.get(
        "staged_endpoints"
    ) or []

    if not endpoints:
        raise RuntimeError(
            "No preflighted target endpoint is available"
        )

    chosen = endpoints[0]

    address = chosen.get("address")
    port = chosen.get("port")
    proto = chosen.get("proto")
    host = chosen.get("host")

    if not address or not port or not proto:
        raise RuntimeError(
            "Preflight returned an incomplete endpoint"
        )

    transaction = {
        "target_profile_id": profile_id,
        "profile_type": profile_type,
        "endpoint": {
            "address": address,
            "port": port,
            "proto": proto,
            "host": host,
        },
    }

    linux._write_runtime_target(
        transaction
    )

    print(
        "{}|{}|{}|{}|{}".format(
            profile_id,
            profile_type,
            address,
            port,
            proto,
        )
    )

except Exception as exc:
    print(
        "ERROR: {}".format(exc),
        file=sys.stderr,
    )

    sys.exit(1)
PY_STAGE
    )" || return 1

    [ -n "$STAGED" ] || {
        echo "ERROR: Runtime target staging returned no result."
        return 1
    }

    OLDIFS="$IFS"
    IFS='|'
    set -- $STAGED
    IFS="$OLDIFS"

    STAGED_PROFILE_ID="$1"
    STAGED_PROFILE_TYPE="$2"
    STAGED_ADDRESS="$3"
    STAGED_PORT="$4"
    STAGED_PROTO="$5"

    [ -n "$STAGED_PROFILE_ID" ] &&
    [ -n "$STAGED_PROFILE_TYPE" ] &&
    [ -n "$STAGED_ADDRESS" ] &&
    [ -n "$STAGED_PORT" ] &&
    [ -n "$STAGED_PROTO" ] || {
        echo "ERROR: Invalid staged target result."
        return 1
    }

    set_local_contract "$STAGED_PROFILE_TYPE" || {
        echo "ERROR: Unsupported staged VPN type."
        return 1
    }

    echo "Pinned local fallback:"
    echo " profile=$STAGED_PROFILE_ID"
    echo " type=$STAGED_PROFILE_TYPE"

    printf ' endpoint=%s:%s %s\n' \
        "$STAGED_ADDRESS" \
        "$STAGED_PORT" \
        "$STAGED_PROTO" |
        redact_ip_stream

    return 0
}

verify_staged_target()
{
    [ -n "${STAGED_PROFILE_ID:-}" ] || return 1
    [ -n "${STAGED_PROFILE_TYPE:-}" ] || return 1

    (
        cd "$ADDON_ROOT" || exit 1

        python3 \
            - "$STAGED_PROFILE_ID" "$STAGED_PROFILE_TYPE" \
            <<'PY_VERIFY'
import sys

from resources.lib.backends import linux


profile_id = sys.argv[1]
profile_type = sys.argv[2]

ok = linux._wait_profile_active(
    profile_id,
    timeout=45,
    profile_type=profile_type,
)

sys.exit(0 if ok else 1)
PY_VERIFY
    )
}

killswitch_active()
{
    [ -n "${LOCAL_INTERFACE:-}" ] || return 1

    "$IPT" -C OUTPUT \
        -j CE_OVPN_KS \
        >/dev/null 2>&1 || return 1

    "$IPT" -C CE_OVPN_KS \
        -o "$LOCAL_INTERFACE" \
        -j RETURN \
        >/dev/null 2>&1 || return 1

    "$IP6T" -C OUTPUT \
        -j CE_OVPN_KS6 \
        >/dev/null 2>&1 || return 1

    "$IP6T" -C CE_OVPN_KS6 \
        -j REJECT \
        >/dev/null 2>&1
}

keep_local()
{
    printf '%s\n' local > "$STATE_FILE"

    if [ -n "${UPIP:-}" ]; then
        printf '%s\n' "$UPIP" > "$UPSTREAM_IP_FILE"
    fi

    echo "Keeping local managed VPN protection."
    exit 0
}

use_router()
{
    echo "UPSTREAM VPN CONFIRMED"

    for SERVICE in \
        "$OVPN_SERVICE" \
        "$WG_SERVICE"
    do
        if systemctl is-active --quiet "$SERVICE"; then
            echo "Stopping unnecessary local managed VPN service: $SERVICE"

            systemctl stop "$SERVICE" || {
                echo "ERROR: Could not stop $SERVICE"
                exit 1
            }
        fi
    done

    clear_runtime_target

    "$DNSLOCK" unlock 2>/dev/null || true
    "$KILLSWITCH" down 2>/dev/null || true
    "$BOOTGUARD" down

    printf '%s\n' router > "$STATE_FILE"
    printf '%s\n' "$UPIP" > "$UPSTREAM_IP_FILE"

    echo "Using router/upstream VPN."
    exit 0
}

use_local()
{
    printf '%s\n' failed > "$STATE_FILE"

    echo "Upstream VPN not confirmed."
    echo "Entering fail-closed local fallback."

    #
    # Never let a previous failed transaction influence a new
    # fallback attempt.
    #
    clear_runtime_target

    if bootstrap_guard_active; then
        echo "Bootstrap guard already ACTIVE."
    else
        echo "Activating bootstrap guard..."

        "$BOOTGUARD" up || {
            echo "ERROR: Bootstrap guard could not initialize."
            echo "Local managed VPN will NOT be started."
            exit 1
        }
    fi

    echo "Preflighting preferred local fallback..."

    if ! stage_local_target; then
        echo "ERROR: Local fallback preflight/staging failed."
        echo "Bootstrap guard remains ACTIVE."
        echo "Local managed VPN will NOT be started."
        exit 1
    fi

    echo "Installing pinned managed VPN kill switch..."

    run_killswitch up || {
        echo "ERROR: Could not activate pinned VPN kill switch."
        echo "Bootstrap guard remains ACTIVE."
        echo "Local managed VPN will NOT be started."
        exit 1
    }

    "$BOOTGUARD" down 2>/dev/null || true

    if systemctl is-active --quiet "$LOCAL_SERVICE"; then
        echo "Local managed VPN already running."
    else
        echo "Starting pinned local managed VPN fallback..."

        if ! systemctl start "$LOCAL_SERVICE"; then
            printf '%s\n' failed > "$STATE_FILE"

            echo "ERROR: Could not start local managed VPN."
            echo "Pinned VPN kill switch remains ACTIVE."
            exit 1
        fi
    fi

    echo "Verifying exact local VPN profile and Internet path..."

    if ! verify_staged_target; then
        echo "ERROR: Local VPN failed protected verification."

        systemctl stop "$LOCAL_SERVICE" 2>/dev/null || true

        printf '%s\n' failed > "$STATE_FILE"

        echo "Local managed VPN has been stopped."
        echo "Pinned VPN kill switch remains ACTIVE."
        echo "WAN remains fail-closed."
        exit 1
    fi

    run_dnslock lock || {
        echo "ERROR: Could not lock DNS to the VPN tunnel."
        echo "Pinned VPN kill switch remains ACTIVE."
        exit 1
    }

    run_killswitch up || {
        echo "ERROR: Could not finalize kill switch after DNS lock."
        echo "Existing fail-closed protection remains in place."
        exit 1
    }

    printf '%s\n' local > "$STATE_FILE"

    if [ -n "${UPIP:-}" ]; then
        printf '%s\n' "$UPIP" > "$UPSTREAM_IP_FILE"
    fi

    echo "LOCAL MANAGED VPN ACTIVE"
    echo "Verified profile: $STAGED_PROFILE_ID"
    echo "Verified type: $STAGED_PROFILE_TYPE"

    exit 0
}

if ! get_lan_interface; then
    printf '%s\n' failed > "$STATE_FILE"
    echo "ERROR: Could not determine physical Internet interface."
    exit 1
fi


CURRENT="$(get_current_path)"
LASTIP="$(cat "$UPSTREAM_IP_FILE" 2>/dev/null)"

if [ "$CURRENT" = "local" ]; then
    CURRENT_LOCAL_TYPE="$(
        get_current_local_type
    )"

    if [ -z "$CURRENT_LOCAL_TYPE" ] ||
       ! set_local_contract "$CURRENT_LOCAL_TYPE"
    then
        printf '%s\n' failed > "$STATE_FILE"

        echo "ERROR: Could not identify active local VPN contract."
        exit 1
    fi
fi

echo "Physical Internet interface: $LANIF"
echo "Current VPN path: $CURRENT"

if [ "$CURRENT" = "local" ]; then
    echo "Current local VPN type: $LOCAL_PROFILE_TYPE"
fi

#
# LOCAL MODE
# Keep the working tunnel and kill switch intact.
# Resolve detector hosts through VPN DNS, then temporarily permit
# only those HTTPS probes on the physical interface.
#
if [ "$CURRENT" = "local" ]; then
    #
    # A firewall reload can flush our private iptables chain
    # without stopping OpenVPN or removing tun0. Restore the
    # fail-closed layer before doing any router recovery probe.
    #
    if ! killswitch_active; then
        echo "WARNING: Local VPN is active but kill switch is missing; repairing missing kill switch."

        run_killswitch up || {
            printf '%s\n' failed > "$STATE_FILE"
            echo "ERROR: Could not restore local VPN kill switch."
            exit 1
        }

        killswitch_active || {
            printf '%s\n' failed > "$STATE_FILE"
            echo "ERROR: Local VPN kill switch repair did not verify."
            exit 1
        }

        echo "Local VPN kill switch restored."
    fi

    echo "Checking whether router/upstream VPN has returned..."

    if ! start_local_probe; then
        echo "WARNING: Could not prepare safe upstream probe."
        keep_local
    fi

    trap 'stop_local_probe' 0 2 15

    UPIP="$(get_upstream_ip)"

    if [ -z "$UPIP" ]; then
        echo "Physical upstream IP unavailable; keeping local VPN."
        stop_local_probe
        trap - 0 2 15
        keep_local
    fi

    printf 'Physical upstream IP: %s\n' "$UPIP" |
        redact_ip_stream
    printf 'Previous upstream IP: %s\n' "${LASTIP:-unknown}" |
        redact_ip_stream

    if [ -n "$LASTIP" ] && [ "$UPIP" = "$LASTIP" ]; then
        echo "Physical upstream IP unchanged."
        stop_local_probe
        trap - 0 2 15
        keep_local
    fi

    if verify_upstream; then
        stop_local_probe
        trap - 0 2 15
        use_router
    fi

    stop_local_probe
    trap - 0 2 15
    keep_local
fi

#
# ROUTER MODE
# Do not install the bootstrap firewall merely to verify an
# already-established router/upstream VPN.
#
if [ "$CURRENT" = "router" ]; then
    UPIP="$(get_upstream_ip)"

    if [ -z "$UPIP" ]; then
        echo "ERROR: Physical upstream IP unavailable."
        use_local
    fi

    printf 'Physical upstream IP: %s\n' "$UPIP" |
        redact_ip_stream
    printf 'Previous upstream IP: %s\n' "${LASTIP:-unknown}" |
        redact_ip_stream

    if [ -n "$LASTIP" ] && [ "$UPIP" = "$LASTIP" ]; then
        echo "Upstream IP unchanged; keeping verified router VPN."
        "$KILLSWITCH" down 2>/dev/null || true
        "$BOOTGUARD" down 2>/dev/null || true
        printf '%s\n' router > "$STATE_FILE"
        exit 0
    fi

    echo "Upstream IP changed."

    if verify_upstream; then
        use_router
    fi

    use_local
fi

#
# UNKNOWN / STARTUP MODE
# This is where bootstrap fail-close belongs: before we know
# whether any trusted VPN path exists.
#
printf '%s\n' failed > "$STATE_FILE"

echo "VPN path unknown; activating bootstrap protection."

"$BOOTGUARD" up || {
    echo "ERROR: Bootstrap guard could not initialize."
    echo "WAN remains blocked if guard rules were installed."
    exit 1
}

UPIP="$(get_upstream_ip)"

if [ -z "$UPIP" ]; then
    echo "ERROR: Could not determine physical upstream public IP."
    use_local
fi

printf 'Physical upstream IP: %s\n' "$UPIP" |
    redact_ip_stream
printf 'Previous upstream IP: %s\n' "${LASTIP:-unknown}" |
    redact_ip_stream

if verify_upstream; then
    use_router
fi

use_local
