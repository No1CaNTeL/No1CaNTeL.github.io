#!/usr/bin/env python3

import argparse
import ipaddress
import json
import os
import re
import shutil
import subprocess
import sys


DEFAULT_REGISTRY = (
    "/storage/.kodi/userdata/addon_data/"
    "service.vpn.manager/profiles.json"
)

# Stage 2 deliberately shares the existing pinned-target file.
# The filename remains OpenVPN-named for beta23 compatibility;
# a later runtime migration may rename it atomically.
DEFAULT_TARGET = (
    "/run/vpn-manager-openvpn.target.json"
)

DEFAULT_RUNTIME_DIR = (
    "/run/vpn-manager-wireguard"
)

DEFAULT_EFFECTIVE_CONFIG = (
    DEFAULT_RUNTIME_DIR + "/wg0.conf"
)

DEFAULT_INTERFACE = "wg0"

UNSAFE_HOOKS = {
    "preup",
    "postup",
    "predown",
    "postdown",
}


def fail(message, code=1):
    print(
        "VPN Manager WireGuard: ERROR: {}".format(
            message
        ),
        file=sys.stderr,
    )
    raise SystemExit(code)


def _load_json(path, label):
    try:
        with open(
            path,
            "r",
            encoding="utf-8",
        ) as f:
            data = json.load(f)

    except FileNotFoundError:
        fail(
            "{} not found: {}".format(
                label,
                path,
            )
        )

    except Exception as exc:
        fail(
            "Could not read {}: {}".format(
                label,
                exc,
            )
        )

    if not isinstance(data, dict):
        fail("Invalid {}".format(label))

    return data


def load_target_profile(
    registry_path,
    target_path,
):
    target = _load_json(
        target_path,
        "runtime VPN target",
    )

    profile_type = str(
        target.get("profile_type") or ""
    ).strip().lower()

    if profile_type != "wireguard":
        fail(
            "Runtime target profile is not WireGuard"
        )

    profile_id = str(
        target.get("profile_id") or ""
    ).strip()

    if not profile_id:
        fail(
            "Runtime VPN target has no profile_id"
        )

    remote_address = str(
        target.get("remote_address") or ""
    ).strip()

    try:
        address = ipaddress.ip_address(
            remote_address
        )
    except ValueError:
        fail(
            "Invalid runtime target IPv4 address"
        )

    if address.version != 4:
        fail(
            "Runtime target endpoint must be IPv4"
        )

    remote_port = str(
        target.get("remote_port") or ""
    ).strip()

    if (
        not remote_port.isdigit()
        or not 1 <= int(remote_port) <= 65535
    ):
        fail(
            "Invalid runtime target port"
        )

    remote_proto = str(
        target.get("remote_proto") or ""
    ).strip().lower()

    if not remote_proto.startswith("udp"):
        fail(
            "WireGuard runtime target must use UDP"
        )

    registry = _load_json(
        registry_path,
        "profile registry",
    )

    for item in registry.get("profiles", []):
        if not isinstance(item, dict):
            continue

        if str(item.get("id") or "") != profile_id:
            continue

        if not item.get("enabled", True):
            fail(
                "Runtime target profile is disabled"
            )

        if str(
            item.get("type") or ""
        ).strip().lower() != "wireguard":
            fail(
                "Runtime target profile is not WireGuard"
            )

        profile_path = str(
            item.get("path") or ""
        ).strip()

        if not profile_path:
            fail(
                "Runtime target profile has no config path"
            )

        if not profile_path.lower().endswith(
            ".conf"
        ):
            fail(
                "WireGuard profile must use a .conf file"
            )

        if not os.path.isfile(profile_path):
            fail(
                "WireGuard config not found: {}".format(
                    profile_path
                )
            )

        if not os.access(
            profile_path,
            os.R_OK,
        ):
            fail(
                "WireGuard config is not readable"
            )

        profile = dict(item)

        profile["_runtime_target"] = {
            "profile_id": profile_id,
            "profile_type": "wireguard",
            "remote_address": str(address),
            "remote_port": remote_port,
            "remote_proto": "udp",
        }

        return profile

    fail(
        "Runtime target profile '{}' not found".format(
            profile_id
        )
    )


def _parse_directive(line):
    stripped = line.strip()

    if (
        not stripped
        or stripped.startswith("#")
        or stripped.startswith(";")
        or "=" not in stripped
    ):
        return None, None

    key, value = stripped.split("=", 1)

    return (
        key.strip().lower(),
        value.strip(),
    )


def materialize_effective_config(
    profile,
    output_path=DEFAULT_EFFECTIVE_CONFIG,
):
    source_path = str(
        profile.get("path") or ""
    ).strip()

    runtime_target = (
        profile.get("_runtime_target") or {}
    )

    remote_address = str(
        runtime_target.get("remote_address") or ""
    ).strip()

    remote_port = str(
        runtime_target.get("remote_port") or ""
    ).strip()

    try:
        parsed_address = ipaddress.ip_address(
            remote_address
        )
    except ValueError:
        fail(
            "Invalid pinned WireGuard endpoint"
        )

    if parsed_address.version != 4:
        fail(
            "Pinned WireGuard endpoint must be IPv4"
        )

    if (
        not remote_port.isdigit()
        or not 1 <= int(remote_port) <= 65535
    ):
        fail(
            "Invalid pinned WireGuard endpoint port"
        )

    try:
        with open(
            source_path,
            "r",
            encoding="utf-8",
            errors="replace",
        ) as f:
            source_lines = f.readlines()

    except Exception as exc:
        fail(
            "Could not read WireGuard config: {}".format(
                exc
            )
        )

    output = []

    current_section = None
    interface_count = 0
    peer_count = 0
    endpoint_count = 0
    replaced_endpoint_count = 0

    have_private_key = False
    have_address = False
    have_full_ipv4_route = False

    for raw_line in source_lines:
        stripped = raw_line.strip()

        if (
            stripped.startswith("[")
            and stripped.endswith("]")
        ):
            current_section = (
                stripped[1:-1]
                .strip()
                .lower()
            )

            if current_section == "interface":
                interface_count += 1

            elif current_section == "peer":
                peer_count += 1

            output.append(raw_line)
            continue

        key, value = _parse_directive(
            raw_line
        )

        if key is None:
            output.append(raw_line)
            continue

        if key in UNSAFE_HOOKS:
            fail(
                "wg-quick hook '{}' is not permitted".format(
                    key
                )
            )

        if (
            key == "saveconfig"
            and value.lower() in {
                "1",
                "true",
                "yes",
                "on",
            }
        ):
            fail(
                "SaveConfig=true is not permitted"
            )

        if (
            key == "table"
            and value.lower() not in {
                "",
                "auto",
            }
        ):
            fail(
                "Custom WireGuard Table routing is not "
                "supported"
            )

        if current_section == "interface":
            if key == "privatekey" and value:
                have_private_key = True

            elif key == "address" and value:
                have_address = True

        elif current_section == "peer":
            if key == "allowedips":
                allowed = [
                    item.strip()
                    for item in value.split(",")
                    if item.strip()
                ]

                if "0.0.0.0/0" in allowed:
                    have_full_ipv4_route = True

            elif key == "endpoint":
                endpoint_count += 1

                indent = re.match(
                    r"^\s*",
                    raw_line,
                ).group(0)

                output.append(
                    "{}Endpoint = {}:{}\n".format(
                        indent,
                        parsed_address,
                        remote_port,
                    )
                )

                replaced_endpoint_count += 1
                continue

        output.append(raw_line)

    if interface_count != 1:
        fail(
            "WireGuard config must contain exactly "
            "one [Interface] section"
        )

    if peer_count < 1:
        fail(
            "WireGuard config has no [Peer] section"
        )

    if not have_private_key:
        fail(
            "WireGuard [Interface] has no PrivateKey"
        )

    if not have_address:
        fail(
            "WireGuard [Interface] has no Address"
        )

    if not have_full_ipv4_route:
        fail(
            "Managed WireGuard requires "
            "0.0.0.0/0 in AllowedIPs"
        )

    if endpoint_count != 1:
        fail(
            "Managed WireGuard requires exactly "
            "one peer Endpoint"
        )

    if replaced_endpoint_count != 1:
        fail(
            "Pinned WireGuard endpoint replacement failed"
        )

    runtime_dir = os.path.dirname(
        output_path
    )

    os.makedirs(
        runtime_dir,
        mode=0o700,
        exist_ok=True,
    )

    os.chmod(
        runtime_dir,
        0o700,
    )

    tmp = output_path + ".tmp"

    try:
        with open(
            tmp,
            "w",
            encoding="utf-8",
        ) as f:
            f.writelines(output)
            f.flush()
            os.fsync(f.fileno())

        os.chmod(
            tmp,
            0o600,
        )

        os.replace(
            tmp,
            output_path,
        )

        os.chmod(
            output_path,
            0o600,
        )

    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass

        raise

    return output_path


def _find_wg_quick():
    override = str(
        os.environ.get(
            "VPN_MANAGER_WG_QUICK",
            "",
        )
    ).strip()

    if override:
        return override

    return shutil.which("wg-quick")


def _interface_exists(
    interface=DEFAULT_INTERFACE,
):
    return os.path.exists(
        "/sys/class/net/{}".format(
            interface
        )
    )


def _run_wg_quick(action, config_path):
    wg_quick = _find_wg_quick()

    if not wg_quick:
        fail(
            "wg-quick executable not found"
        )

    try:
        result = subprocess.run(
            [
                wg_quick,
                action,
                config_path,
            ],
            timeout=45,
        )

    except Exception as exc:
        fail(
            "Could not execute wg-quick: {}".format(
                exc
            )
        )

    if result.returncode != 0:
        fail(
            "wg-quick {} failed".format(
                action
            ),
            result.returncode,
        )


def bring_up(
    registry_path,
    target_path,
    effective_config,
):
    if _interface_exists():
        fail(
            "{} already exists; refusing to replace "
            "an active interface".format(
                DEFAULT_INTERFACE
            )
        )

    profile = load_target_profile(
        registry_path,
        target_path,
    )

    materialize_effective_config(
        profile,
        effective_config,
    )

    _run_wg_quick(
        "up",
        effective_config,
    )

    if not _interface_exists():
        fail(
            "wg-quick returned success but {} "
            "is not present".format(
                DEFAULT_INTERFACE
            )
        )

    print(
        "VPN Manager WireGuard: {} active".format(
            DEFAULT_INTERFACE
        )
    )

    return 0


def bring_down(effective_config):
    if not _interface_exists():
        return 0

    if not os.path.isfile(
        effective_config
    ):
        fail(
            "Effective WireGuard config is missing; "
            "refusing incomplete teardown"
        )

    _run_wg_quick(
        "down",
        effective_config,
    )

    if _interface_exists():
        fail(
            "{} remained after wg-quick down".format(
                DEFAULT_INTERFACE
            )
        )

    return 0


def cleanup_runtime_files(
    effective_config=DEFAULT_EFFECTIVE_CONFIG,
):
    if _interface_exists():
        fail(
            "Refusing WireGuard runtime cleanup while "
            "{} is active".format(
                DEFAULT_INTERFACE
            )
        )

    try:
        os.unlink(
            effective_config
        )
    except FileNotFoundError:
        pass
    except OSError as exc:
        fail(
            "Could not remove effective config: {}".format(
                exc
            )
        )

    runtime_dir = os.path.dirname(
        effective_config
    )

    try:
        os.rmdir(
            runtime_dir
        )
    except FileNotFoundError:
        pass
    except OSError:
        # Leave the directory intact if something else is
        # deliberately present. Never recursively remove /run.
        pass

    return 0


def print_transport(
    registry_path,
    target_path,
):
    profile = load_target_profile(
        registry_path,
        target_path,
    )

    runtime = (
        profile.get("_runtime_target")
        or {}
    )

    remote_address = str(
        runtime.get("remote_address")
        or ""
    ).strip()

    remote_port = str(
        runtime.get("remote_port")
        or ""
    ).strip()

    remote_proto = str(
        runtime.get("remote_proto")
        or ""
    ).strip().lower()

    if (
        not remote_address
        or not remote_port
        or remote_proto != "udp"
    ):
        fail(
            "Validated WireGuard runtime target "
            "has no usable transport"
        )

    print(
        "{}|{}|{}".format(
            remote_address,
            remote_port,
            remote_proto,
        )
    )

    return 0


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Kodi VPN Manager WireGuard runtime launcher"
        )
    )

    mode = parser.add_mutually_exclusive_group(
        required=True
    )

    mode.add_argument(
        "--up",
        action="store_true",
    )

    mode.add_argument(
        "--down",
        action="store_true",
    )

    mode.add_argument(
        "--cleanup",
        action="store_true",
    )

    mode.add_argument(
        "--transport",
        action="store_true",
        help=(
            "Print the validated pinned WireGuard "
            "transport endpoint"
        ),
    )

    args = parser.parse_args()

    registry_path = os.environ.get(
        "VPN_MANAGER_REGISTRY",
        DEFAULT_REGISTRY,
    )

    target_path = os.environ.get(
        "VPN_MANAGER_TARGET",
        DEFAULT_TARGET,
    )

    if args.transport:
        return print_transport(
            registry_path,
            target_path,
        )

    effective_config = os.environ.get(
        "VPN_MANAGER_WIREGUARD_CONFIG",
        DEFAULT_EFFECTIVE_CONFIG,
    )

    if args.cleanup:
        return cleanup_runtime_files(
            effective_config
        )

    if args.down:
        return bring_down(
            effective_config
        )

    return bring_up(
        registry_path,
        target_path,
        effective_config,
    )


if __name__ == "__main__":
    raise SystemExit(main())
