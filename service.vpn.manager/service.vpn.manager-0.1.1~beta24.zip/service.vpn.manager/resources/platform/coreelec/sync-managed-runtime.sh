#!/bin/sh

set -u

SCRIPT_DIR="$(
    CDPATH= cd "$(dirname "$0")" 2>/dev/null &&
    pwd
)"

ADDON_ROOT="$(
    CDPATH= cd "$SCRIPT_DIR/../../.." 2>/dev/null &&
    pwd
)"

VERSION_FILE="$ADDON_ROOT/VERSION"

CFG="/storage/.config"
SYSTEMD="$CFG/system.d"

LOCK_DIR="/run/vpn-manager-runtime.lock"

RUNTIME_ROOT="$CFG/vpn-manager"
BIN_DIR="$RUNTIME_ROOT/bin"
MANIFEST="$RUNTIME_ROOT/manifest.json"
BACKUPS="$RUNTIME_ROOT/backups"

SELECTOR_SERVICE="vpn-manager-selector.service"
SELECTOR_TIMER="vpn-manager-selector.timer"
OPENVPN_SERVICE="vpn-manager-openvpn.service"
WIREGUARD_SERVICE="vpn-manager-wireguard.service"

SELECTOR_UNIT="$SYSTEMD/$SELECTOR_SERVICE"
TIMER_UNIT="$SYSTEMD/$SELECTOR_TIMER"
OPENVPN_UNIT="$SYSTEMD/$OPENVPN_SERVICE"
WIREGUARD_UNIT="$SYSTEMD/$WIREGUARD_SERVICE"
WIREGUARD_LAUNCHER="$BIN_DIR/vpn-manager-wireguard-launcher.py"

STAGE="$RUNTIME_ROOT/.sync-stage-$$"
ROLLBACK="$BACKUPS/pre-sync-$$"

usage()
{
    printf '%s\n' \
        "Usage: $0 --check | --apply"
}

fail()
{
    printf 'ERROR: %s\n' "$1" >&2
    exit 1
}

release_lock()
{
    rm -rf "$LOCK_DIR"
}


acquire_lock()
{
    if mkdir "$LOCK_DIR" 2>/dev/null; then
        :
    else
        OWNER="$(
            cat "$LOCK_DIR/pid" 2>/dev/null ||
            true
        )"

        if [ -n "$OWNER" ] &&
           kill -0 "$OWNER" 2>/dev/null; then
            fail \
                "Another VPN Manager runtime operation is active."
        fi

        rm -rf "$LOCK_DIR"

        mkdir "$LOCK_DIR" 2>/dev/null ||
            fail \
                "Could not acquire VPN Manager runtime lock."
    fi

    printf '%s\n' "$$" > "$LOCK_DIR/pid" ||
        fail "Could not record runtime lock owner."

    trap 'release_lock' EXIT
    trap 'exit 130' INT
    trap 'exit 143' HUP TERM
}

unit_active()
{
    systemctl is-active "$1" >/dev/null 2>&1
}

unit_enabled()
{
    systemctl is-enabled "$1" >/dev/null 2>&1
}

main_pid()
{
    systemctl show "$1" \
        -p MainPID \
        2>/dev/null |
        awk -F= '/^MainPID=/{print $2}'
}

atomic_install()
{
    SRC="$1"
    DEST="$2"
    MODE="$3"

    DIR="$(dirname "$DEST")"
    TMP="$DIR/.vpnmgr-sync-$$-$(basename "$DEST")"

    cp "$SRC" "$TMP" ||
        return 1

    chmod "$MODE" "$TMP" || {
        rm -f "$TMP"
        return 1
    }

    mv -f "$TMP" "$DEST" || {
        rm -f "$TMP"
        return 1
    }

    return 0
}

manifest_matches_runtime()
{
    python3 - \
        "$MANIFEST" \
        "$RUNTIME_ROOT" \
        "$SYSTEMD" <<'PY'
import hashlib
import json
import pathlib
import sys

manifest_path = pathlib.Path(sys.argv[1])
runtime_root = pathlib.Path(sys.argv[2])
systemd_root = pathlib.Path(sys.argv[3])

try:
    data = json.loads(
        manifest_path.read_text(
            encoding="utf-8",
        )
    )
except Exception as exc:
    print(
        "manifest read failed: {}".format(exc),
        file=sys.stderr,
    )
    raise SystemExit(2)

if data.get("schema_version") != 1:
    print(
        "unsupported manifest schema",
        file=sys.stderr,
    )
    raise SystemExit(2)


def digest(path):
    h = hashlib.sha256()

    with path.open("rb") as handle:
        for block in iter(
            lambda: handle.read(1024 * 1024),
            b"",
        ):
            h.update(block)

    return h.hexdigest()


for relative, expected in data.get(
    "files",
    {},
).items():
    path = runtime_root / relative

    if not path.is_file():
        print(
            "missing managed file: {}".format(
                relative
            ),
            file=sys.stderr,
        )
        raise SystemExit(3)

    if digest(path) != expected:
        print(
            "modified managed file: {}".format(
                relative
            ),
            file=sys.stderr,
        )
        raise SystemExit(3)


for name, expected in data.get(
    "units",
    {},
).items():
    path = systemd_root / name

    if not path.is_file():
        print(
            "missing managed unit: {}".format(
                name
            ),
            file=sys.stderr,
        )
        raise SystemExit(3)

    if digest(path) != expected:
        print(
            "modified managed unit: {}".format(
                name
            ),
            file=sys.stderr,
        )
        raise SystemExit(3)

raise SystemExit(0)
PY
}

desired_matches_runtime()
{
    for FILE in \
        vpn-selector.sh \
        vpn-bootstrap-guard.sh \
        openvpn-killswitch.sh \
        openvpn-dns-lock.sh \
        vpn-manager-openvpn-launcher.py \
        vpn-manager-wireguard-launcher.py
    do
        SOURCE_HASH="$(
            sha256sum "$SCRIPT_DIR/$FILE" |
            awk '{print $1}'
        )"

        LIVE_HASH="$(
            sha256sum "$BIN_DIR/$FILE" 2>/dev/null |
            awk '{print $1}'
        )"

        [ -n "$LIVE_HASH" ] ||
            return 1

        [ "$SOURCE_HASH" = "$LIVE_HASH" ] ||
            return 1
    done

    for NAME in \
        vpn-manager-selector.service \
        vpn-manager-selector.timer \
        vpn-manager-openvpn.service \
        vpn-manager-wireguard.service
    do
        SOURCE_HASH="$(
            sha256sum "$SCRIPT_DIR/$NAME" |
            awk '{print $1}'
        )"

        LIVE_HASH="$(
            sha256sum "$SYSTEMD/$NAME" 2>/dev/null |
            awk '{print $1}'
        )"

        [ -n "$LIVE_HASH" ] ||
            return 1

        [ "$SOURCE_HASH" = "$LIVE_HASH" ] ||
            return 1
    done

    return 0
}

write_manifest()
{
    ADDON_VERSION="$(
        cat "$VERSION_FILE" 2>/dev/null ||
        printf '%s' "unknown"
    )"

    TMP="$RUNTIME_ROOT/.manifest-new-$$"

    python3 - \
        "$TMP" \
        "$ADDON_VERSION" \
        "$RUNTIME_ROOT" \
        "$SYSTEMD" <<'PY'
import hashlib
import json
import pathlib
import sys

target = pathlib.Path(sys.argv[1])
version = sys.argv[2]
runtime = pathlib.Path(sys.argv[3])
systemd = pathlib.Path(sys.argv[4])

files = (
    "bin/vpn-selector.sh",
    "bin/vpn-bootstrap-guard.sh",
    "bin/openvpn-killswitch.sh",
    "bin/openvpn-dns-lock.sh",
    "bin/vpn-manager-openvpn-launcher.py",
    "bin/vpn-manager-wireguard-launcher.py",
)

units = (
    "vpn-manager-selector.service",
    "vpn-manager-selector.timer",
    "vpn-manager-openvpn.service",
    "vpn-manager-wireguard.service",
)


def digest(path):
    h = hashlib.sha256()

    with path.open("rb") as handle:
        for block in iter(
            lambda: handle.read(1024 * 1024),
            b"",
        ):
            h.update(block)

    return h.hexdigest()


data = {
    "schema_version": 1,
    "addon_id": "service.vpn.manager",
    "addon_version": version,
    "runtime_root": "/storage/.config/vpn-manager",
    "files": {
        name: digest(runtime / name)
        for name in files
    },
    "units": {
        name: digest(systemd / name)
        for name in units
    },
}

target.write_text(
    json.dumps(
        data,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)
PY

    chmod 600 "$TMP" ||
        return 1

    mv -f "$TMP" "$MANIFEST"
}

restore_sync_backup()
{
    printf '%s\n' \
        "Sync failure detected — restoring previous managed runtime."

    systemctl stop "$WIREGUARD_SERVICE" \
        >/dev/null 2>&1 || true

    systemctl disable "$WIREGUARD_SERVICE" \
        >/dev/null 2>&1 || true

    for FILE in \
        vpn-selector.sh \
        vpn-bootstrap-guard.sh \
        openvpn-killswitch.sh \
        openvpn-dns-lock.sh \
        vpn-manager-openvpn-launcher.py \
        vpn-manager-wireguard-launcher.py
    do
        if [ -f "$ROLLBACK/bin/$FILE" ]; then
            cp \
                "$ROLLBACK/bin/$FILE" \
                "$BIN_DIR/$FILE" ||
                true

            chmod 755 "$BIN_DIR/$FILE" ||
                true
        fi
    done

    for NAME in \
        vpn-manager-selector.service \
        vpn-manager-selector.timer \
        vpn-manager-openvpn.service \
        vpn-manager-wireguard.service
    do
        if [ -f "$ROLLBACK/units/$NAME" ]; then
            cp \
                "$ROLLBACK/units/$NAME" \
                "$SYSTEMD/$NAME" ||
                true

            chmod 644 "$SYSTEMD/$NAME" ||
                true
        fi
    done

    if [ "${WIREGUARD_LAUNCHER_PRESENT_BEFORE:-0}" != "1" ]; then
        rm -f "$WIREGUARD_LAUNCHER"
    fi

    if [ "${WIREGUARD_UNIT_PRESENT_BEFORE:-0}" != "1" ]; then
        rm -f "$WIREGUARD_UNIT"
    fi

    if [ -f "$ROLLBACK/manifest.json" ]; then
        cp \
            "$ROLLBACK/manifest.json" \
            "$MANIFEST" ||
            true

        chmod 600 "$MANIFEST" ||
            true
    fi

    systemctl daemon-reload \
        >/dev/null 2>&1 || true

    rm -rf "$STAGE"

    if [ "${TIMER_ACTIVE_BEFORE:-0}" = "1" ]; then
        systemctl start "$SELECTOR_TIMER" \
            >/dev/null 2>&1 || true
    fi

    printf '%s\n' "Automatic sync rollback attempted."
}

MODE="${1:---check}"

case "$MODE" in
    --check|--apply)
        ;;
    *)
        usage
        exit 2
        ;;
esac

[ "$(id -u)" = "0" ] ||
    fail "Managed runtime sync must run as root."

acquire_lock

for CMD in \
    systemctl \
    sha256sum \
    python3 \
    awk \
    cp \
    mv \
    chmod \
    mkdir \
    rm \
    stat \
    dirname \
    sleep
do
    command -v "$CMD" >/dev/null 2>&1 ||
        fail "Required command not found: $CMD"
done

[ -f "$VERSION_FILE" ] ||
    fail "Addon VERSION file not found."

[ -d "$RUNTIME_ROOT" ] ||
    fail "Managed runtime is not installed."

[ -d "$BIN_DIR" ] ||
    fail "Managed runtime bin directory is missing."

[ -f "$MANIFEST" ] ||
    fail "Managed runtime manifest is missing."

for FILE in \
    vpn-selector.sh \
    vpn-bootstrap-guard.sh \
    openvpn-killswitch.sh \
    openvpn-dns-lock.sh \
    vpn-manager-openvpn-launcher.py \
    vpn-manager-wireguard-launcher.py \
    vpn-manager-openvpn.service \
    vpn-manager-wireguard.service \
    vpn-manager-selector.service \
    vpn-manager-selector.timer
do
    [ -f "$SCRIPT_DIR/$FILE" ] ||
        fail "Packaged host file missing: $FILE"
done

for FILE in \
    vpn-selector.sh \
    vpn-bootstrap-guard.sh \
    openvpn-killswitch.sh \
    openvpn-dns-lock.sh
do
    sh -n "$SCRIPT_DIR/$FILE" ||
        fail "Shell validation failed: $FILE"
done

python3 - "$SCRIPT_DIR/vpn-manager-openvpn-launcher.py" <<'PY' ||
import pathlib
import sys

path = pathlib.Path(sys.argv[1])

compile(
    path.read_text(
        encoding="utf-8",
    ),
    str(path),
    "exec",
)
PY
    fail "Python launcher validation failed."

python3 - "$SCRIPT_DIR/vpn-manager-wireguard-launcher.py" <<'PY_WG' ||
import pathlib
import sys

path = pathlib.Path(sys.argv[1])

compile(
    path.read_text(
        encoding="utf-8",
    ),
    str(path),
    "exec",
)
PY_WG
    fail "WireGuard launcher validation failed."

if ! manifest_matches_runtime; then
    fail \
        "Managed runtime differs from its manifest; refusing overwrite."
fi

WIREGUARD_LAUNCHER_PRESENT_BEFORE=0
WIREGUARD_UNIT_PRESENT_BEFORE=0
WIREGUARD_LAUNCHER_MANAGED_BEFORE=0
WIREGUARD_UNIT_MANAGED_BEFORE=0
WIREGUARD_ACTIVE_BEFORE=0
WIREGUARD_ENABLED_BEFORE=0

[ -f "$WIREGUARD_LAUNCHER" ] &&
    WIREGUARD_LAUNCHER_PRESENT_BEFORE=1

[ -f "$WIREGUARD_UNIT" ] &&
    WIREGUARD_UNIT_PRESENT_BEFORE=1

unit_active "$WIREGUARD_SERVICE" &&
    WIREGUARD_ACTIVE_BEFORE=1

unit_enabled "$WIREGUARD_SERVICE" &&
    WIREGUARD_ENABLED_BEFORE=1

WIREGUARD_OWNERSHIP="$(
    python3 - "$MANIFEST" <<'PY_WG_OWNERSHIP'
import json
import sys

with open(
    sys.argv[1],
    "r",
    encoding="utf-8",
) as f:
    data = json.load(f)

files = data.get("files", {})
units = data.get("units", {})

print(
    "{} {}".format(
        1
        if "bin/vpn-manager-wireguard-launcher.py"
        in files
        else 0,
        1
        if "vpn-manager-wireguard.service"
        in units
        else 0,
    )
)
PY_WG_OWNERSHIP
)" || fail "Could not inspect WireGuard runtime ownership."

WIREGUARD_LAUNCHER_MANAGED_BEFORE="${WIREGUARD_OWNERSHIP%% *}"
WIREGUARD_UNIT_MANAGED_BEFORE="${WIREGUARD_OWNERSHIP#* }"

if [ "$WIREGUARD_LAUNCHER_PRESENT_BEFORE" = "1" ] &&
   [ "$WIREGUARD_LAUNCHER_MANAGED_BEFORE" != "1" ]; then
    fail \
        "Unmanaged WireGuard launcher already exists; refusing overwrite."
fi

if [ "$WIREGUARD_UNIT_PRESENT_BEFORE" = "1" ] &&
   [ "$WIREGUARD_UNIT_MANAGED_BEFORE" != "1" ]; then
    fail \
        "Unmanaged WireGuard unit already exists; refusing overwrite."
fi

if [ "$WIREGUARD_ACTIVE_BEFORE" = "1" ]; then
    fail \
        "WireGuard service is active; refusing dormant runtime sync."
fi

if [ "$WIREGUARD_ENABLED_BEFORE" = "1" ]; then
    fail \
        "WireGuard service is enabled; refusing dormant runtime sync."
fi

if desired_matches_runtime; then
    printf '%s\n' \
        "Managed runtime already matches packaged version."
    printf '%s\n' \
        "Runtime sync: CURRENT"
    exit 0
fi

TIMER_ACTIVE_BEFORE=0
TIMER_ENABLED_BEFORE=0
SELECTOR_ENABLED_BEFORE=0
OPENVPN_ACTIVE_BEFORE=0

unit_active "$SELECTOR_TIMER" &&
    TIMER_ACTIVE_BEFORE=1

unit_enabled "$SELECTOR_TIMER" &&
    TIMER_ENABLED_BEFORE=1

unit_enabled "$SELECTOR_SERVICE" &&
    SELECTOR_ENABLED_BEFORE=1

unit_active "$OPENVPN_SERVICE" &&
    OPENVPN_ACTIVE_BEFORE=1

OPENVPN_PID_BEFORE="$(
    main_pid "$OPENVPN_SERVICE"
)"

printf '%s\n' \
    "VPN Manager managed-runtime sync check"

printf 'addon version: %s\n' \
    "$(cat "$VERSION_FILE")"

printf 'selector enabled: %s\n' \
    "$SELECTOR_ENABLED_BEFORE"

printf 'timer enabled: %s\n' \
    "$TIMER_ENABLED_BEFORE"

printf 'timer active: %s\n' \
    "$TIMER_ACTIVE_BEFORE"

printf 'managed OpenVPN active: %s\n' \
    "$OPENVPN_ACTIVE_BEFORE"

printf 'WireGuard launcher present: %s\n' \
    "$WIREGUARD_LAUNCHER_PRESENT_BEFORE"

printf 'WireGuard unit present: %s\n' \
    "$WIREGUARD_UNIT_PRESENT_BEFORE"

printf 'WireGuard active: %s\n' \
    "$WIREGUARD_ACTIVE_BEFORE"

printf 'WireGuard enabled: %s\n' \
    "$WIREGUARD_ENABLED_BEFORE"

if [ "$MODE" = "--check" ]; then
    printf '%s\n' "Runtime sync required: YES"
    printf '%s\n' "Current runtime ownership: VERIFIED"
    printf '%s\n' "No files or services were modified."
    exit 0
fi

# Do not replace the selector executable while its oneshot is running.
for _WAIT in \
    1 2 3 4 5 6 7 8 9 10 \
    11 12 13 14 15 16 17 18 19 20 \
    21 22 23 24 25 26 27 28 29 30 \
    31 32 33 34 35 36 37 38 39 40 \
    41 42 43 44 45
do
    if ! unit_active "$SELECTOR_SERVICE"; then
        break
    fi

    sleep 1
done

if unit_active "$SELECTOR_SERVICE"; then
    fail \
        "Selector is still active; refusing runtime replacement."
fi

mkdir -p \
    "$STAGE/bin" \
    "$STAGE/units" \
    "$ROLLBACK/bin" \
    "$ROLLBACK/units" ||
    fail "Could not prepare sync staging."

for FILE in \
    vpn-selector.sh \
    vpn-bootstrap-guard.sh \
    openvpn-killswitch.sh \
    openvpn-dns-lock.sh \
    vpn-manager-openvpn-launcher.py \
    vpn-manager-wireguard-launcher.py
do
    if [ -f "$BIN_DIR/$FILE" ]; then
        cp \
            "$BIN_DIR/$FILE" \
            "$ROLLBACK/bin/$FILE" ||
            fail "Could not back up managed executable: $FILE"
    elif [ "$FILE" != "vpn-manager-wireguard-launcher.py" ]; then
        fail "Managed executable missing before sync: $FILE"
    fi

    cp \
        "$SCRIPT_DIR/$FILE" \
        "$STAGE/bin/$FILE" ||
        fail "Could not stage executable: $FILE"

    chmod 755 "$STAGE/bin/$FILE" ||
        fail "Could not stage executable mode: $FILE"
done

for NAME in \
    vpn-manager-selector.service \
    vpn-manager-selector.timer \
    vpn-manager-openvpn.service \
    vpn-manager-wireguard.service
do
    if [ -f "$SYSTEMD/$NAME" ]; then
        cp \
            "$SYSTEMD/$NAME" \
            "$ROLLBACK/units/$NAME" ||
            fail "Could not back up managed unit: $NAME"
    elif [ "$NAME" != "$WIREGUARD_SERVICE" ]; then
        fail "Managed unit missing before sync: $NAME"
    fi

    cp \
        "$SCRIPT_DIR/$NAME" \
        "$STAGE/units/$NAME" ||
        fail "Could not stage unit: $NAME"

    chmod 644 "$STAGE/units/$NAME" ||
        fail "Could not stage unit mode: $NAME"
done

cp "$MANIFEST" "$ROLLBACK/manifest.json" ||
    fail "Could not back up managed manifest."

chmod 600 "$ROLLBACK/manifest.json" ||
    fail "Could not protect manifest backup."

if [ "$TIMER_ACTIVE_BEFORE" = "1" ]; then
    systemctl stop "$SELECTOR_TIMER" || {
        rm -rf "$STAGE"
        fail "Could not pause selector timer."
    }
fi

for FILE in \
    vpn-selector.sh \
    vpn-bootstrap-guard.sh \
    openvpn-killswitch.sh \
    openvpn-dns-lock.sh \
    vpn-manager-openvpn-launcher.py \
    vpn-manager-wireguard-launcher.py
do
    atomic_install \
        "$STAGE/bin/$FILE" \
        "$BIN_DIR/$FILE" \
        755 || {
            restore_sync_backup
            fail "Could not install managed executable: $FILE"
        }
done

for NAME in \
    vpn-manager-selector.service \
    vpn-manager-selector.timer \
    vpn-manager-openvpn.service \
    vpn-manager-wireguard.service
do
    atomic_install \
        "$STAGE/units/$NAME" \
        "$SYSTEMD/$NAME" \
        644 || {
            restore_sync_backup
            fail "Could not install managed unit: $NAME"
        }
done

systemctl daemon-reload || {
    restore_sync_backup
    fail "systemd daemon-reload failed."
}

systemctl stop "$WIREGUARD_SERVICE" \
    >/dev/null 2>&1 || true

systemctl disable "$WIREGUARD_SERVICE" \
    >/dev/null 2>&1 || true

if unit_active "$WIREGUARD_SERVICE"; then
    restore_sync_backup
    fail "WireGuard service became active during runtime sync."
fi

if unit_enabled "$WIREGUARD_SERVICE"; then
    restore_sync_backup
    fail "WireGuard service became enabled during runtime sync."
fi

# Sync must never alter enablement.
SELECTOR_ENABLED_AFTER=0
TIMER_ENABLED_AFTER=0

unit_enabled "$SELECTOR_SERVICE" &&
    SELECTOR_ENABLED_AFTER=1

unit_enabled "$SELECTOR_TIMER" &&
    TIMER_ENABLED_AFTER=1

if [ "$SELECTOR_ENABLED_BEFORE" != "$SELECTOR_ENABLED_AFTER" ] ||
   [ "$TIMER_ENABLED_BEFORE" != "$TIMER_ENABLED_AFTER" ]; then

    restore_sync_backup
    fail "Service enablement changed during runtime sync."
fi

if [ "$TIMER_ACTIVE_BEFORE" = "1" ]; then
    systemctl start "$SELECTOR_TIMER" || {
        restore_sync_backup
        fail "Could not resume selector timer."
    }
fi

OPENVPN_ACTIVE_AFTER=0
unit_active "$OPENVPN_SERVICE" &&
    OPENVPN_ACTIVE_AFTER=1

OPENVPN_PID_AFTER="$(
    main_pid "$OPENVPN_SERVICE"
)"

if [ "$OPENVPN_ACTIVE_BEFORE" != "$OPENVPN_ACTIVE_AFTER" ]; then
    restore_sync_backup
    fail "OpenVPN active state changed during runtime sync."
fi

if [ "$OPENVPN_ACTIVE_BEFORE" = "1" ] &&
   [ "${OPENVPN_PID_BEFORE:-0}" != "${OPENVPN_PID_AFTER:-0}" ]; then

    restore_sync_backup
    fail "OpenVPN PID changed during runtime sync."
fi

if unit_active "$WIREGUARD_SERVICE"; then
    restore_sync_backup
    fail "WireGuard service unexpectedly active after runtime sync."
fi

if unit_enabled "$WIREGUARD_SERVICE"; then
    restore_sync_backup
    fail "WireGuard service unexpectedly enabled after runtime sync."
fi

write_manifest || {
    restore_sync_backup
    fail "Could not update managed runtime manifest."
}

if ! manifest_matches_runtime; then
    restore_sync_backup
    fail "Post-sync manifest verification failed."
fi

if ! desired_matches_runtime; then
    restore_sync_backup
    fail "Post-sync packaged/runtime verification failed."
fi

rm -rf "$STAGE"

printf '%s\n' "Managed runtime sync: PASS"
printf '%s\n' "Runtime ownership: VERIFIED"
printf '%s\n' "Service enablement: UNCHANGED"
printf '%s\n' "Existing OpenVPN process was not restarted."
printf 'rollback snapshot: %s\n' "$ROLLBACK"

exit 0
