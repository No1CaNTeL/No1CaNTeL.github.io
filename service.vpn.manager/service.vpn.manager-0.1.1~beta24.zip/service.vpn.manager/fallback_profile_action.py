import json
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import profiles as profile_registry
from resources.lib.log_privacy import install_log_filter


install_log_filter()

ADDON = xbmcaddon.Addon(
    "service.vpn.manager"
)
DIALOG = xbmcgui.Dialog()

PROFILE_REGISTRY = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/profiles.json"
)

FALLBACK_RECENT_STORE = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/fallback_recent_profiles.json"
)

FALLBACK_RECENT_DEFAULT = 20
FALLBACK_RECENT_MIN = 1
FALLBACK_RECENT_MAX = 50

SUPPORTED_TYPES = (
    "openvpn",
    "wireguard",
)


def _label(profile):
    name = str(
        profile.get("name") or ""
    ).strip()

    profile_type = str(
        profile.get("type") or ""
    ).strip().lower()

    protocol = (
        "OpenVPN"
        if profile_type == "openvpn"
        else "WireGuard"
    )

    return "{} [{}]".format(
        name or profile.get("id") or "Unnamed",
        protocol,
    )



def _fallback_recent_limit():
    try:
        value = int(
            ADDON.getSetting(
                "fallback_recent_limit"
            ) or FALLBACK_RECENT_DEFAULT
        )
    except (TypeError, ValueError):
        value = FALLBACK_RECENT_DEFAULT

    return max(
        FALLBACK_RECENT_MIN,
        min(
            FALLBACK_RECENT_MAX,
            value,
        ),
    )


def _load_fallback_recent_ids():
    try:
        with open(
            FALLBACK_RECENT_STORE,
            "r",
            encoding="utf-8",
        ) as handle:
            data = json.load(handle)

    except (
        OSError,
        ValueError,
        TypeError,
    ):
        return []

    if isinstance(data, dict):
        values = data.get(
            "profiles",
            [],
        )

    elif isinstance(data, list):
        values = data

    else:
        return []

    result = []
    seen = set()

    for value in values:
        profile_id = str(
            value or ""
        ).strip()

        if (
            not profile_id
            or profile_id in seen
        ):
            continue

        seen.add(profile_id)
        result.append(profile_id)

        if len(result) >= _fallback_recent_limit():
            break

    return result


def _save_fallback_recent_ids(profile_ids):
    directory = (
        os.path.dirname(
            FALLBACK_RECENT_STORE
        )
        or "."
    )

    os.makedirs(
        directory,
        exist_ok=True,
    )

    values = []
    seen = set()

    for value in profile_ids:
        profile_id = str(
            value or ""
        ).strip()

        if (
            not profile_id
            or profile_id in seen
        ):
            continue

        seen.add(profile_id)
        values.append(profile_id)

        if len(values) >= _fallback_recent_limit():
            break

    temp_path = (
        FALLBACK_RECENT_STORE + ".tmp"
    )

    try:
        with open(
            temp_path,
            "w",
            encoding="utf-8",
        ) as handle:
            json.dump(
                {
                    "schema": 1,
                    "profiles": values,
                },
                handle,
                indent=2,
            )

            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())

        try:
            os.chmod(
                temp_path,
                0o600,
            )
        except OSError:
            pass

        os.replace(
            temp_path,
            FALLBACK_RECENT_STORE,
        )

        try:
            os.chmod(
                FALLBACK_RECENT_STORE,
                0o600,
            )
        except OSError:
            pass

    finally:
        if os.path.exists(temp_path):
            try:
                os.unlink(temp_path)
            except OSError:
                pass


def _record_fallback_recent(profile_id):
    profile_id = str(
        profile_id or ""
    ).strip()

    if not profile_id:
        return

    current = _load_fallback_recent_ids()

    current = [
        value
        for value in current
        if value != profile_id
    ]

    current.insert(
        0,
        profile_id,
    )

    _save_fallback_recent_ids(
        current
    )




def main():
    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

    except Exception as exc:
        xbmc.log(
            "Kodi VPN Manager: could not load fallback "
            "profile registry: {}".format(exc),
            xbmc.LOGERROR,
        )

        DIALOG.notification(
            ADDON.getLocalizedString(32200),
            ADDON.getLocalizedString(32205),
            xbmcgui.NOTIFICATION_ERROR,
            6000,
        )
        return

    candidates = []

    for profile in profile_registry.profiles(data):
        if not isinstance(profile, dict):
            continue

        if not profile.get("enabled", True):
            continue

        profile_type = str(
            profile.get("type") or ""
        ).strip().lower()

        if profile_type not in SUPPORTED_TYPES:
            continue

        candidates.append(profile)

    candidate_by_id = {
        str(
            profile.get("id") or ""
        ): profile
        for profile in candidates
        if profile.get("id")
    }

    configured = profile_registry.fallback_profile(
        data
    )

    configured_id = (
        str(configured.get("id") or "")
        if configured
        else ""
    )

    display_value = (
        _label(configured)
        if configured
        else ADDON.getLocalizedString(32202)
    )

    ADDON.setSetting(
        "fallback_vpn_profile",
        display_value,
    )

    selected = profile_registry.selected_profile(
        data
    )

    selected_provider_id = (
        str(
            selected.get("provider_id") or ""
        )
        if selected
        else ""
    )

    providers = []

    for provider in profile_registry.providers(data):
        provider_id = str(
            provider.get("id") or ""
        )

        provider_candidates = [
            profile
            for profile
            in profile_registry.profiles_for_provider(
                data,
                provider_id,
            )
            if str(
                profile.get("id") or ""
            ) in candidate_by_id
        ]

        if not provider_candidates:
            continue

        provider_candidates.sort(
            key=lambda item: (
                str(
                    item.get("name") or ""
                ).casefold(),
                str(
                    item.get("id") or ""
                ),
            )
        )

        providers.append(
            (
                provider,
                provider_candidates,
            )
        )

    providers.sort(
        key=lambda item: (
            0
            if str(
                item[0].get("id") or ""
            ) == selected_provider_id
            else 1,
            str(
                item[0].get("name") or ""
            ).casefold(),
            str(
                item[0].get("id") or ""
            ),
        )
    )

    recent = []

    for profile_id in _load_fallback_recent_ids():
        profile = candidate_by_id.get(
            profile_id
        )

        if not profile:
            continue

        recent.append(profile)

        if len(recent) >= _fallback_recent_limit():
            break

    chosen_profile = None
    choose_none = False

    while True:
        root_labels = [
            ADDON.getLocalizedString(32202)
        ]

        root_actions = [
            ("none", None)
        ]

        if recent:
            root_labels.append(
                "Recent  >"
            )
            root_actions.append(
                ("recent", recent)
            )

        for provider, provider_candidates in providers:
            provider_name = str(
                provider.get("name") or ""
            ).strip()

            root_labels.append(
                "{}  >".format(
                    provider_name or "Unnamed"
                )
            )

            root_actions.append(
                (
                    "provider",
                    provider_candidates,
                )
            )

        root_preselect = 0

        if configured_id:
            for index, (
                action_type,
                action_value,
            ) in enumerate(root_actions):
                if action_type == "recent":
                    if any(
                        str(
                            profile.get("id") or ""
                        ) == configured_id
                        for profile in action_value
                    ):
                        root_preselect = index
                        break

                if action_type == "provider":
                    if any(
                        str(
                            profile.get("id") or ""
                        ) == configured_id
                        for profile in action_value
                    ):
                        root_preselect = index
                        break

        root_choice = DIALOG.select(
            ADDON.getLocalizedString(32203),
            root_labels,
            preselect=root_preselect,
        )

        if root_choice < 0:
            xbmc.executebuiltin(
                "Addon.OpenSettings(service.vpn.manager)"
            )
            return

        action_type, action_value = (
            root_actions[root_choice]
        )

        if action_type == "none":
            choose_none = True
            break

        branch_profiles = action_value

        branch_labels = [
            _label(profile)
            for profile in branch_profiles
        ]

        branch_preselect = 0

        for index, profile in enumerate(
            branch_profiles
        ):
            if str(
                profile.get("id") or ""
            ) == configured_id:
                branch_preselect = index
                break

        if action_type == "recent":
            branch_title = "Recent"
        else:
            provider_id = str(
                branch_profiles[0].get(
                    "provider_id"
                ) or ""
            )

            provider = profile_registry.provider(
                data,
                provider_id,
            )

            branch_title = str(
                (provider or {}).get("name")
                or ADDON.getLocalizedString(32203)
            )

        branch_choice = DIALOG.select(
            branch_title,
            branch_labels,
            preselect=branch_preselect,
        )

        # Back from a branch returns to the tree root.
        if branch_choice < 0:
            continue

        chosen_profile = branch_profiles[
            branch_choice
        ]
        break

    selected_id = None

    if not choose_none and chosen_profile:
        selected_id = chosen_profile.get("id")

    try:
        updated = profile_registry.set_fallback(
            data,
            selected_id,
        )

        profile_registry.save(
            PROFILE_REGISTRY,
            updated,
        )

    except Exception as exc:
        xbmc.log(
            "Kodi VPN Manager: could not save fallback "
            "profile: {}".format(exc),
            xbmc.LOGERROR,
        )

        DIALOG.notification(
            ADDON.getLocalizedString(32200),
            ADDON.getLocalizedString(32205),
            xbmcgui.NOTIFICATION_ERROR,
            6000,
        )
        return

    if selected_id and chosen_profile:
        try:
            _record_fallback_recent(
                chosen_profile.get("id")
            )

        except Exception as exc:
            xbmc.log(
                "Kodi VPN Manager: could not update "
                "fallback recent profiles: {}".format(
                    exc
                ),
                xbmc.LOGWARNING,
            )

        display_value = _label(
            chosen_profile
        )

        message = ADDON.getLocalizedString(
            32204
        ).format(
            display_value
        )

    else:
        display_value = ADDON.getLocalizedString(
            32202
        )
        message = display_value

    ADDON.setSetting(
        "fallback_vpn_profile",
        display_value,
    )

    DIALOG.notification(
        ADDON.getLocalizedString(32200),
        message,
        xbmcgui.NOTIFICATION_INFO,
        5000,
    )

    xbmc.executebuiltin(
        "Addon.OpenSettings(service.vpn.manager)"
    )


if __name__ == "__main__":
    main()
